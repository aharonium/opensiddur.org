<?php
// Set the Current Author Variable $curauth
$curauth = get_user_by('slug', get_query_var('author_name'));

// Initialize a flag to determine whether to show the "Take the next step" message
$show_next_step_message = false;

// Check if $curauth is valid and has roles
if (!$curauth || !isset($curauth->roles) || !is_array($curauth->roles)) {
    $show_next_step_message = true; // Set the flag to true if $curauth is invalid or has no roles
}
?>

<?php 
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();
?>

<?php
get_header(); 
?>


<?php if ( $curauth && ! empty( $curauth->ID ) ) : ?>

<meta name="twitter:card" content="summary" />
<meta name="twitter:image:src"
      content="<?php echo esc_url( get_avatar_url( $curauth->ID, ['size' => 300] ) ); ?>" />
<meta property="og:description"
      content="Prayers and other works by <?php echo esc_attr( $curauth->display_name ); ?> shared through the Open Siddur Project.">
<meta property="og:image"
      content="<?php echo esc_url( get_avatar_url( $curauth->ID, ['size' => 300] ) ); ?>" />

<?php endif; ?>


<?php
extract($bfa_ata); 
global $bfa_ata_postcount;
?>

<?php if ($bfa_ata['widget_center_top'] <> '') { 
    echo bfa_parse_widget_areas($bfa_ata['widget_center_top']); 
} ?>

<div class="<?php echo ( is_page() ? 'page ' : '' ) . 'post" id="post-'; the_ID(); ?>">
	

<?php if ($show_next_step_message || 
    (!in_array('contributor', $curauth->roles) && !in_array('author', $curauth->roles))) : 
?>
    <?php echo do_shortcode('[spacer height="20px"]'); ?>
    <h1>Take the next step</h1>
    <?php echo do_shortcode('[spacer height="20px"]'); ?>
    <p>Profile pages are only available for <a href="/upload/">project contributors</a>.</p>
    <?php get_footer(); exit; ?>
<?php endif; ?>


	
<!-- Show Author Info -->

<div class="author-profile-card">
    <div class="author-photo">
        <?php echo get_avatar($curauth->user_email, 250); ?>
    </div>

    <div class="author-details">
        <h2 class="author-name"><a href="/index.php?user_ID=<?php echo esc_attr($curauth->ID); ?>" style="text-decoration: none; color: inherit;">
            <?php echo get_the_author_meta('display_name'); ?>
        </a></h2>
        
        <!-- <?php
        // Fetch sibling accounts
        $siblings = get_sibling_accounts($curauth->ID);

        if (!empty($siblings)) {
            echo do_shortcode('[spacer height="20px"]');
            echo '<div class="sibling-accounts" style="text-indent: 10px;">';
            echo 'Also find:&nbsp; ';

            $sibling_links = [];
            foreach ($siblings as $sibling) {
                $display_name = $sibling->display_name;

                // Check if "transcription" or "translation" is in the display name
                if (preg_match('/\btranscription\b/i', $display_name)) {
                    $display_name = preg_replace('/\btranscription\b/i', 'transcriptions', $display_name);
                } elseif (preg_match('/\btranslation\b/i', $display_name)) {
                    $display_name = preg_replace('/\btranslation\b/i', 'translations', $display_name);
                } else {
                    $display_name .= ' (original works)';
                }
                
                $profile_url = home_url('/profile/' . $sibling->user_nicename);
                $sibling_links[] = '<a href="' . esc_url($profile_url) . '">' . esc_html($display_name) . '</a>';
            }

            // Join the links with ' | ' and display them
            echo implode(' | ', $sibling_links);
            echo '</div>';
        }
        ?> -->
        
        <div class="author-description"><?php echo wpautop($curauth->user_description); ?></div>

        <?php if (!empty($curauth->user_url)) : ?>
            <a class="author-website" href="<?php echo esc_url($curauth->user_url); ?>" target="_blank">
                <?php echo esc_html($curauth->user_url); ?>
            </a>
        <?php endif; ?>

        <div class="author-contributions">
            <?php echo do_shortcode('[author_contributions]'); ?>
        </div>
    </div>
</div>


<style>
.tabs {
    display: flex;
    gap: 10px;
    border-bottom: 2px solid #ccc;
    margin-bottom: 20px;
}
.tab-button {
    padding: 10px 20px;
    cursor: pointer;
    background: #F4E1C6;
    border: 2px solid #ccc;
    border-bottom: none;
    border-radius: 8px 8px 0 0;
    font-weight: bold;
    text-decoration: none;
    color: black;
}
.tab-button.active {
    background: #e0c095;
    border-bottom: 2px solid #e0c095;
}
</style>


<?php
$curauth = get_userdata(get_query_var('author'));
$main_id = get_main_account_id($curauth->ID);
$sibling_data = get_sibling_accounts_with_roles($main_id);

// Identify the current user's role_label first
$current_role_label = null;
foreach ($sibling_data as $entry) {
    if ($entry['user']->ID === $curauth->ID) {
        $current_role_label = $entry['role_label'];
        break;
    }
}
/*
// If current user not in list, add them with the correct role label
$is_in_list = false;
foreach ($sibling_data as $entry) {
    if ($entry['user']->ID === $curauth->ID) {
        $is_in_list = true;
        break;
    }
}
if (!$is_in_list) {
    $sibling_data[] = ['user' => $curauth, 'role_label' => $current_role_label];
}
*/
// Separate original account and others
$original = null;
$others = [];

foreach ($sibling_data as $entry) {
    if ($entry['role_label'] === null) {
        $original = $entry;
    } else {
        $others[] = $entry;
    }
}

// Sort others by role label
usort($others, function($a, $b) {
    return strcmp($a['role_label'], $b['role_label']);
});

// Combine original and others
$ordered_accounts = [];
if ($original) {
    $ordered_accounts[] = $original;
}
$ordered_accounts = array_merge($ordered_accounts, $others);

// Render the tabs
if (count($ordered_accounts) > 1) {
    echo '<div class="sibling-tabs" style="margin-top: 30px;">';
    echo '<div class="tabs">';

    foreach ($ordered_accounts as $entry) {
        $user = $entry['user'];
        $role_label = $entry['role_label'];
        $label = $role_label ? esc_html($role_label) : 'original works';

        $is_active = ($user->ID === $curauth->ID);

        if ($is_active) {
            // Active tab: render as non-clickable <span>
            echo "<span class='tab-button active'>{$label}</span>";
        } else {
            // Sibling tabs: clickable link
            $url = esc_url(home_url('/profile/' . $user->user_nicename));
            echo "<a class='tab-button' href='{$url}'>{$label}</a>";
        }
    }

    echo '</div></div>';
}
?>


<?php 
// Display filter message if a category, tag, collaborator, date range, or language filter is applied
$filter_message = '';

// Get the base author URL (unfiltered)
$author_id = get_query_var('author');
$base_url = get_author_posts_url($author_id);

// Handle category filter
if (isset($_GET['cat'])) {
    $category = get_category_by_slug($_GET['cat']);
    if ($category) {
        $filter_message = 'Resources filtered by CATEGORY: “' . esc_html($category->name);
    }
} 

// Handle tag filter
elseif (isset($_GET['tag'])) {
    $tag = get_term_by('slug', $_GET['tag'], 'post_tag');
    if ($tag) {
        $filter_message = 'Resources filtered by TAG: “' . esc_html($tag->name);
    }
} 

// Handle collaborator filter
elseif (isset($_GET['collab'])) {
    $collab_id = intval($_GET['collab']);
    $collab_user = get_user_by('ID', $collab_id);
    if ($collab_user) {
        $filter_message = 'Resources filtered by COLLABORATOR: “' . esc_html($collab_user->display_name);
    }
}

// Handle date range filter
elseif (isset($_GET['daterange_start']) && isset($_GET['daterange_end'])) {
    $start = (int) $_GET['daterange_start'];
    $end = (int) $_GET['daterange_end'];

    $start_label = ($start < 0) ? abs($start) . ' BCE' : $start . ' CE';
    $end_label = ($end < 0) ? abs($end) . ' BCE' : $end . ' CE';

    $filter_message = 'Resources filtered by DATE RANGE: “' . esc_html($start_label) . ' to ' . esc_html($end_label) . '”';
}

// Handle language filter
elseif (isset($_GET['language']) && isset($_GET['language_name'])) {
    $filter_message = 'Resources filtered by LANGUAGE: “' . esc_html(urldecode($_GET['language_name'])) . '”';
}

// Display the filter message with "Clear filter" link if it's set
if ($filter_message) {
    echo '<div class="filter-message" style="font-size: 18px; margin-bottom: 20px;">';
    echo $filter_message . '” <a href="' . esc_url($base_url) . '" style="font-size: 16px; color: #0073aa;">(clear filter)</a>';
    echo '</div>';
}
?>


<!-- Pagination -->

<?php 
    echo '<div align="right">';
    the_posts_pagination();
    echo '</div>';
    echo do_shortcode('[spacer height="20px"]');
?>
	
<p />
 
 
<!-- Sort options for posts -->

<?php 

/*
$current_order = isset($_GET['order']) ? $_GET['order'] : 'asc';
$next_order = ($current_order === 'asc') ? 'desc' : 'asc';
$base_url = add_query_arg(array(
    'order' => $next_order,
));
*/

// $filtered_count = isset($_GET['filtered_posts']) ? (int) $_GET['filtered_posts'] : 0;

// if ($filtered_count > 1) {
    // Capture the current order from the URL, defaulting to 'asc'
    $current_order = isset($_GET['order']) ? $_GET['order'] : 'asc';
    // Determine the opposite order for the toggle link
    $next_order = ($current_order === 'asc') ? 'desc' : 'asc';
    // Generate the base URL (keeping any existing query parameters like category or tag)
    $base_url = add_query_arg(array(
        'order' => $next_order,
    ));

    // Display the toggle link
    echo '<div class="sort-options">';
    if ($current_order === 'asc') {
        echo '<span style="text-decoration: underline; text-underline-offset: 10px; text-decoration-thickness: from-font;">';
        echo 'Sorted Chronologically (new to old). Sort <a href="' . esc_url($base_url) . '">oldest first</a>?';
        echo '</span>';
    } else {
        echo '<span style="text-decoration: underline; text-underline-offset: 10px; text-decoration-thickness: from-font;">';
        echo 'Sorted Chronologically (old to new). Sort <a href="' . esc_url($base_url) . '">most recent first</a>?';
        echo '</span>';    
    }   
    echo '</div>';
    echo do_shortcode('[spacer height="20px"]');
// }
?>



<?php if (have_posts()) : ?>

<!-- Begin posts loop) -->

<?php while (have_posts()) : the_post(); ?>


<div class="post-headline"><h2 style="margin=0;">
  <a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>">
    <?php
      // Show "NEW" emoji if post was created within the last 31 days
      // $created = new DateTime(get_the_date('Y-m-d H:i:s', $current_id));
      $created = new DateTime(get_the_date('Y-m-d H:i:s', get_the_ID()));  // Use get_the_ID() instead of $current_id
      $current = new DateTime(current_time('mysql'));
      $is_new = $created->diff($current)->days < 31;
      if ($is_new) {
        echo '&#x1F195; ';
      }
    ?>
    <?php the_title(); ?>
  </a>
</h2></div>

<p class="posted-on" style="color: #696969; padding-left: 40px;">
  Contributed by:
  <?php
    if ( class_exists('coauthors_plus') ) {
      $co_authors = get_coauthors();
      $coauthor_links = [];

      foreach ( $co_authors as $key => $co_author ) {
        $display_name = esc_html($co_author->display_name);
        $classes = 'author-post-coauthor-wrap author-post-coauthor-' . ($key + 1);

        // Skip linking to the current author's profile
        if ($co_author->display_name === $curauth->display_name) {
          $coauthor_links[] = '' . $display_name . '';
        } else {
          $url = esc_url('/profile/' . $co_author->user_nicename);
          $coauthor_links[] = '<a href="' . $url . '">' . $display_name . '</a>';
        }
      }

      // Output joined by comma and space
      echo implode(', ', $coauthor_links);
    }
    // echo ' &#10087;'; // ❧
  ?>
</p>

<div style="padding-left: 40px;"><?php the_excerpt(); ?></div>
<hr />



<?php endwhile; ?>

<!-- End posts loop -->

<?php 
    // Pagination for longer lists
    echo do_shortcode('[spacer height="20px"]');
    echo '<div align="right">';    
    the_posts_pagination();
    echo '</div>';    
    echo do_shortcode('[social_sharing]');
?>

<?php else : ?>
    <p>No posts found for this author.</p>
<?php endif; ?>

<?php 
    // Reset Post Data to prevent conflicts
    wp_reset_postdata();
?>

<?php get_footer(); ?>