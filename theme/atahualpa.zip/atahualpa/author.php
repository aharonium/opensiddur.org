<?php
// Set the Current Author Variable $curauth
$curauth = get_user_by('slug', get_query_var('author_name'));

// Initialize a flag to determine whether to show the "Take the next step" message
$show_next_step_message = false;

// Check if $curauth is valid and has roles
if (!$curauth || !isset($curauth->roles) || !is_array($curauth->roles)) {
    $show_next_step_message = true; // Set the flag to true if $curauth is invalid or has no roles
}
?>

<?php 
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();
?>

<?php
get_header(); 
?>


<meta name="twitter:card" content="summary" />
<meta name="twitter:image:src" content="<?php echo get_avatar_url($curauth->ID, ['size' => '300']); ?>" />
<meta property="og:description" content="Prayers and other works by <?php echo $curauth->display_name; ?> shared through the Open Siddur Project.">
<meta property="og:image" content="<?php echo get_avatar_url($curauth->ID, ['size' => '300']); ?>" />

<?php
extract($bfa_ata); 
global $bfa_ata_postcount;
?>




<?php if ($bfa_ata['widget_center_top'] <> '') { 
    echo bfa_parse_widget_areas($bfa_ata['widget_center_top']); 
} ?>

<div class="<?php echo ( is_page() ? 'page ' : '' ) . 'post" id="post-'; the_ID(); ?>">
	

<?php if ($show_next_step_message || 
    (!in_array('contributor', $curauth->roles) && !in_array('author', $curauth->roles))) : 
?>
    <?php echo do_shortcode('[spacer height="20px"]'); ?>
    <h1>Take the next step</h1>
    <?php echo do_shortcode('[spacer height="20px"]'); ?>
    <p>Profile pages are only available for <a href="/upload/">project contributors</a>.</p>
    <?php get_footer(); exit; ?>
<?php endif; ?>


	
<!-- Show Author Info -->

<div class="author-profile-card">
    <div class="author-photo">
        <?php echo get_avatar($curauth->user_email, 250); ?>
    </div>

    <div class="author-details">
        <h2 class="author-name"><a href="/index.php?user_ID=<?php echo esc_attr($curauth->ID); ?>" style="text-decoration: none; color: inherit;">
            <?php echo get_the_author_meta('display_name'); ?>
        </a></h2>
        
        <?php
        // Fetch sibling accounts
        $siblings = get_sibling_accounts($curauth->ID);

        if (!empty($siblings)) {
            echo do_shortcode('[spacer height="20px"]');
            echo '<div class="sibling-accounts" style="text-indent: 10px;">';
            echo 'Also find:&nbsp; ';

            $sibling_links = [];
            foreach ($siblings as $sibling) {
                $display_name = $sibling->display_name;

                // Check if "transcription" or "translation" is in the display name
                if (preg_match('/\btranscription\b/i', $display_name)) {
                    $display_name = preg_replace('/\btranscription\b/i', 'transcriptions', $display_name);
                } elseif (preg_match('/\btranslation\b/i', $display_name)) {
                    $display_name = preg_replace('/\btranslation\b/i', 'translations', $display_name);
                } else {
                    $display_name .= ' (original works)';
                }
                
                $profile_url = home_url('/profile/' . $sibling->user_nicename);
                $sibling_links[] = '<a href="' . esc_url($profile_url) . '">' . esc_html($display_name) . '</a>';
            }

            // Join the links with ' | ' and display them
            echo implode(' | ', $sibling_links);
            echo '</div>';
        }
        ?>
        
        <div class="author-description"><?php echo wpautop($curauth->user_description); ?></div>

        <?php if (!empty($curauth->user_url)) : ?>
            <a class="author-website" href="<?php echo esc_url($curauth->user_url); ?>" target="_blank">
                <?php echo esc_html($curauth->user_url); ?>
            </a>
        <?php endif; ?>

        <div class="author-contributions">
            <?php echo do_shortcode('[author_contributions]'); ?>
        </div>
    </div>
</div>


<?php 
// Display filter message if a category, tag, collaborator, date range, or language filter is applied
$filter_message = '';

// Get the base author URL (unfiltered)
$author_id = get_query_var('author');
$base_url = get_author_posts_url($author_id);

// Handle category filter
if (isset($_GET['cat'])) {
    $category = get_category_by_slug($_GET['cat']);
    if ($category) {
        $filter_message = 'Resources filtered by CATEGORY: “' . esc_html($category->name);
    }
} 

// Handle tag filter
elseif (isset($_GET['tag'])) {
    $tag = get_term_by('slug', $_GET['tag'], 'post_tag');
    if ($tag) {
        $filter_message = 'Resources filtered by TAG: “' . esc_html($tag->name);
    }
} 

// Handle collaborator filter
elseif (isset($_GET['collab'])) {
    $collab_id = intval($_GET['collab']);
    $collab_user = get_user_by('ID', $collab_id);
    if ($collab_user) {
        $filter_message = 'Resources filtered by COLLABORATOR: “' . esc_html($collab_user->display_name);
    }
}

// Handle date range filter
elseif (isset($_GET['daterange_start']) && isset($_GET['daterange_end'])) {
    $start = (int) $_GET['daterange_start'];
    $end = (int) $_GET['daterange_end'];

    $start_label = ($start < 0) ? abs($start) . ' BCE' : $start . ' CE';
    $end_label = ($end < 0) ? abs($end) . ' BCE' : $end . ' CE';

    $filter_message = 'Resources filtered by DATE RANGE: “' . esc_html($start_label) . ' to ' . esc_html($end_label) . '”';
}

// Handle language filter
elseif (isset($_GET['language']) && isset($_GET['language_name'])) {
    $filter_message = 'Resources filtered by LANGUAGE: “' . esc_html(urldecode($_GET['language_name'])) . '”';
}

// Display the filter message with "Clear filter" link if it's set
if ($filter_message) {
    echo '<div class="filter-message" style="font-size: 18px; margin-bottom: 20px;">';
    echo $filter_message . '” <a href="' . esc_url($base_url) . '" style="font-size: 16px; color: #0073aa;">(clear filter)</a>';
    echo '</div>';
}
?>




<!-- Pagination -->

<?php 
    echo '<div align="right">';
    the_posts_pagination();
    echo '</div>';
    echo do_shortcode('[spacer height="20px"]');
?>
	
<p />
 
<!-- Sort options for posts -->

<?php 
// Capture the current order from the URL, defaulting to 'asc'
$current_order = isset($_GET['order']) ? $_GET['order'] : 'asc';

// Determine the opposite order for the toggle link
$next_order = ($current_order === 'asc') ? 'desc' : 'asc';

// Generate the base URL (keeping any existing query parameters like category or tag)
$base_url = add_query_arg(array(
    'order' => $next_order,
));

// Display the toggle link
echo '<div class="sort-options">';
if ($current_order === 'asc') {
    echo '<span style="text-decoration: underline; text-underline-offset: 10px; text-decoration-thickness: from-font;">';
    echo 'Sorted Chronologically (new to old). Sort <a href="' . esc_url($base_url) . '">oldest first</a>?';
    echo '</span>';
} else {
    echo '<span style="text-decoration: underline; text-underline-offset: 10px; text-decoration-thickness: from-font;">';
    echo 'Sorted Chronologically (old to new). Sort <a href="' . esc_url($base_url) . '">most recent first</a>?';
    echo '</span>';    
}
echo '</div>';
echo do_shortcode('[spacer height="20px"]');
?>



<?php if (have_posts()) : ?>

<!-- Begin posts loop) -->

<?php while (have_posts()) : the_post(); ?>

		<?php 
		    // Check if the post is new
            $created = new DateTime(get_the_date('Y-m-d H:i:s', $current_id));
            $current = new DateTime(current_time('mysql'));
            $created_to_today = $created->diff($current);
            $is_new = ($created_to_today && $created_to_today->days < 31);
            
            if ($is_new) {
                $newemoji = '&#x1F195; ';
            } else { 
                $newemoji = '';
            }
        ?>

<h3>
<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php if ($newemoji) { echo $newemoji; } ?>
<?php the_title(); ?></a>
</h3>
<p class="posted-on" style="color: #696969; padding-left: 40px;">Contributed <!-- on: <?php the_time('d M Y'); ?> -->by&nbsp; 

		<?php if ( class_exists( 'coauthors_plus' ) ) { 		// Get the Co-Authors for the post
			$co_authors = get_coauthors();  // For each Co-Author, echo a wrapper div, their name, and their bio if they have one
			foreach ( $co_authors as $key => $co_author ) {
				$co_author_classes = array(
					'co-author-wrap',
					'co-author-number-' . ( $key + 1 ),
				);
				echo '<span style="color: #000; fontWeight: normal;" class="' . implode( ' ', $co_author_classes ) . '">';
				if ($co_author->display_name !== $curauth->display_name) { echo '<a href="/profile/' . $co_author->user_nicename . '">'; }
				echo '<span class="co-author-display-name" style="font-weight: normal;">' . $co_author->display_name . '</span></a> | </span>';
			}
		
		} echo '&#10087;';  ?>


</p>
 
<div style="padding-left: 40px;"><?php the_excerpt(); ?></div><hr />

<?php endwhile; ?>

<!-- End posts loop -->

<?php 
    // Pagination for longer lists
    echo do_shortcode('[spacer height="20px"]');
    the_posts_pagination();
    echo do_shortcode('[social_sharing]');
?>

<?php else : ?>
    <p>No posts found for this author.</p>
<?php endif; ?>

<?php 
    // Reset Post Data to prevent conflicts
    wp_reset_postdata();
?>

<?php get_footer(); ?>