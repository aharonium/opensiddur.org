<!DOCTYPE html>
<?php 
	$templateURI = get_template_directory_uri(); 
	$homeURL = get_home_url();  ?>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php // if index.php or another page template (copied from index.php) was not used
if (!isset($bfa_ata))  
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options(); ?>
<?php global $post_id; ?>
<title><?php wp_title( '' ); ?></title>
<?php 
/*
 * Legacy Internet Explorer X-UA-Compatible handling removed.
 * This block previously emitted IE compatibility meta tags
 * (IE7–IE9 / Edge modes), which are no longer relevant.
 *
 * Original code preserved below for historical reference.
 */

/* if ( isset($bfa_ata['IEDocType']) ) { 
switch ( $bfa_ata['IEDocType'] ) { 
	case "None":
		break;
	case "EmulateIE7":
		?><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7"/>
		<?php
		break;
	case "EmulateIE8":
		?><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8"/>
		<?php
		break;
	case "IE8":
		?><meta http-equiv="X-UA-Compatible" content="IE=8"/>
		<?php
		break;
	case "IE9":
		?><meta http-equiv="X-UA-Compatible" content="IE=9"/>
		<?php
		break;
	case "Edge":
		?><meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
		<?php
		break;
	default:
		break;
}} */ ?><?php echo bfa_meta_tags(); ?>
<?php 

if ($bfa_ata['favicon_file'] != "") { 
    if($bfa_ata['images_root'] == "atahualpa") {
           $imgdir  = get_template_directory_uri() . '/images/favicon/';
        } else {
// at this point the images_root is 'wp-content'
    		if(!isset($bfa_ata['ata_images_dir']) 
    		OR ($bfa_ata['ata_images_dir'] == '') ) {	
           		$imgdir  = content_url() . '/ata-images/';
			} else {
				$imgdir  = content_url() . '/' . $bfa_ata['ata_images_dir'] . '/';
        	}
    	}
?><link rel="shortcut icon" href="<?php echo $imgdir. $bfa_ata['favicon_file']; ?>" />
<?php } ?>
<!-- <link rel="profile" href="http://gmpg.org/xfn/11" /> -->
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( $bfa_ata['css_external'] == "External" ) { ?><link rel="stylesheet" href="<?php echo $homeURL; ?>/?bfa_ata_file=css" type="text/css" media="all" /><?php } ?>
<?php if ( function_exists('wp_list_comments') AND is_singular() AND (comments_open( $post_id ))) { 	wp_enqueue_script( 'comment-reply' ); } ?>
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>	<?php bfa_incl('html_inserts_body_tag'); ?>>
<?php bfa_incl('html_inserts_body_top'); ?>

<?php if ($bfa_ata['full_width_header'] == "Yes") { ?>
		<!-- Full Width Header -->
		<div id="header" class="full-width">
		<?php echo bfa_header_config(); ?>
		</div>
		<!-- / Full Width Header -->
<?php } ?>
<div id="wrapper">
<div id="container">
<table id="layout" border="0" cellspacing="0" cellpadding="0">
<colgroup>
<?php if ( $left_col == "on" ) { ?><col class="colone" /><?php } ?>
<?php if ( $left_col2 == "on" ) { ?><col class="colone-inner" /><?php } ?>
<col class="coltwo" />
<?php if ( $right_col2 == "on" ) { ?><col class="colthree-inner" /><?php } ?>
<?php if ( $right_col == "on" ) { ?><col class="colthree" /><?php } ?>
</colgroup> 

<?php if ($bfa_ata['full_width_header'] == "No") { ?>
	<tr>
		<!-- Header -->
		<td id="header" colspan="<?php echo $cols; ?>">
		<?php echo bfa_header_config(); ?>
			<!-- begin בס״ד -->		
			<div align="right" style="vertical-align: text-top;">
			    <a href="/index.php?tag_ID=285" style="text-decoration: none; color: inherit; font-weight: normal;">
			    <span class="shamayim" lang="heb-hebr" style="float: right; position: absolute; right: 25px; top: 25px; z-index: 0;">&#x1FAAC;&#xFE0E; בסיעתא דשמיא</span>
			    </a>
			</div>
			<!-- end בס״ד -->
		</td>
	<tr>

		<!-- Header -->
<?php } ?>
	<!-- Main Body -->	
	<tr id="bodyrow">

		<?php if ( $left_col == "on" ) { ?>
		<!-- Left Sidebar -->
		<td id="left">

			<?php // Widgetize the Left Sidebar 
			if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Left Sidebar') ) : ?>
		
				<div class="widget widget_categories">
					<div class="widget-title">
						<h3><?php _e('Categories','atahualpa'); ?></h3>
					</div>
					<ul><?php wp_list_categories('show_count=1&title_li='); ?></ul>
				</div>
				
				<div class="widget widget_archive">
					<div class="widget-title">
						<h3><?php _e('Archives','atahualpa'); ?></h3>
					</div>
					<ul><?php wp_get_archives('type=monthly'); ?></ul>
				</div>

				<div class="widget widget_text">
					<div class="widget-title">
						<h3>A sample text widget</h3>
					</div>
					<div class="textwidget">
						<p>Etiam pulvinar consectetur dolor sed malesuada. Ut convallis 
						<a href="http://wordpress.org/">euismod dolor nec</a> pretium. Nunc ut tristique massa. </p>
						<p>Nam sodales mi vitae dolor <em>ullamcorper et vulputate enim accumsan</em>. 
						Morbi orci magna, tincidunt vitae molestie nec, molestie at mi. <strong>Nulla nulla lorem</strong>, 
						suscipit in posuere in, interdum non magna. </p>
					</div>
				</div>
				
			<?php endif; ?>

		</td>
		<!-- / Left Sidebar -->
		<?php } ?>

		<?php if ( $left_col2 == "on" ) { ?>
		<!-- Left INNER Sidebar -->
		<td id="left-inner">

			<?php // Widgetize the Left Inner Sidebar 
			if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Left Inner Sidebar') ) : ?>
		
					<!-- no default content for the LEFT INNER sidebar -->
									
			<?php endif; ?>

		</td>
		<!-- / Left INNER Sidebar -->
		<?php } ?>
		

		<!-- Main Column -->
		<td id="middle">