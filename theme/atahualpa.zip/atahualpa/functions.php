<?php
$bfa_ata_version = "3.7.27";

// Load translation file above
// load_theme_textdomain('atahualpa');

add_action('init', function() {
    load_theme_textdomain('atahualpa');
});


// get default theme options
include_once (get_template_directory() . '/functions/bfa_theme_options.php');
// Load options
include_once (get_template_directory() . '/functions/bfa_get_options.php');
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();


// Sidebars:
add_action( 'widgets_init', 'bfa_widgets_init' );
function bfa_widgets_init() {

	global $bfa_ata;

	register_sidebar(array(
		'name'=>'Left Sidebar',
		'id'=> 'bfa-ata-left-sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title"><h3>',
		'after_title' => '</h3></div>',
	));
	register_sidebar(array(
		'name'=>'Right Sidebar',
		'id'=> 'bfa-ata-right-sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title"><h3>',
		'after_title' => '</h3></div>',
	));
	register_sidebar(array(
		'name'=>'Left Inner Sidebar',
		'id'=> 'bfa-ata-left-inner-sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title"><h3>',
		'after_title' => '</h3></div>',
	));
	register_sidebar(array(
		'name'=>'Right Inner Sidebar',
		'id'=> 'bfa-ata-right-inner-sidebar',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title"><h3>',
		'after_title' => '</h3></div>',
	));
			
	// Register additional extra widget areas:
	# $bfa_ata_extra_widget_areas = get_option('bfa_widget_areas');
	if(isset($bfa_ata['bfa_widget_areas'])) $bfa_ata_extra_widget_areas = $bfa_ata['bfa_widget_areas'];
	else $bfa_ata_extra_widget_areas = '';
	
	if ($bfa_ata_extra_widget_areas != '') {
		$n = 0;
		foreach ($bfa_ata_extra_widget_areas as $widget_area) {
			$n++; 
			$id_name = 'bfa-ata-extra-widget-area-'.$n;
			register_sidebar(array(
				'name' => $widget_area['name'],
				'id'=> $id_name,
				'before_widget' => $widget_area['before_widget'],
				'after_widget' => $widget_area['after_widget'],
				'before_title' => $widget_area['before_title'],
				'after_title' => $widget_area['after_title']
			));
		}
	}
}


#global $bfa_ata;
// Load functions
include_once (get_template_directory() . '/functions/bfa_header_config.php');
include_once (get_template_directory() . '/functions/bfa_meta_tags.php');
include_once (get_template_directory() . '/functions/bfa_hor_cats.php');
include_once (get_template_directory() . '/functions/bfa_hor_pages.php');
// New WP3 menus:
include_once (get_template_directory() . '/functions/bfa_new_wp3_menus.php');
include_once (get_template_directory() . '/functions/bfa_footer.php');
include_once (get_template_directory() . '/functions/bfa_recent_comments.php');
include_once (get_template_directory() . '/functions/bfa_popular_posts.php');
include_once (get_template_directory() . '/functions/bfa_popular_in_cat.php');
include_once (get_template_directory() . '/functions/bfa_subscribe.php');
include_once (get_template_directory() . '/functions/bfa_postinfo.php');
include_once (get_template_directory() . '/functions/bfa_rotating_header_images.php');
include_once (get_template_directory() . '/functions/bfa_next_previous_links.php');
include_once (get_template_directory() . '/functions/bfa_post_parts.php');
if (!function_exists('paged_comments'))  
	include_once (get_template_directory() . '/functions/bfa_custom_comments.php');
	
// Since 3.5.2: JSON for PHP 4 & 5.1:
if (!function_exists('json_decode')) {
	include_once (get_template_directory() . '/functions/JSON.php');
	function json_encode($data) { $json = new Services_JSON(); return( $json->encode($data) ); }
	function json_decode($data) { $json = new Services_JSON(); return( $json->decode($data) ); }
}
function bfa_toArray($data) {
    if (is_object($data)) $data = get_object_vars($data);
    return is_array($data) ? array_map(__FUNCTION__, $data) : $data;
}



// For plugin "Sociable":
if (function_exists('sociable_html')) 
	include_once (get_template_directory() . '/functions/bfa_sociable2.php'); 

// "Find in directory" function, needed for finding header images on WPMU
if (file_exists(ABSPATH."/wpmu-settings.php")) 
	include_once (get_template_directory() . '/functions/bfa_m_find_in_dir.php');

// CSS for admin area
include_once (get_template_directory() . '/functions/bfa_css_admin_head.php');
// Add the CSS to the <head>...</head> of the theme option admin area
add_action('admin_head', 'bfa_add_stuff_admin_head');

include_once (get_template_directory() . '/functions/bfa_ata_add_admin.php');
include_once (get_template_directory() . '/functions/bfa_ata_admin.php');
add_action('admin_menu', 'bfa_ata_add_admin');


// Escape single & double quotes
function bfa_escape($string) {
	$string = (string) $string;
	$string = str_replace('"', '&#34;', $string);
	$string = str_replace("'", '&#39;', $string);
	return $string;
}


// Move Featured Content Gallery down in script order in wp_head(), so that jQuery can finish before mootools
// Since 3.6 this probably won't work because as per the new WP rules wp_head() must be right before </head>
function bfa_remove_featured_gallery_scripts() {
       remove_action('wp_head', 'gallery_styles');
}
add_action('init','bfa_remove_featured_gallery_scripts', 1);

function bfa_addscripts_featured_gallery() {
	if(!function_exists('gallery_styles')) return;
	gallery_styles();
}
add_action('wp_head', 'bfa_addscripts_featured_gallery', 12);

/*
 * Add custom header inserts through wp_head
 *
 * wp_head is supposed to be right before </head>, but html_inserts_header should be after/at the bottom of wp_head
 *
@ since 3.6.5
*/
function bfa_add_html_inserts_header() {
	global $bfa_ata;
	if( $bfa_ata['html_inserts_header'] != '' ) bfa_incl('html_inserts_header'); 
}
add_action('wp_head', 'bfa_add_html_inserts_header', 20);

// new comment template for WP 2.7+, legacy template for old WP 2.6 and older
// Since 3.6.: ToDo: Remove legacy.comments.php after a while. Older WP's won't work anyway 
// with the new WP requirements to REPLACE older functions with newer ones introduced in 2.8 (i.e. get_the_author_meta)
if ( !function_exists('paged_comments') ) {
	include_once (get_template_directory() . '/functions/bfa_custom_comments.php'); 
}

// remove WP default inline CSS for ".recentcomments a" from header
function bfa_remove_wp_widget_recent_comments_style() {
      remove_filter('wp_head', 'wp_widget_recent_comments_style' );
}
add_filter( 'wp_head', 'bfa_remove_wp_widget_recent_comments_style', 1 );


/* Remove plugin CSS & JS and include them in the theme's main CSS and JS files
This will be extended and improved in upcoming versions */

// remove WP Pagenavi CSS, will be included in css.php
if (function_exists('wp_pagenavi')) {
	remove_action('wp_head', 'pagenavi_css');
}

// If the plugin Share This is activated, disable its auto-output so we can control it 
// through the Atahualpa Theme Options
if ( function_exists('akst_share_link') ) {
	@define('AKST_ADDTOCONTENT', false);
	@define('AKST_ADDTOFOOTER', false);
}

/* EXTERNAL OR INTERNAL CSS & JS, PLUS COMPRESSION & DEBUG */

// Register new query variables "bfa_ata_file" and "bfa_debug" with Wordpress
add_filter('query_vars', 'bfa_add_new_var_to_wp');
function bfa_add_new_var_to_wp($public_query_vars) {
	$public_query_vars[] = 'bfa_ata_file';
	$public_query_vars[] = 'bfa_debug';
	return $public_query_vars;
}

// if debug add/remove info
if ( function_exists('wp_generator') ) {
	remove_action('wp_head', 'wp_generator');
}
add_action('wp_head', 'bfa_debug');
function bfa_debug() {
	global $bfa_ata, $bfa_ata_version;
	$debug = get_query_var('bfa_debug');
	if ( $debug == 1 ) {
		echo '<meta name="theme" content="Atahualpa ' . $bfa_ata_version . '" />' . "\n";
		if ( function_exists('the_generator') ) { 
			the_generator( apply_filters( 'wp_generator_type', 'xhtml' ) );
		}
		echo '<meta name="robots" content="noindex, follow" />'."\n";
	}
}	

// redirect the template if new var "bfa_ata_file" or "bfa_debug" exists in URL 
add_action('template_redirect', 'bfa_css_js_redirect');
add_action('wp_head', 'bfa_inline_css_js');

// since 3.4.3 
function bfa_add_js_link() {
	global $bfa_ata;
	$homeURL = get_home_url();  
	
	if ( $bfa_ata['javascript_external'] == "External" ) { ?>
	<script type="text/javascript" src="<?php echo $homeURL; ?>/?bfa_ata_file=js"></script>
	<?php } 
}
add_action('wp_head', 'bfa_add_js_link');

function bfa_css_js_redirect() {
	global $bfa_ata;
	$bfa_ata_query_var_file = get_query_var('bfa_ata_file');
	if ( $bfa_ata_query_var_file == "css" OR $bfa_ata_query_var_file == "js" ) {
		include_once (get_template_directory() . '/' . $bfa_ata_query_var_file . '.php');
		exit; // this stops WordPress entirely
	}
	// Since 3.4.7: Import/Export Settings
	if ( $bfa_ata_query_var_file == "settings-download" ) {
		if(isset($_FILES['userfile'])) $uploadedfile = $_FILES['userfile'];
		include_once (get_template_directory() . '/download.php');
		exit; // this stops WordPress entirely
	}
	if ( $bfa_ata_query_var_file == "settings-upload" ) {
		include_once (get_template_directory() . '/upload.php');
		exit; // this stops WordPress entirely
	}
}
	
function bfa_inline_css_js() {
	global $bfa_ata;
	$bfa_ata_preview = get_query_var('preview');
	$bfa_ata_debug = get_query_var('bfa_debug');
	if ( $bfa_ata_preview == 1 OR $bfa_ata['css_external'] == "Inline" OR 
	( $bfa_ata_debug == 1 AND $bfa_ata['allow_debug'] == "Yes" ) ) {
		include_once (get_template_directory() . '/css.php');
	}
	if ( $bfa_ata_preview == 1 OR $bfa_ata['javascript_external'] == "Inline" OR 
	( $bfa_ata_debug == 1 AND $bfa_ata['allow_debug'] == "Yes" ) ) {
		include_once (get_template_directory() . '/js.php');
	}
}


function bfa_delete_bfa_ata4() {
	check_ajax_referer( "delete_bfa_ata4" );
	if (delete_option('bfa_ata4')) echo '<span style="color:green;font-weight:bold;">Successfully deleted option \'bfa_ata4\' ...</span>'; 
	else echo '<span style="color:green;font-weight:bold;">Something went wrong...</span>';
	die();
}
// add_action ( 'wp_ajax_' + [name of "action" in jQuery.ajax, see functions/bfa_css_admin_head.php], [name of function])
add_action( 'wp_ajax_bfa_delete_bfa_ata4', 'bfa_delete_bfa_ata4' );



// Custom Excerpts 
/*
function bfa_wp_trim_excerpt($text) { // Fakes an excerpt if needed

	global $bfa_ata, $post;

	if ( '' <> $text ) {
//  an manual excerpt exists, stick on the 'custom read more' and we're done
		$words = preg_split("/\s+/u", $text);
		$custom_read_more = str_replace('%permalink%', get_permalink(), $bfa_ata['custom_read_more']);
		if ( get_the_title() == '' ) { 
			$custom_read_more = str_replace('%title%', 'Permalink', $custom_read_more);
		} else {		
			$custom_read_more = str_replace('%title%', the_title('','',FALSE), $custom_read_more);
		}
		array_push($words, $custom_read_more);
		$text = implode(' ', $words);
		return $text;
	}

	$text = get_the_content('');
	$words = preg_split ("/\s+/u", $text);
	// $post_content = $post->post_content;
	$post_content = ( $post && isset( $post->post_content ) ) ? $post->post_content : '';
	$post_content_length = count(preg_split("/\s+/u", $post_content));

// Build the excerpt from the post 
		$text = apply_filters('the_content', $text);
 		$text = str_replace(']]>', ']]>', $text);
		$text = strip_tags($text, $bfa_ata['dont_strip_excerpts']);
		$excerpt_length = $bfa_ata['excerpt_length'];
		$words = preg_split("/\s+/u", $text, $excerpt_length + 1);

// this is to handle the case where the number of words 
// in the post equals the excerpt length

 	if ($post_content_length > $excerpt_length) {	
 		array_pop($words);	
//  		array_pop($words);	
		$custom_read_more = str_replace('%permalink%', get_permalink(), $bfa_ata['custom_read_more']);
		$custom_read_more = str_replace('%title%', the_title('','',FALSE), $custom_read_more);
		array_push($words, $custom_read_more);
 	}
	$text = implode(' ', $words);
	return $text;

	return $text;
}
remove_filter('get_the_excerpt', 'wp_trim_excerpt');
add_filter('get_the_excerpt', 'bfa_wp_trim_excerpt');
*/

function bfa_wp_trim_excerpt($text) {

	global $bfa_ata, $post;

	$text = (string) $text;

	if ( '' !== $text ) {

		$words = preg_split("/\s+/u", $text);

		$custom_read_more = str_replace(
			'%permalink%',
			(string) get_permalink(),
			(string) ($bfa_ata['custom_read_more'] ?? '')
		);

		if ( get_the_title() === '' ) { 
			$custom_read_more = str_replace('%title%', 'Permalink', $custom_read_more);
		} else {		
			$custom_read_more = str_replace(
				'%title%',
				(string) the_title('', '', FALSE),
				$custom_read_more
			);
		}

		$words[] = $custom_read_more;
		return implode(' ', $words);
	}

	$text = (string) get_the_content('');
	$words = preg_split("/\s+/u", $text);

	$post_content = ( $post && isset( $post->post_content ) ) ? (string) $post->post_content : '';
	$post_content_length = count(preg_split("/\s+/u", $post_content));

	$text = apply_filters('the_content', $text);
	$text = str_replace(']]>', ']]>', $text);
	$text = strip_tags($text, (string) ($bfa_ata['dont_strip_excerpts'] ?? ''));

	$excerpt_length = (int) ($bfa_ata['excerpt_length'] ?? 55);
	$words = preg_split("/\s+/u", $text, $excerpt_length + 1);

	if ( $post_content_length > $excerpt_length ) {	
		array_pop($words);

		$custom_read_more = str_replace(
			'%permalink%',
			(string) get_permalink(),
			(string) ($bfa_ata['custom_read_more'] ?? '')
		);

		$custom_read_more = str_replace(
			'%title%',
			(string) the_title('', '', FALSE),
			$custom_read_more
		);

		$words[] = $custom_read_more;
	}

	return implode(' ', $words);
}




/* Custom widget areas. 

Usage:
<?php bfa_widget_area([parameters]); ?>

Example: 
<?php bfa_widget_area('name=My widget area&cells=4&align=1&align_2=9&align_3=7&width_4=700&before_widget=<div id="%1$s" class="header-widget %2$s">&after_widget=</div>'); ?>

Can be used anywhere in templates, and in theme option text areas that allow usage of PHP code.

Available paramaters:

Mandatory:
name					Name under which all cells of this widget area will be listed at Site Admin -> Appearance -> Widgets
							A widget area with 3 cells and a name of "My widget area" creates 3 widget cells which appear as
							"My widget area 1", "My widget area 2" and "My widget area 3", 
							with the CSS ID's "my_widget_area_1", "my_widget_area_2" and "my_widget_area_3". 
						
Optional:
cells						Amount of (table) cells. Each cell is a new widget area. Default: 1
align						Default alignment for all cells. Default: 2 (= center top). 1 = center middle, 2 = center top, 3 = right top, 4 = right middle, 
							5 = right bottom, 6 = center bottom, 7 = left bottom, 8 = left middle, 9 = left top.
align_1					Alignment for cell 1: align_2, align_3 ... Non-specified cells get the default value of "align", which, if not defined, is 2 (= center top).
width_1				Width of cell 1: width_1, width_2, width_3 ... Non-specified cells get a equal share of the remaining width of the whole table
							containing all the widget area cells.
before_widget		HTML before each widget in any cell of this widget area. Default:  <div id="%1$s" class="widget %2$s">
after_widget		HMTL after each widget ... Default: </div>
before_title			HTML before the title of each widget in any cell of this widget area: Default: <div class="widget-title"><h3>
after_title			HMTL after the title ... Default: </h3></div>

*/
function bfa_widget_area($args = '') {
	global $bfa_ata;
	$defaults = array(
		'name' => '',
		'cells' => 1,
		'align' => 2,
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="widget-title"><h3>',
		'after_title' => '</h3></div>',
	);
	
	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );

	$area_id = strtolower(str_replace(" ", "_", (string) $r['name']));
	
	# $bfa_widget_areas = get_option('bfa_widget_areas');
	$bfa_widget_areas = $bfa_ata['bfa_widget_areas'];	
	
	// If there are more than 1 cell, use a table, otherwise just a DIV:
	if ( $r['cells'] > 1 ) {
	
		echo '<table id="' . $area_id . '" class="bfa_widget_area" style="table-layout:fixed;width:100%" cellpadding="0" cellspacing="0" border="0">';

		// If a width was set for any of the widget area cells:
		# if ( strpos($args,'width_') !== FALSE ) {
		
		// Since 3.6.7
		$colgroup = 'no'; // If all table cells have the same width, this can be achieved by table-layout:fixed alone, without the colgroup element.
		// Check if any of the cells have a set width
		for ( $i = 1; $i <= $r['cells']; $i++ ) { 
			if ( array_key_exists('width_' . $i, $r) AND !empty($r['width_' . $i]) ) {
					$colgroup = 'yes';
			}
		}
		
		if ($colgroup == 'yes') {
			echo "\n<colgroup>";
			for ( $i = 1; $i <= $r['cells']; $i++ ) {
				echo '<col';
				$current_width = "width_" . $i;
				if ( isset($r[$current_width]) ) {
					if (!preg_match('/(%|px|pX|Px|PX)/',$r[$current_width]) ) {
						$r[$current_width] = $r[$current_width].'px';
					}
					echo ' style="width:' . $r[$current_width] . '"';
				}
				echo ' />';
			}
			echo "</colgroup>";
		}
		
		echo "<tr>";
		
		for ( $i = 1; $i <= $r['cells']; $i++ ) {
			
				$current_name = $r['name'] . ' ' . $i;
				$current_id = $area_id . '_' . $i;
				$current_align = "align_" . $i;
				
				echo "\n" . '<td id="' . $current_id .'" ';
				
				if ( isset($r[$current_align]) ) 
					$align_type = $r["$current_align"];
				else 
					$align_type = $r['align'];
				
				echo bfa_table_cell_align($align_type) . ">";
				
				// Register widget area
		  		$this_widget_area = array(
		  			"name" => $current_name,
		  			"before_widget" => $r['before_widget'],
		  			"after_widget" => $r['after_widget'],
		  			"before_title" => $r['before_title'],
		  			"after_title" => $r['after_title']
		  			);
		  
		   		// Display widget area
				dynamic_sidebar("$current_name"); 
				
				echo "\n</td>";
				
				$bfa_widget_areas[$current_name] = $this_widget_area;
		}
		
		echo "\n</tr></table>";     
	
	} else {
	
		// If only 1 widget cell, use a DIV instead of a table
		echo '<div id="' . $area_id . '" class="bfa_widget_area">';
		
		// Add new widget area to existing ones
		$this_widget_area = array(
			"name" => $r['name'],
			"before_widget" => $r['before_widget'],
			"after_widget" => $r['after_widget'],
			"before_title" => $r['before_title'],
			"after_title" => $r['after_title']
			);

		// Display widget area
		dynamic_sidebar($r['name']); 	

		echo '</div>';
		
		$current_name = $r['name'];
		$bfa_widget_areas[$current_name] = $this_widget_area;
	
	}

	# update_option("bfa_widget_areas", $bfa_widget_areas);
	$bfa_ata['bfa_widget_areas'] = $bfa_widget_areas;
	update_option('bfa_ata4', $bfa_ata);

}


function bfa_table_cell_align($align_type) {
	switch ($align_type) {
		case 1: $string = 'align="center" valign="middle"'; break;
		case 2: $string = 'align="center" valign="top"'; break;
		case 3: $string = 'align="right" valign="top"'; break;		
		case 4: $string = 'align="right" valign="middle"'; break;
		case 5: $string = 'align="right" valign="bottom"'; break;
		case 6: $string = 'align="center" valign="bottom"'; break;
		case 7: $string = 'align="left" valign="bottom"'; break;
		case 8: $string = 'align="left" valign="middle"'; break;
		case 9: $string = 'align="left" valign="top"'; 
	}
	return $string;
}
	

// Since 3.4.3: Delete Widget Areas
function bfa_ata_reset_widget_areas() {
	global $bfa_ata;
	check_ajax_referer( "reset_widget_areas" );
	$delete_areas = $_POST['delete_areas'];
	# $current_areas = get_option('bfa_widget_areas');
	$current_areas = $bfa_ata['bfa_widget_areas'];
	foreach ($delete_areas as $area_name) {
		unset($current_areas[$area_name]);
	}
	# update_option('bfa_widget_areas', $current_areas);
	$bfa_ata['bfa_widget_areas'] = $current_areas;
	update_option('bfa_ata4', $bfa_ata);
	echo 'Custom widget areas deleted...'; 
	die();
}
// add_action ( 'wp_ajax_' + [name of "action" in jQuery.ajax, see functions/bfa_css_admin_head.php], [name of function])
add_action( 'wp_ajax_reset_bfa_ata_widget_areas', 'bfa_ata_reset_widget_areas' );


// Since 3.6.5: Import Settings
/* function bfa_ata_import_settings() {
	global $bfa_ata;
	check_ajax_referer( "import_settings" );
	
	// was encoded with encodeURIComponent in bfa_css_admin_head.php
	// $import_options = rawurldecode($_POST['options']);
	$import_options = stripslashes($_POST['ataoptions']);
	
	// Since 3.5.2, use JSON 
	if ( json_decode($import_options) != NULL AND strpos($import_options, 'use_bfa_seo') !== FALSE ) {
		update_option('bfa_ata4', json_decode($import_options, TRUE));
		echo "<strong><span style='color:green'>Success! Reloading admin area in 2 seconds... </span></strong><br />";		
	
	// Probably not a valid settings file:
	} else {
		echo "<strong><span style='color:red'>Sorry, but doesn't appear 
			to be a valid Atahualpa Settings File.</span></strong>";
			#print_r($import_options);
	}	
	
	die();
}
// add_action ( 'wp_ajax_' + [name of "action" in jQuery.ajax, see functions/bfa_css_admin_head.php], [name of function])
*/

function bfa_ata_import_settings() {
	global $bfa_ata;
	check_ajax_referer( "import_settings" );

	$import_options = isset($_POST['ataoptions'])
		? (string) stripslashes($_POST['ataoptions'])
		: '';

	// Since 3.5.2, use JSON 
	if (
		json_decode($import_options) !== NULL &&
		strpos($import_options, 'use_bfa_seo') !== false
	) {
		update_option('bfa_ata4', json_decode($import_options, true));
		echo "<strong><span style='color:green'>Success! Reloading admin area in 2 seconds... </span></strong><br />";
	} else {
		echo "<strong><span style='color:red'>Sorry, but doesn't appear 
			to be a valid Atahualpa Settings File.</span></strong>";
	}

	die();
}
add_action( 'wp_ajax_import_settings', 'bfa_ata_import_settings' );



/* CUSTOM BODY TITLE and meta title, meta keywords, meta description */
if(isset($bfa_ata['page_post_options'])) {
	if ($bfa_ata['page_post_options'] == "Yes") {
	/* Use the admin_menu action to define the custom boxes */
		if (is_admin())
			add_action('admin_menu', 'bfa_ata_add_custom_box');

		/* Use the save_post action to do something with the data entered */
		add_action('save_post', 'bfa_ata_save_postdata');
	}
}

/* Use the publish_post action to do something with the data entered */
#add_action('publish_post', 'bfa_ata_save_postdata');

#add_action('pre_post_update', 'bfa_ata_save_postdata');

/* Adds a custom section to the "advanced" Post and Page edit screens */
function bfa_ata_add_custom_box() {

  if( function_exists( 'add_meta_box' )) {
    add_meta_box( 'bfa_ata_sectionid', __( 'Atahualpa Post Options', 'atahualpa' ), 
                'bfa_ata_inner_custom_box', 'post', 'normal', 'high' );
    add_meta_box( 'bfa_ata_sectionid', __( 'Atahualpa Page Options', 'atahualpa' ), 
                'bfa_ata_inner_custom_box', 'page', 'normal', 'high' );
   } else {
    add_action('dbx_post_advanced', 'bfa_ata_old_custom_box' );
    add_action('dbx_page_advanced', 'bfa_ata_old_custom_box' );
  }
}
   
/* Prints the inner fields for the custom post/page section */
function bfa_ata_inner_custom_box() {

	global $post;
	
  // Use nonce for verification

	echo '<input type="hidden" name="bfa_ata_noncename" id="bfa_ata_noncename" value="' . 
    wp_create_nonce( plugin_basename(__FILE__) ) . '" />';

  // The actual fields for data entry
  
  	$thePostID = $post->ID;
	$post_id = get_post($thePostID);
#	$title = $post_id->post_title;
	$title = ($post_id->post_title !== 'Auto Draft') ? $post_id->post_title : '';

	$body_title = get_post_meta($post->ID, 'bfa_ata_body_title', true);
	if ( $body_title == '' ) {
		$body_title = $title;
	}
	$display_body_title = get_post_meta($post->ID, 'bfa_ata_display_body_title', true);
	$body_title_multi = get_post_meta($post->ID, 'bfa_ata_body_title_multi', true);
	if ( $body_title_multi == '' ) {
		$body_title_multi = $title;
	}
	$meta_title = get_post_meta($post->ID, 'bfa_ata_meta_title', true);
	$meta_keywords = get_post_meta($post->ID, 'bfa_ata_meta_keywords', true);
	$meta_description = get_post_meta($post->ID, 'bfa_ata_meta_description', true);	

	echo '<table cellpadding="5" cellspacing="0" border="0" style="table-layout:fixed;width:100%">';
	echo '<tr><td style="text-align:right;padding:2px 5px 2px 2px"><input id="bfa_ata_display_body_title" name="bfa_ata_display_body_title" type="checkbox" '. ($display_body_title == 'on' ? ' CHECKED' : '') .' /></td><td>Check to <strong>NOT</strong> display the Body Title on Single Post or Static Pages</td></tr>';
	echo '<tr><td style="text-align:right;padding:2px 5px 2px 2px"><label for="bfa_ata_body_title">' . __("Body Title Single Pages", 'atahualpa' ) . '</label></td>';
	echo '<td><input type="text" name="bfa_ata_body_title" value="' . $body_title . '" size="70" style="width:97%" /></td></tr>';
	echo '<tr><td style="text-align:right;padding:2px 5px 2px 2px"><label for="bfa_ata_body_title_multi">' . __("Body Title Multi Post Pages", 'atahualpa' ) . '</label></td>';
	echo '<td><input type="text" name="bfa_ata_body_title_multi" value="' . $body_title_multi . '" size="70" style="width:97%" /></td></tr>';
		
	echo '<colgroup><col style="width:200px"><col></colgroup>';
	echo '<tr><td style="text-align:right;padding:2px 5px 2px 2px"><label for="bfa_ata_meta_title">' . __("Meta Title", 'atahualpa' ) . '</label></td>';
	echo '<td><input type="text" name="bfa_ata_meta_title" value="' . 
	$meta_title . '" size="70" style="width:97%" /></td></tr>';
	
	echo '<tr><td style="text-align:right;padding:2px 5px 2px 2px"><label for="bfa_ata_meta_keywords">' . __("Meta Keywords", 'atahualpa' ) . '</label></td>';
	echo '<td><input type="text" name="bfa_ata_meta_keywords" value="' . 
	$meta_keywords . '" size="70" style="width:97%" /></td></tr>';
	
	echo '<tr><td style="text-align:right;vertical-align:top;padding:5px 5px 2px 2px"><label for="bfa_ata_meta_description">' . __("Meta Description", 'atahualpa' ) . '</label></td>';
	echo '<td><textarea name="bfa_ata_meta_description" cols="70" rows="4" style="width:97%">'.$meta_description.'</textarea></td></tr>';
	
	echo '</table>';

}

/* Prints the edit form for pre-WordPress 2.5 post/page */
function bfa_ata_old_custom_box() {

  echo '<div class="dbx-b-ox-wrapper">' . "\n";
  echo '<fieldset id="bfa_ata_fieldsetid" class="dbx-box">' . "\n";
  echo '<div class="dbx-h-andle-wrapper"><h3 class="dbx-handle">' . 
        __( 'Body copy title', 'atahualpa' ) . "</h3></div>";   
   
  echo '<div class="dbx-c-ontent-wrapper"><div class="dbx-content">';

  // output editing form

  bfa_ata_inner_custom_box();

  // end wrapper

  echo "</div></div></fieldset></div>\n";
}



/* When the post is saved, save our custom data */
function bfa_ata_save_postdata( $post_id ) {

  /* verify this came from the our screen and with proper authorization,
  because save_post can be triggered at other times */
// Before using $_POST['value']    
if (isset($_POST['bfa_ata_noncename']))    
{     

	if ( !wp_verify_nonce( $_POST['bfa_ata_noncename'], plugin_basename(__FILE__) )) {
		return $post_id;
	}

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ))
			return $post_id;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ))
			return $post_id;
		}

	// Save the data
	
	$new_body_title = $_POST['bfa_ata_body_title'];
	$new_display_body_title = !isset($_POST["bfa_ata_display_body_title"]) ? NULL : $_POST["bfa_ata_display_body_title"];
	$new_body_title_multi = $_POST['bfa_ata_body_title_multi'];
	$new_meta_title = $_POST['bfa_ata_meta_title'];
	$new_meta_keywords = $_POST['bfa_ata_meta_keywords'];
	$new_meta_description = $_POST['bfa_ata_meta_description'];

	update_post_meta($post_id, 'bfa_ata_body_title', $new_body_title);
	update_post_meta($post_id, 'bfa_ata_display_body_title', $new_display_body_title);
	update_post_meta($post_id, 'bfa_ata_body_title_multi', $new_body_title_multi);
	update_post_meta($post_id, 'bfa_ata_meta_title', $new_meta_title);
	update_post_meta($post_id, 'bfa_ata_meta_keywords', $new_meta_keywords);
	update_post_meta($post_id, 'bfa_ata_meta_description', $new_meta_description);

}}

if ( function_exists( 'add_theme_support' ) ) { // Added in 2.9

	// Since 3.4.5: WP 2.9 thumbnails support:
	add_theme_support( 'post-thumbnails' );
	if ($bfa_ata['post_thumbnail_crop'] == "Yes") 
		set_post_thumbnail_size( $bfa_ata['post_thumbnail_width'], $bfa_ata['post_thumbnail_height'], true );
	else set_post_thumbnail_size( $bfa_ata['post_thumbnail_width'], $bfa_ata['post_thumbnail_height'] );
	add_image_size( 'single-post-thumbnail', 400, 9999 ); // Permalink thumbnail size
	
	// Since 3.5.4:
	add_theme_support('automatic-feed-links');
}


// Since 3.4.7: Import/Export Settings
function bfa_import_settings_now() {
	check_ajax_referer( "import_bfa_settings" );
	$new_options = maybe_unserialize(bfa_file_get_contents($_FILES['userfile']['tmp_name']));
	update_option('bfa_new_test', $new_options);
	die();
}
// add_action ( 'wp_ajax_' + [name of "action" in jQuery.ajax, see functions/bfa_css_admin_head.php], [name of function])
add_action( 'wp_ajax_import_bfa_settings_now', 'bfa_import_settings_now' );



// Since 3.5.2: New menu system in WP 3
if (function_exists('register_nav_menus')) {
add_action( 'init', 'bfa_register_new_menus' );
	function bfa_register_new_menus() {
		register_nav_menus(
			array(
				'menu1' => __( 'Menu 1','atahualpa' ),
				'menu2' => __( 'Menu 2','atahualpa' )
			)
		);
	}
}

// Since 3.5.4: Add odd/even class to WP's post_class
add_filter ( 'post_class' , 'bfa_post_class' );
global $current_class;
$current_class = 'odd';

function bfa_post_class ( $classes ) {
	global $current_class;
	$classes[] = $current_class;
	$current_class = ($current_class == 'odd') ? 'even' : 'odd';
	return $classes;
}

// Since 3.6: Use stream wrapper instead of eval to include user code. Not used anymore since 3.6.5
class bfa_VariableStream {
    var $position;
    var $varname;

    function stream_open($path, $mode, $options, &$opened_path)
    {
        $url = parse_url($path);
        $this->varname = $url["host"];
        $this->position = 0;

        return true;
    }

    function stream_read($count)
    {
        $ret = substr($GLOBALS[$this->varname], $this->position, $count);
        $this->position += strlen($ret);
        return $ret;
    }

    function stream_write($data)
    {
        $left = substr($GLOBALS[$this->varname], 0, $this->position);
        $right = substr($GLOBALS[$this->varname], $this->position + strlen($data));
        $GLOBALS[$this->varname] = $left . $data . $right;
        $this->position += strlen($data);
        return strlen($data);
    }

    function stream_tell()
    {
        return $this->position;
    }

    function stream_eof()
    {
        return $this->position >= strlen($GLOBALS[$this->varname]);
    }

    function stream_seek($offset, $whence)
    {
        switch ($whence) {
            case SEEK_SET:
                if ($offset < strlen($GLOBALS[$this->varname]) && $offset >= 0) {
                     $this->position = $offset;
                     return true;
                } else {
                     return false;
                }
                break;

            case SEEK_CUR:
                if ($offset >= 0) {
                     $this->position += $offset;
                     return true;
                } else {
                     return false;
                }
                break;

            case SEEK_END:
                if (strlen($GLOBALS[$this->varname]) + $offset >= 0) {
                     $this->position = strlen($GLOBALS[$this->varname]) + $offset;
                     return true;
                } else {
                     return false;
                }
                break;

            default:
                return false;
        }
    }

	function stream_stat() 
	{
		return array('size' => strlen($GLOBALS[$this->varname]));
	} 

	function url_stat() 
	{
		return array();
	}

}

// Since 3.6: Register stream wrapper 'bfa'
stream_wrapper_register("bfa", "bfa_VariableStream")
    or die("Failed to register new stream protocol 'bfa'");

// Since 3.6: Make sure $GLOBALS has all values
foreach($bfa_ata as $key => $value) {
	$GLOBALS[$key] = $value;
}

// Since 3.6: New variables using newer WP functions
$templateURI = get_template_directory_uri(); 
// Since 3.7.0: Escape home_url, too
$homeURL = esc_url( home_url() );

// Since 3.6: Include Javascripts here and with wp_enqueue instead of header.php
// $isIE6 = (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 6.') !== FALSE);
 
// Since 3.7.4: Enqueue with add_action
/* function bfa_enqueue_scripts() {
	global $isIE6, $bfa_ata;
	$templateURI = get_template_directory_uri(); 

	
	if ( !is_admin() ) { 
		
		wp_enqueue_script('jquery');

		if (strpos($bfa_ata['configure_header'],'%image')!== FALSE AND $bfa_ata['header_image_javascript'] != "0" 
		AND $bfa_ata['crossslide_fade'] != "0") {
			wp_register_script('crossslide', $templateURI . '/js/jquery.cross-slide.js', array('jquery'), '0.3.2' );
			wp_enqueue_script('crossslide');
		}
	}
} */


function bfa_enqueue_scripts() {
	global $isIE6, $bfa_ata;
	$templateURI = get_template_directory_uri(); 

	if ( !is_admin() ) { 
		
		wp_enqueue_script('jquery');

		$configure_header = isset($bfa_ata['configure_header'])
			? (string) $bfa_ata['configure_header']
			: '';

		if (
			strpos($configure_header, '%image') !== false
			&& $bfa_ata['header_image_javascript'] != "0"
			&& $bfa_ata['crossslide_fade'] != "0"
		) {
			wp_register_script(
				'crossslide',
				$templateURI . '/js/jquery.cross-slide.js',
				array('jquery'),
				'0.3.2'
			);
			wp_enqueue_script('crossslide');
		}
	}
}
add_action('wp_enqueue_scripts', 'bfa_enqueue_scripts'); // For use on the Front end (ie. Theme)



// Since 3.6.1: Add ddroundies script in head this way:
function bfa_ddroundiesHead() {
	global $bfa_ata;
	echo '
<!--[if IE 6]>
<script type="text/javascript">DD_roundies.addRule("' . $bfa_ata['pngfix_selectors'] . '");</script>
<![endif]-->
';
}

// Since 3.6: Content Width
if ( ! isset( $content_width ) )
	$content_width = 640;


// Since 3.6.5: Process or don't process user included PHP code. 
function bfa_incl($option) {

	global $bfa_ata;
	
	$result = bfa_parse_widget_areas($bfa_ata[$option]);

	echo $result;
}

/*
function bfa_parse_widget_areas($content) {
				
	if ( strpos($content,'<?php bfa_widget_area') !== FALSE ) {
		$content = preg_replace_callback("/<\?php bfa_widget_area(.*?)\((.*?)'(.*?)'(.*?)\)(.*?)\?>/s","bfa_parse_widget_areas_callback",$content);
	}

	return $content; 
}	
*/
function bfa_parse_widget_areas($content) {

	$content = (string) $content;
				
	if ( strpos($content, '<?php bfa_widget_area') !== FALSE ) {
		$content = preg_replace_callback(
			"/<\?php bfa_widget_area(.*?)\((.*?)'(.*?)'(.*?)\)(.*?)\?>/s",
			"bfa_parse_widget_areas_callback",
			$content
		);
	}

	return $content; 
}


// Callback for preg_replace_callback
function bfa_parse_widget_areas_callback($matches) {

	parse_str($matches[3], $widget_options);
	
	ob_start(); 
	
		bfa_widget_area($widget_options);
		$widget_area = ob_get_contents();
		
	ob_end_clean();
	
	return $widget_area;
}

function bfa_is_pagetemplate_active($pagetemplate = '') {

	if ($pagetemplate == '') {return 0;}
	
	global $wpdb;
	$sql = "select meta_key from $wpdb->postmeta where meta_key like '_wp_page_template' and meta_value like '" . $pagetemplate . "'";
	$result = $wpdb->query($sql);
	if ($result) {
		return 1;
	} else {
		return 0;
	}
}

// add category nicenames in body and post class
	function bfa_category_id_class($classes) {
	    global $post;
	    if (is_single()) {	
	    	foreach((get_the_category($post->ID)) as $category)
	        	$classes[] = 'category-'.$category->slug;
		}
		return $classes;
	}
	add_filter('body_class', 'bfa_category_id_class');
	

/**
 * Atahualpa theme footer mod
 */
 
// Powered by Atahualpa (modified by ANV)
/*
function bfa_footer_output($footer_content) {
	global $bfa_ata;
	echo do_shortcode('[xyz-ihs snippet="Subscribe"]');
	echo do_shortcode('[spacer height="40px"]');
    $footer_content .= '
        <div class="footer-container">
        <div class="footer-left">
            <span lang="en">
                <a href="/about-this-project/policies/terms-of-use/">TERMS OF USE</a> ✶ 
                <a href="/about-this-project/policies/copyright-policy/">COPYRIGHT</a> ✶ 
                <a href="/about-this-project/policies/privacy-policy/">PRIVACY</a> ✶ 
                <a href="/contribute/upload/">UPLOAD</a> ✶ 
                <a href="/contact">CONTACT</a>
            </span>
        </div>
        <div class="footer-right">
            <a href="/index.php?tag_ID=4634" style="text-decoration: none;">
            <span lang="he" style="font-weight: normal;">&#x1FAAC;&#xFE0E; בסיעתא דארעא</span>
            </a>
        </div>
        </div>';
	return $footer_content;
}
*/


function bfa_footer_output($footer_content) {
    global $bfa_ata;

    // Render the form content via shortcode
    $form_html = do_shortcode('[xyz-ihs snippet="Subscribe"]');

    // Add a hidden container and auto-reveal script, with reserved height
    $footer_content .= '
        <div class="subscribe-block" style="margin-bottom: 2em;">
            <div id="subscribe-form-wrapper" class="subscribe-form-wrappa">
                <div id="subscribe-form-container" style="display: none;">
                    ' . $form_html . '
                </div>
            </div>
        </div>
        <script>
        document.addEventListener("DOMContentLoaded", function () {
            setTimeout(function () {
                const container = document.getElementById("subscribe-form-container");
                if (container) {
                    container.style.display = "block";
                }
            }, 1000); // 1000 milliseconds = 1 second
        });
        </script>
        ';

    // Spacer before footer content
    $footer_content .= do_shortcode('[spacer height="40px"]');

    // Footer HTML
    $footer_content .= '
        <div class="footer-container">
            <div class="footer-left">
                <span lang="en">
                    <a href="/?p=8011">TERMS OF USE</a> ✶ 
                    <a href="/?p=8016">COPYRIGHT</a> ✶ 
                    <a href="/?p=8008">PRIVACY</a> ✶ 
                    <a href="/?p=781">UPLOAD</a> ✶ 
                    <a href="/?p=28454">SUPPORT THIS PROJECT</a> ✶                     
                    <a href="/?p=76">CONTACT</a>
                </span>
            </div>
            <div class="footer-right">
                <a href="/index.php?tag_ID=4634" style="text-decoration: none;">
                    <span class="arets" lang="heb-Hebr" style="font-weight: normal;">&#x1FAAC;&#xFE0E; בסיעתא דארעא</span>
                </a>
            </div>
        </div>';

    return $footer_content;
}






/**
 * Registers an editor stylesheet for the current theme. 
 */
 
/* function wpdocs_theme_add_editor_styles() {
    $font_url = str_replace( ',', '%2C', '//fonts.googleapis.com/css?family=Lato:300,400,700' );
    add_editor_style( $font_url );
}
add_action( 'after_setup_theme', 'wpdocs_theme_add_editor_styles' );
*/	

function set_default_admin_color($user_id) {
	$args = array(
		'ID' => $user_id,
		'admin_color' => 'Coffee'
	);
	wp_update_user( $args );
}
add_action('user_register', 'set_default_admin_color');


function style_tool_bar() {
    echo '
    <style type="text/css">
	#wpadminbar {
		background: #DDDDDD;
	}
    </style>';
}
add_action( 'admin_head', 'style_tool_bar' );
add_action( 'wp_head', 'style_tool_bar' );

function remove_toolbar_items($wp_adminbar) {
  $wp_adminbar->remove_node('wpseo-menu');
}

add_action('admin_bar_menu', 'remove_toolbar_items', 999);



/**
 * AJAX Search Pro functions
 */
 
function hebrew_unvocalize( $str ) {
    // PHP 8+ safety: guarantee string
    $str = (string) $str;
	$hebrew_common_ligatures = array(
		'ײַ' => 'ײ',
		'ﬠ' => 'ע',
		'ﬡ' => 'א',
		'ﬢ' => 'ד',
		'ﬣ' => 'ה',
		'ﬤ' => 'כ',
		'ﬥ' => 'ל',
		'ﬦ' => 'ם',
		'ﬧ' => 'ר',
		'ﬨ' => 'ת',
		'שׁ' => 'ש',
		'שׂ' => 'ש',
		'שּׁ' => 'ש',
		'שּׂ' => 'ש',
		'אַ' => 'א',
		'אָ' => 'א',
		'אּ' => 'א',
		'בּ' => 'ב',
		'גּ' => 'ג',
		'דּ' => 'ד',
		'הּ' => 'ה',
		'וּ' => 'ו',
		'זּ' => 'ז',
		'טּ' => 'ט',
		'יּ' => 'י',
		'ךּ' => 'ך',
		'כּ' => 'כ',
		'לּ' => 'ל',
		'מּ' => 'מ',
		'נּ' => 'נ',
		'סּ' => 'ס',
		'ףּ' => 'ף',
		'פּ' => 'פ',
		'צּ' => 'צ',
		'קּ' => 'ק',
		'רּ' => 'ר',
		'שּ' => 'ש',
		'תּ' => 'ת',
		'וֹ' => 'ו',
		'בֿ' => 'ב',
		'כֿ' => 'כ',
		'פֿ' => 'פ',
		'ﭏ' => 'אל'
	);
	$new_kw = trim( preg_replace('/\p{Mn}/u', '', $str) );
	foreach( $hebrew_common_ligatures as $word1 => $word2 ) {
		$new_kw = trim(str_replace( $word1, $word2, $new_kw ));
	}
	return $new_kw;
}

function asp_normalize_punctuation($str) {
    // Ensure string
    $str = (string) $str;

    // Remove common punctuation characters
    $str = preg_replace('/[-\'’"“”_.,:;!?(){}\[\]\/\\\\]/u', '', $str);

    return $str;
}

//remove diacritics from search index and search queries
add_filter('asp_indexing_keywords', 'diacritic_asp_indexing_keywords', 10, 1);
function diacritic_asp_indexing_keywords($keywords) {
	$new_kw_arr = array();

	foreach ($keywords as $keyword => $arr) {

		$new_kw = hebrew_unvocalize($keyword);
		$new_kw = asp_normalize_punctuation($new_kw);

		if ($new_kw != '') {
			if (!isset($new_kw_arr[$new_kw])) {
				$new_kw_arr[$new_kw] = array($new_kw, 1);
			} else {
				$new_kw_arr[$new_kw][1]++;
			}
		}
	}

	return $new_kw_arr;
}

add_filter('asp_search_phrase_after_cleaning', 'asp_clean_search_phrase', 10, 1);
function asp_clean_search_phrase($str) {

    $str = hebrew_unvocalize($str);
    $str = asp_normalize_punctuation($str);

    return $str;
}

// Show folder and tag icons before category and tag results in Ajax Search Pro
$GLOBALS['disable_new_status_in_titles'] = false;

add_filter('asp_results', 'asp_display_tax_name_in_results');
function asp_display_tax_name_in_results($results) {
    foreach ($results as $k => &$r) {
        if (isset($r->content_type)) {
            // Check for taxonomy terms
            if ($r->content_type == 'term') {
                $taxonomy = get_taxonomy($r->taxonomy);
                if ($taxonomy && !is_wp_error($taxonomy)) {
                    switch ($r->taxonomy) {
                        case 'category':
                            $name = "&#x1F4C1;"; // Folder emoji
                            break;
                        case 'post_tag':
                            $name = "&#x1F516;"; // Bookmark emoji
                            break;
                        default:
                            $name = esc_html($taxonomy->labels->name); // Default case for other taxonomies
                    }
                    $r->title = $name . " " . esc_html($r->title);
                }
            }
            // Check for author pages
            elseif ($r->content_type == 'user' || isset($r->user_id)) {
                $author_name = get_the_author_meta('display_name', $r->id);
                $r->title = "&#x270D; " . esc_html($author_name); // Writing hand emoji
            }
        }
    }
    return $results;
}


//scrolling fix for ajax search pro
add_action('wp_footer', 'asp_remove_wheels');
function asp_remove_wheels() {
	?>
	<script>
	jQuery(function($){
		$(".asp_main_container").on("asp_results_show", function(event, id, instance, phrase) { 
		  $('.asp_r .results').off('mousewheel');
		});
		$('.asp_r .results').off('mousewheel');
	});
	</script>
	<?php
}


/**
 * Contact Form Functions
 */
 
// for adding referer page as a hidden field in CF7
function getRefererPage( $form_tag ) {
    if ( isset( $form_tag['name'] ) && $form_tag['name'] === 'referer-page' ) {
        $referrer = $_SERVER['HTTP_REFERER'] ?? 'No Referrer';
        $form_tag['values'][] = esc_html( $referrer );
    }
    return $form_tag;
}

if ( ! is_admin() ) {
    add_filter( 'wpcf7_form_tag', 'getRefererPage' );
}



/**
 * Gutenberg Block function
 */
 
//Remove Gutenberg Block Library CSS from loading on the frontend
function smartwp_remove_wp_block_library_css(){
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );
    wp_dequeue_style( 'wc-block-style' ); // Remove WooCommerce block CSS
} 
add_action( 'wp_enqueue_scripts', 'smartwp_remove_wp_block_library_css', 100 );


/** 
* Dynamically increase allowed memory limit for export. 
* 
*/ 
function my_export_wp() { 
  ini_set('memory_limit', '4096M'); 
} 
add_action('export_wp', 'my_export_wp');





// Remove dashicons in frontend for unauthenticated users
add_action( 'wp_enqueue_scripts', 'bs_dequeue_dashicons' );
function bs_dequeue_dashicons() {
    if ( ! is_user_logged_in() ) {
        wp_deregister_style( 'dashicons' );
    }
}

/**
 * YARRP function
 */
 
// Remove YARRP Thumbnails
add_filter( 'yarpp_add_image_size', '__return_false' );


/**
 * Function for modifying how category pages display subcategories.
 * Check if given term has child terms
 *
 * @param Integer $term_id
 * @param String $taxonomy
 *
 * @return Boolean
 */
function has_term_have_children( $term_id = '', $taxonomy = 'category' )
{
    // Check if we have a term value, if not, return false
    if ( !$term_id ) 
        return false;

    // Get term children
    // $term_children = get_term_children( filter_var( $term_id, FILTER_VALIDATE_INT ), filter_var( $taxonomy, FILTER_SANITIZE_STRING ) );

    $term_children = get_term_children(
        (int) $term_id,
        sanitize_key( $taxonomy )
    );

    // Return false if we have an empty array or WP_Error object
    if ( empty( $term_children ) || is_wp_error( $term_children ) )
    return false;

    return true;
}



// Export Post Data in JSON format 
function export_json() {
    if (!isset($_GET['post_id'])) {
        wp_die('No post ID provided');
    }

    $post_id = intval($_GET['post_id']);
    $post = get_post($post_id);
    if (!$post) {
        wp_die('Post not found');
    }

    if (function_exists('get_coauthors')) {
        $coauthors = get_coauthors($post_id);
        $coauthors_details = array_map(function($coauthor) {
            return array(
                'name' => $coauthor->display_name,
                'bio' => get_the_author_meta('description', $coauthor->ID),
                'website' => get_the_author_meta('user_url', $coauthor->ID),
                'avatar' => get_avatar_url($coauthor->ID),
                'profile_link' => home_url('/profile/' . $coauthor->user_nicename)
            );
        }, $coauthors);
    } else {
        $author = get_userdata($post->post_author);
        $coauthors_details = array(
            array(
                'name' => $author->display_name,
                'bio' => get_the_author_meta('description', $author->ID),
                'website' => get_the_author_meta('user_url', $author->ID),
                'avatar' => get_avatar_url($author->ID),
                'profile_link' => home_url('/profile/' . $author->user_nicename)
            )
        );
    }

    $custom_fields = get_post_custom($post_id);
    $custom_fields_filtered = array();
    $allowed_custom_fields = array('open_content_license', '_yoast_wpseo_primary_category', '_thumbnail_id', 'date_src_start', 'date_src_end', 'languages_meta', 'scripts_meta');

    foreach ($allowed_custom_fields as $field) {
        if (isset($custom_fields[$field])) {
            $custom_fields_filtered[$field] = $custom_fields[$field];
        }
    }

    $featured_image_id = get_post_thumbnail_id($post_id);
    $featured_image = array();
    if ($featured_image_id) {
        $image_src = wp_get_attachment_image_src($featured_image_id, 'full');
        $featured_image = array(
            'url' => $image_src[0],
            'title' => get_the_title($featured_image_id),
            'caption' => wp_get_attachment_caption($featured_image_id)
        );
    }

    $data = array(
        'post_id' => $post_id,
        'title' => $post->post_title,
        'author' => get_the_author_meta('display_name', $post->post_author),
        'coauthors' => $coauthors_details,
        'date' => get_the_date('', $post_id),
        'last_updated' => get_the_modified_date('', $post_id),
        'excerpt' => get_the_excerpt($post_id),
        'content' => apply_filters('the_content', $post->post_content),
        'categories' => wp_get_post_categories($post_id, array('fields' => 'names')),
        'tags' => wp_get_post_tags($post_id, array('fields' => 'names')),
        'custom_fields' => $custom_fields_filtered,
        'featured_image' => $featured_image,
        'source_link' => home_url('/?p=' . $post_id),
        'permalink' => get_permalink($post_id),
        'slug' => $post->post_name // Add this line to include the slug
    );

    $post_slug = $post->post_name;
    $filename = $post_slug . '.json';

    header('Content-Type: application/json; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

add_action('admin_post_export_json', 'export_json');
add_action('admin_post_nopriv_export_json', 'export_json');



// Export Data to XML format
function export_xml() {
    if (!isset($_GET['post_id'])) {
        wp_die('No post ID provided');
    }

    $post_id = intval($_GET['post_id']);
    $post = get_post($post_id);
    if (!$post) {
        wp_die('Post not found');
    }

    if (function_exists('get_coauthors')) {
        $coauthors = get_coauthors($post_id);
        $coauthors_details = array_map(function($coauthor) {
            return array(
                'name' => $coauthor->display_name,
                'bio' => get_the_author_meta('description', $coauthor->ID),
                'website' => get_the_author_meta('user_url', $coauthor->ID),
                'avatar' => get_avatar_url($coauthor->ID),
                'profile_link' => home_url('/profile/' . $coauthor->user_nicename)
            );
        }, $coauthors);
    } else {
        $author = get_userdata($post->post_author);
        $coauthors_details = array(
            array(
                'name' => $author->display_name,
                'bio' => get_the_author_meta('description', $author->ID),
                'website' => get_the_author_meta('user_url', $author->ID),
                'avatar' => get_avatar_url($author->ID),
                'profile_link' => home_url('/profile/' . $author->user_nicename)
            )
        );
    }

    $custom_fields = get_post_custom($post_id);
    $custom_fields_filtered = array();
    $allowed_custom_fields = array('open_content_license', '_yoast_wpseo_primary_category', '_thumbnail_id', 'date_src_start', 'date_src_end', 'languages_meta', 'scripts_meta');

    foreach ($allowed_custom_fields as $field) {
        if (isset($custom_fields[$field])) {
            $custom_fields_filtered[$field] = $custom_fields[$field];
        }
    }

    $featured_image_id = get_post_thumbnail_id($post_id);
    $featured_image = array();
    if ($featured_image_id) {
        $image_src = wp_get_attachment_image_src($featured_image_id, 'full');
        $featured_image = array(
            'url' => $image_src[0],
            'title' => get_the_title($featured_image_id),
            'caption' => wp_get_attachment_caption($featured_image_id)
        );
    }

    $data = array(
        'post_id' => $post_id,
        'title' => $post->post_title,
        'author' => get_the_author_meta('display_name', $post->post_author),
        'coauthors' => $coauthors_details,
        'date' => get_the_date('', $post_id),
        'last_updated' => get_the_modified_date('', $post_id),
        'excerpt' => get_the_excerpt($post_id),
        'content' => apply_filters('the_content', $post->post_content),
        'categories' => wp_get_post_categories($post_id, array('fields' => 'names')),
        'tags' => wp_get_post_tags($post_id, array('fields' => 'names')),
        'custom_fields' => $custom_fields_filtered,
        'featured_image' => $featured_image,
        'source_link' => home_url('/?p=' . $post_id),
        'permalink' => get_permalink($post_id) 
    );

    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->formatOutput = true;

    $root = $dom->createElement('post');
    $dom->appendChild($root);

    $root->appendChild($dom->createElement('title', htmlspecialchars($data['title'])));
    $root->appendChild($dom->createElement('author', htmlspecialchars($data['author'])));

    $coauthors_xml = $dom->createElement('coauthors');
    $root->appendChild($coauthors_xml);
    foreach ($data['coauthors'] as $coauthor) {
        $coauthor_xml = $dom->createElement('coauthor');
        $coauthors_xml->appendChild($coauthor_xml);
        $coauthor_xml->appendChild($dom->createElement('name', htmlspecialchars($coauthor['name'])));
        $coauthor_xml->appendChild($dom->createElement('bio', htmlspecialchars($coauthor['bio'])));
        $coauthor_xml->appendChild($dom->createElement('website', htmlspecialchars($coauthor['website'])));
        $coauthor_xml->appendChild($dom->createElement('avatar', htmlspecialchars($coauthor['avatar'])));
        $coauthor_xml->appendChild($dom->createElement('profile_link', htmlspecialchars($coauthor['profile_link'])));
    }
    $root->appendChild($dom->createElement('date', htmlspecialchars($data['date'])));
    $root->appendChild($dom->createElement('last_updated', htmlspecialchars($data['last_updated'])));
    $root->appendChild($dom->createElement('excerpt', htmlspecialchars($data['excerpt'])));

    $content_node = $dom->createElement('content');
    $content_cdata = $dom->createCDATASection($data['content']);
    $content_node->appendChild($content_cdata);
    $root->appendChild($content_node);

    $categories_xml = $dom->createElement('categories');
    $root->appendChild($categories_xml);
    foreach ($data['categories'] as $category) {
        $categories_xml->appendChild($dom->createElement('category', htmlspecialchars($category)));
    }

    $tags_xml = $dom->createElement('tags');
    $root->appendChild($tags_xml);
    foreach ($data['tags'] as $tag) {
        $tags_xml->appendChild($dom->createElement('tag', htmlspecialchars($tag)));
    }

    $custom_fields_xml = $dom->createElement('custom_fields');
    $root->appendChild($custom_fields_xml);
    foreach ($data['custom_fields'] as $key => $value) {
        $custom_fields_xml->appendChild($dom->createElement($key, htmlspecialchars(is_array($value) ? implode(',', $value) : $value)));
    }

    $featured_image_xml = $dom->createElement('featured_image');
    $root->appendChild($featured_image_xml);
    if (!empty($data['featured_image'])) {
        $featured_image_xml->appendChild($dom->createElement('url', htmlspecialchars($data['featured_image']['url'])));
        $featured_image_xml->appendChild($dom->createElement('title', htmlspecialchars($data['featured_image']['title'])));
        $featured_image_xml->appendChild($dom->createElement('caption', htmlspecialchars($data['featured_image']['caption'])));
    }

    $root->appendChild($dom->createElement('permalink', htmlspecialchars($data['permalink'])));
    $root->appendChild($dom->createElement('source_link', htmlspecialchars($data['source_link'])));

    $post_slug = $post->post_name;
    $filename = $post_slug . '.xml';

    header('Content-Type: application/xml; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $dom->saveXML();
    exit;
}

add_action('admin_post_export_xml', 'export_xml');
add_action('admin_post_nopriv_export_xml', 'export_xml');



// Export data to HTML format
function export_html() {
    if (!isset($_GET['post_id'])) {
        wp_die('No post ID provided');
    }

    $post_id = intval($_GET['post_id']);
    $post = get_post($post_id);
    if (!$post) {
        wp_die('Post not found');
    }

    if (function_exists('get_coauthors')) {
        $coauthors = get_coauthors($post_id);
        $coauthors_details = array_map(function($coauthor) {
            return array(
                'name' => $coauthor->display_name,
                'bio' => get_the_author_meta('description', $coauthor->ID),
                'website' => get_the_author_meta('user_url', $coauthor->ID),
                'avatar' => get_avatar_url($coauthor->ID),
                'profile_link' => home_url('/profile/' . $coauthor->user_nicename)
            );
        }, $coauthors);
    } else {
        $author = get_userdata($post->post_author);
        $coauthors_details = array(
            array(
                'name' => $author->display_name,
                'bio' => get_the_author_meta('description', $author->ID),
                'website' => get_the_author_meta('user_url', $author->ID),
                'avatar' => get_avatar_url($author->ID),
                'profile_link' => home_url('/profile/' . $author->user_nicename)
            )
        );
    }

    $custom_fields = get_post_custom($post_id);
    $custom_fields_filtered = array();
    $allowed_custom_fields = array('open_content_license', 'date_src_start', 'date_src_end', 'languages_meta', 'scripts_meta');

    foreach ($allowed_custom_fields as $field) {
        if (isset($custom_fields[$field])) {
            $custom_fields_filtered[$field] = $custom_fields[$field];
        }
    }

    $featured_image_id = get_post_thumbnail_id($post_id);
    $featured_image = array();
    if ($featured_image_id) {
        $image_src = wp_get_attachment_image_src($featured_image_id, 'full');
        $featured_image = array(
            'url' => $image_src[0],
            'title' => get_the_title($featured_image_id),
            'caption' => wp_get_attachment_caption($featured_image_id)
        );
    }

    $source_link = home_url('/?p=' . $post_id);

    // Process content
    $content = $post->post_content;

    // Apply content filters
    $content = apply_filters('the_content', $content);
    
    // Replace all HTML entities with their reserved characters
    $content = htmlspecialchars_decode($content, ENT_QUOTES | ENT_HTML5);

    // Remove [expander_maker] shortcodes and content between them
    $content = preg_replace('/\[expander_.*?_maker\]/s', '', $content);
    
    // Add max-height to all images
    $content = preg_replace('/<img (.*?)>/', '<img $1 style="max-height:250px;">', $content);

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo htmlspecialchars_decode($post->post_title); ?> • the Open Siddur Project</title>
    </head>
    <body>
        <h1><?php echo htmlspecialchars_decode($post->post_title); ?></h1>
        <p><strong>Source Link:</strong> <a href="<?php echo htmlspecialchars_decode($source_link); ?>"><?php echo htmlspecialchars_decode($source_link); ?></a></p>
        <?php foreach ($custom_fields_filtered as $key => $value): ?>
            <strong></strong><?php echo htmlspecialchars_decode($key); ?>:</strong> <?php echo htmlspecialchars_decode(is_array($value) ? implode(', ', $value) : $value); ?>
        <?php endforeach; ?>
        <p><strong>Date:</strong> <?php echo htmlspecialchars_decode(get_the_date('', $post_id)); ?></p>
        <p><strong>Last Updated:</strong> <?php echo htmlspecialchars_decode(get_the_modified_date('', $post_id)); ?></p>
        <p><strong>Categories:</strong> <?php echo htmlspecialchars_decode(implode(', ', wp_get_post_categories($post_id, array('fields' => 'names')))); ?></p>
        <p><strong>Tags:</strong> <?php echo htmlspecialchars_decode(implode(', ', wp_get_post_tags($post_id, array('fields' => 'names')))); ?></p>
        <p><strong>Excerpt:</strong> <?php echo htmlspecialchars_decode(get_the_excerpt($post_id)); ?></p>
        <hr />
        <div><strong>Content:</strong> <?php echo htmlspecialchars_decode($content); ?></div>
        </hr />
        <p><strong>Contributor:</strong> <?php echo htmlspecialchars_decode(get_the_author_meta('display_name', $post->post_author)); ?></p>
        <p><strong>Co-authors:</strong></p>
        <ul>
        <?php foreach ($coauthors_details as $coauthor): ?>
            <li>
                <img src="<?php echo htmlspecialchars_decode($coauthor['avatar']); ?>" alt="<?php echo htmlspecialchars_decode($coauthor['name']); ?>" style="max-height:96px;"><br>
                <strong>Name:</strong> <?php echo htmlspecialchars_decode($coauthor['name']); ?><br>
                <strong>Bio:</strong> <?php echo htmlspecialchars_decode($coauthor['bio']); ?><br>
                <strong>Website:</strong> <a href="<?php echo htmlspecialchars_decode($coauthor['website']); ?>"><?php echo htmlspecialchars_decode($coauthor['website']); ?></a><br>
                <strong>Profile Link:</strong> <a href="<?php echo htmlspecialchars_decode($coauthor['profile_link']); ?>"><?php echo htmlspecialchars_decode($coauthor['profile_link']); ?></a>
            </li>
        <?php endforeach; ?>
        </ul>
        <?php if (!empty($featured_image)): ?>
            <p><strong>Featured Image:</strong><br>
                <img src="<?php echo htmlspecialchars_decode($featured_image['url']); ?>" alt="<?php echo htmlspecialchars_decode($featured_image['title']); ?>" style="max-height:250px;"><br>
                <strong>Title:</strong> <?php echo htmlspecialchars_decode($featured_image['title']); ?><br>
                <strong>Caption:</strong> <?php echo htmlspecialchars_decode($featured_image['caption']); ?>
            </p>
        <?php endif; ?>
    </body>
    </html>
    <?php
    $html_content = ob_get_clean();

    $post_slug = $post->post_name;
    $filename = $post_slug . '.html';

    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $html_content;
    exit;
}

add_action('admin_post_export_html', 'export_html');
add_action('admin_post_nopriv_export_html', 'export_html');


// Export data to ODT file (essentially the same as HTML but more reliable and straightforward than generating via PHPWord)
function export_odt() {
    if (!isset($_GET['post_id'])) {
        wp_die('No post ID provided');
    }

    $post_id = intval($_GET['post_id']);
    $post = get_post($post_id);
    if (!$post) {
        wp_die('Post not found');
    }

    if (function_exists('get_coauthors')) {
        $coauthors = get_coauthors($post_id);
        $coauthors_details = array_map(function($coauthor) {
            return array(
                'name' => $coauthor->display_name,
                'bio' => get_the_author_meta('description', $coauthor->ID),
                'website' => get_the_author_meta('user_url', $coauthor->ID),
                'avatar' => get_avatar_url($coauthor->ID),
                'profile_link' => home_url('/profile/' . $coauthor->user_nicename)
            );
        }, $coauthors);
    } else {
        $author = get_userdata($post->post_author);
        $coauthors_details = array(
            array(
                'name' => $author->display_name,
                'bio' => get_the_author_meta('description', $author->ID),
                'website' => get_the_author_meta('user_url', $author->ID),
                'avatar' => get_avatar_url($author->ID),
                'profile_link' => home_url('/profile/' . $author->user_nicename)
            )
        );
    }

    $custom_fields = get_post_custom($post_id);
    $custom_fields_filtered = array();
    $allowed_custom_fields = array('open_content_license', 'date_src_start', 'date_src_end', 'languages_meta', 'scripts_meta');

    foreach ($allowed_custom_fields as $field) {
        if (isset($custom_fields[$field])) {
            $custom_fields_filtered[$field] = $custom_fields[$field];
        }
    }

    $featured_image_id = get_post_thumbnail_id($post_id);
    $featured_image = array();
    if ($featured_image_id) {
        $image_src = wp_get_attachment_image_src($featured_image_id, 'full');
        $featured_image = array(
            'url' => $image_src[0],
            'title' => get_the_title($featured_image_id),
            'caption' => wp_get_attachment_caption($featured_image_id)
        );
    }

    $source_link = home_url('/?p=' . $post_id);

    // Process content
    $content = $post->post_content;

    // Apply content filters
    $content = apply_filters('the_content', $content);
    
    // Replace all HTML entities with their reserved characters
    $content = htmlspecialchars_decode($content, ENT_QUOTES | ENT_HTML5);

    // Remove [expander_maker] shortcodes and content between them
    $content = preg_replace('/\[expander_.*?_maker\]/s', '', $content);
    
    // Add max-height to all images
    $content = preg_replace('/<img (.*?)>/', '<img $1 style="max-height:250px;">', $content);

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo htmlspecialchars_decode($post->post_title); ?> • the Open Siddur Project</title>
    </head>
    <body>
        <h1><?php echo htmlspecialchars_decode($post->post_title); ?></h1>
        <p><strong>Source Link:</strong> <a href="<?php echo htmlspecialchars_decode($source_link); ?>"><?php echo htmlspecialchars_decode($source_link); ?></a></p>
        <?php foreach ($custom_fields_filtered as $key => $value): ?>
            <strong></strong><?php echo htmlspecialchars_decode($key); ?>:</strong> <?php echo htmlspecialchars_decode(is_array($value) ? implode(', ', $value) : $value); ?>
        <?php endforeach; ?>
        <p><strong>Date:</strong> <?php echo htmlspecialchars_decode(get_the_date('', $post_id)); ?></p>
        <p><strong>Last Updated:</strong> <?php echo htmlspecialchars_decode(get_the_modified_date('', $post_id)); ?></p>
        <p><strong>Categories:</strong> <?php echo htmlspecialchars_decode(implode(', ', wp_get_post_categories($post_id, array('fields' => 'names')))); ?></p>
        <p><strong>Tags:</strong> <?php echo htmlspecialchars_decode(implode(', ', wp_get_post_tags($post_id, array('fields' => 'names')))); ?></p>
        <p><strong>Excerpt:</strong> <?php echo htmlspecialchars_decode(get_the_excerpt($post_id)); ?></p>
        <hr />
        <div><strong>Content:</strong> <?php echo htmlspecialchars_decode($content); ?></div>
        </hr />
        <p><strong>Contributor:</strong> <?php echo htmlspecialchars_decode(get_the_author_meta('display_name', $post->post_author)); ?></p>
        <p><strong>Co-authors:</strong></p>
        <ul>
        <?php foreach ($coauthors_details as $coauthor): ?>
            <li>
                <img src="<?php echo htmlspecialchars_decode($coauthor['avatar']); ?>" alt="<?php echo htmlspecialchars_decode($coauthor['name']); ?>" style="max-height:150px; width: auto;"><br>
                <strong>Name:</strong> <?php echo htmlspecialchars_decode($coauthor['name']); ?><br>
                <strong>Bio:</strong> <?php echo htmlspecialchars_decode($coauthor['bio']); ?><br>
                <strong>Website:</strong> <a href="<?php echo htmlspecialchars_decode($coauthor['website']); ?>"><?php echo htmlspecialchars_decode($coauthor['website']); ?></a><br>
                <strong>Profile Link:</strong> <a href="<?php echo htmlspecialchars_decode($coauthor['profile_link']); ?>"><?php echo htmlspecialchars_decode($coauthor['profile_link']); ?></a>
            </li>
        <?php endforeach; ?>
        </ul>
        <?php if (!empty($featured_image)): ?>
            <p><strong>Featured Image:</strong><br>
                <img src="<?php echo htmlspecialchars_decode($featured_image['url']); ?>" alt="<?php echo htmlspecialchars_decode($featured_image['title']); ?>" style="max-height:250px;"><br>
                <strong>Title:</strong> <?php echo htmlspecialchars_decode($featured_image['title']); ?><br>
                <strong>Caption:</strong> <?php echo htmlspecialchars_decode($featured_image['caption']); ?>
            </p>
        <?php endif; ?>
    </body>
    </html>
    <?php
    $html_content = ob_get_clean();

    $post_slug = $post->post_name;
    $filename = $post_slug . '.odt';

    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $html_content;
    exit;
}

add_action('admin_post_export_odt', 'export_odt');
add_action('admin_post_nopriv_export_odt', 'export_odt');


// Add Dublin Core Meta Element Tags to the Post Header
function add_dublin_core_meta_tags() {
    if (is_single()) {
        global $post;

        // Get the metadata
        $post_id = $post->ID;
        $identifier = 'https://opensiddur.org/?p=' . $post_id;
        $title = get_the_title($post_id);
        $categories = get_the_category($post_id);
        $tags = get_the_tags($post_id);
        $language = get_bloginfo('language'); // Assuming default language
        $date = get_the_date('Y-m-d', $post_id);
        $description = get_the_excerpt($post_id);
        $source = $identifier; // Assuming source is the same as identifier
        $type = 'Text';
        $publisher = 'The Open Siddur Project';
        $creator = get_the_author_meta('display_name', $post->post_author);
        $contributors = [];
        
        if (function_exists('get_coauthors')) {
            $coauthors = get_coauthors($post_id);
            foreach ($coauthors as $coauthor) {
                if ($coauthor->ID != $post->post_author) {
                    $contributors[] = $coauthor->display_name;
                }
            }
        }
        
        $rights = 'https://opensiddur.org/copyright-policy/';
        $rightsholder = get_the_author_meta('display_name', $post->post_author);

        // Fetch and filter custom fields
        $custom_fields = get_post_custom($post_id);
        $license = '';
        if (isset($custom_fields['open_content_license'][0])) {
            // Extract URL from the custom field HTML
            $license_html = $custom_fields['open_content_license'][0];
            $license_url = extract_license_url($license_html);
            if ($license_url) {
                $license = $license_url;
            }
        }

        // Output the meta tags
        echo '<meta name="dc.identifier" content="' . esc_url($identifier) . '" />' . "\n";
        echo '<meta name="dc.title" content="' . esc_attr($title) . '" />' . "\n";
        
        if ($categories) {
            foreach ($categories as $category) {
                echo '<meta name="dc.subject" content="' . esc_attr($category->name) . '" />' . "\n";
            }
        }
        
        if ($tags) {
            foreach ($tags as $tag) {
                echo '<meta name="dc.subject" content="' . esc_attr($tag->name) . '" />' . "\n";
            }
        }
        
        echo '<meta name="dc.language" content="' . esc_attr($language) . '" />' . "\n";
        echo '<meta name="dc.date" content="' . esc_attr($date) . '" />' . "\n";
        echo '<meta name="dc.description" content="' . esc_attr($description) . '" />' . "\n";
        echo '<meta name="dc.source" content="' . esc_url($source) . '" />' . "\n";
        echo '<meta name="dc.type" content="' . esc_attr($type) . '" />' . "\n";
        echo '<meta name="dc.publisher" content="' . esc_attr($publisher) . '" />' . "\n";
        echo '<meta name="dc.creator" content="' . esc_attr($creator) . '" />' . "\n";
        
        if ($contributors) {
            foreach ($contributors as $contributor) {
                echo '<meta name="dc.contributor" content="' . esc_attr($contributor) . '" />' . "\n";
            }
        }
        
        echo '<meta name="dc.rights" content="' . esc_url($rights) . '" />' . "\n";
        echo '<meta name="dc.rightsholder" content="' . esc_attr($rightsholder) . '" />' . "\n";
        
        if ($license) {
            echo '<meta name="dc.license" content="' . esc_url($license) . '" />' . "\n";
        }
    }
}
add_action('wp_head', 'add_dublin_core_meta_tags');

// Function to extract URL from HTML anchor tag
function extract_license_url($html) {
    if (preg_match('/<a\s+href=[\'"]([^\'"]+)[\'"]/', $html, $matches)) {
        return $matches[1];
    }
    return false;
}


/**
 * Get category image URL with fallback for both Pro and Free versions of the plugin.
 *
 * @param int $term_id The term ID for the category.
 * @param string $size The desired image size (e.g., 'thumbnail', 'medium', 'full').
 * @return string The image URL or an empty string if not found.
 */
function custom_get_category_image( $term_id, $size = 'full' ) {
    // Check if the Pro function exists
    if ( function_exists( 'pciwgas_pro_term_image' ) ) {
        return pciwgas_pro_term_image( $term_id, $size );
    }

    // Fallback to the Free function
    if ( function_exists( 'pciwgas_term_image' ) ) {
        return pciwgas_term_image( $term_id, $size );
    }

    // No function available
    return '';
}






// Function to export all post and page IDs
function export_all_ids() {
    $post_ids = get_posts(array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ));

    $page_ids = get_posts(array(
        'post_type' => 'page',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ));

    wp_send_json_success(array('posts' => $post_ids, 'pages' => $page_ids));
}

add_action('admin_post_export_all_ids', 'export_all_ids');
add_action('admin_post_nopriv_export_all_ids', 'export_all_ids');



// Function to get category image
function get_category_image($category_id) {
    $image_data = array(
        'url' => '',
        'title' => '',
        'caption' => ''
    );

    // Use the new custom_get_category_image function
    $pciwgas_image_url = custom_get_category_image($category_id, 'full');
    if ($pciwgas_image_url) {
        $image_data['url'] = $pciwgas_image_url;

        // Get the attachment ID from the URL
        $attachment_id = attachment_url_to_postid($pciwgas_image_url);
        if ($attachment_id) {
            $image_data['title'] = get_the_title($attachment_id);
            $image_data['caption'] = wp_get_attachment_caption($attachment_id);
        }
    }

    return $image_data;
}



// Function to get category data with additional fields, including hierarchical ID
function get_category_data($category, $hierarchical_prefix = '') {
    $category_id = $category->term_id;
    $subcategories = get_categories(array('parent' => $category_id, 'hide_empty' => false));

    // Generate a hierarchical ID based on term order and the hierarchical prefix
    $term_order = (int) $category->term_order; // Correctly fetching term_order directly
    $hierarchical_id = $hierarchical_prefix ? "$hierarchical_prefix" : (string)$term_order;

    // Fetch only post IDs assigned directly to this category (exclude subcategories)
    $posts = get_posts(array(
        'numberposts' => -1,
        'post_status' => 'publish',
        'fields' => 'ids', // Only return post IDs
        'tax_query' => array(
            array(
                'taxonomy' => 'category',
                'field' => 'term_id',
                'terms' => $category_id,
                'include_children' => false, // Exclude posts from child categories
            ),
        ),
    ));

    // Debug log to verify post count and posts retrieved
    //if (defined('WP_DEBUG') && WP_DEBUG) {
      //  error_log("Generating data for Category ID {$category_id}: Found " . count($posts) . " posts.");
    //}

    // Determine the ancestor_set_id by checking parent categories for the special mark
    $ancestor_set_id = null;

    // Only assign ancestor_set_id if this is a terminal category (subcategory_count = 0)
/*    if (count($subcategories) === 0) {
        $parent_id = $category->parent;
        while ($parent_id) {
            $parent_category = get_category($parent_id);
            if (strpos($parent_category->name, '◆') !== false) {
                $ancestor_set_id = $parent_category->term_id;
                break;
            }
            $parent_id = $parent_category->parent; // Move up the hierarchy
        }
    }
*/

// Only assign ancestor_set_id if this is a terminal category (subcategory_count = 0)
if (count($subcategories) === 0) {
    $parent_id = $category->parent;
    while ($parent_id) {
        $parent_category = get_category($parent_id);

        if (
            $parent_category &&
            ! is_wp_error($parent_category) &&
            strpos((string) $parent_category->name, '◆') !== false
        ) {
            $ancestor_set_id = $parent_category->term_id;
            break;
        }

        $parent_id = $parent_category ? $parent_category->parent : 0;
    }
}
    
    
    return array(
        'name' => $category->name,
        'id' => $category_id,
        'stub' => $category->slug,
        'description' => $category->description,
        'featured_image' => get_category_image($category_id),
        'permalink' => get_category_link($category_id),
        'category_page_link' => home_url('/index.php?cat=' . $category_id),
        'subcategory_count' => count($subcategories),
        'subcategories' => wp_list_pluck($subcategories, 'term_id'),
        'parent_id' => $category->parent,
        'post_count' => count($posts),
        'post_ids' => $posts, // Now this contains only the post IDs
        'term_order' => $term_order, // Correctly fetching term_order directly from $category
        'hierarchical_id' => $hierarchical_id, // Add the hierarchical ID here
        'ancestor_set_id' => $ancestor_set_id, // Set to the marked ancestor ID, or null
    );
}

// Recursive function to gather categories by hierarchy and term order, without nesting
function gather_categories_hierarchically($parent_id = 0, &$categories_data = [], $hierarchical_prefix = '') {
    // Fetch categories with the specified parent and order by term_order
    $categories = get_categories(array(
        'parent' => $parent_id,
        'hide_empty' => false,
        'orderby' => 'term_order',
        'order' => 'ASC',
    ));

    foreach ($categories as $category) {
        // Build the hierarchical ID based on the current level's prefix and term_order
        $new_hierarchical_id = $hierarchical_prefix ? "$hierarchical_prefix." . $category->term_order : (string)$category->term_order;

        // Gather data for the current category using get_category_data
        $category_data = get_category_data($category, $new_hierarchical_id);
        
        // Add the category data to the list
        $categories_data[] = $category_data;

        // Recursively gather data for subcategories with the updated hierarchical ID prefix
        gather_categories_hierarchically($category->term_id, $categories_data, $new_hierarchical_id);
    }

    return $categories_data;
}

// Main function to generate categories.json with hierarchical ordering and flat structure
function generate_categories_json() {
    $categories_data = gather_categories_hierarchically();

    // Index categories by ID for easier access later
    $categories_by_id = [];
    foreach ($categories_data as $category) {
        $categories_by_id[$category['id']] = $category;
    }

    // Identify terminal categories
    $terminal_categories = array_filter($categories_data, function($cat) {
        return $cat['subcategory_count'] === 0;
    });

    // Build a map of stub base => list of category IDs (group by base slug)
    $stub_groups = [];
    $suffixes = ['readings', 'mahzorim', 'siddurim', 'seder', 'haggadot']; // Define suffixes

    foreach ($terminal_categories as $cat) {
        $stub = $cat['stub'];
        $base_stub = $stub;

        foreach ($suffixes as $suffix) {
            if (preg_match('/-' . preg_quote($suffix, '/') . '$/', $stub)) {
                $base_stub = preg_replace('/-' . preg_quote($suffix, '/') . '$/', '', $stub);
                break;
            }
        }

        $stub_groups[$base_stub][] = $cat['id'];
    }

    // Build a complementary ID map for each terminal category
    $complementary_map = [];
    foreach ($stub_groups as $base_stub => $ids) {
        foreach ($ids as $id) {
            $complementary_map[$id] = array_values(array_diff($ids, [$id]));
        }
    }

    // Assign complementary_cat_id back into categories_by_id
    foreach ($complementary_map as $id => $related_ids) {
        if (isset($categories_by_id[$id])) {
            $categories_by_id[$id]['complementary_cat_id'] = $related_ids;
        }
    }

    // For non-terminal categories, ensure complementary_cat_id is at least an empty array
    foreach ($categories_by_id as $id => &$cat) {
        if (!isset($cat['complementary_cat_id'])) {
            $cat['complementary_cat_id'] = [];
        }
    }
    unset($cat);

    // Final flat array of categories
    $categories_data = array_values($categories_by_id);

    // Write JSON with hash check
    $json_data = json_encode($categories_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'categories.json';
    $hash_file_path = trailingslashit($upload_dir['basedir']) . 'categories_hash.txt';
    $current_hash = hash('sha256', $json_data);

    if (file_exists($hash_file_path)) {
        $saved_hash = file_get_contents($hash_file_path);
        if ($current_hash === $saved_hash) {
            return;
        }
    }

    file_put_contents($json_file_path, $json_data);
    file_put_contents($hash_file_path, $current_hash);
}


/*
function generate_categories_json() {
    // Start gathering categories from the top level (parent_id = 0)
    $categories_data = gather_categories_hierarchically();

    // Encode JSON with pretty print and unicode support
    $json_data = json_encode($categories_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    // Define the upload directory and file paths
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'categories.json';
    $hash_file_path = trailingslashit($upload_dir['basedir']) . 'categories_hash.txt';

    // Calculate the new hash of the JSON data
    $current_hash = hash('sha256', $json_data);

    // Check if the hash file exists and matches the new hash
    if (file_exists($hash_file_path)) {
        $saved_hash = file_get_contents($hash_file_path);
        if ($current_hash === $saved_hash) {
            return; // No changes; exit without regenerating the file
        }
    }

    // Write the new JSON data to the file
    file_put_contents($json_file_path, $json_data);
    file_put_contents($hash_file_path, $current_hash);
}
*/


// Schedule the cron job to regenerate categories.json hourly
if (!wp_next_scheduled('generate_categories_json_cron')) {
    wp_schedule_event(time(), 'hourly', 'generate_categories_json_cron');
}

// Hook the cron event to the function
add_action('generate_categories_json_cron', 'generate_categories_json');

// Admin page to manually regenerate and download the JSON file
add_action('admin_menu', 'export_categories_json_menu');

function export_categories_json_menu() {
    add_submenu_page(
        'edit.php', // Change to 'edit.php' or 'users.php' if it's in a different menu
        'Export Cats JSON', 
        'Export Cats JSON', 
        'manage_options', 
        'export-categories-json', 
        'export_categories_json_page'
    );
}

function export_categories_json_page() {
    // Get the upload directory path and the JSON file URL
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'categories.json';
    $json_file_url = trailingslashit($upload_dir['baseurl']) . 'categories.json';

    // Check if the "regenerate" action was requested and handle regeneration
    if (isset($_POST['regenerate_json'])) {
        generate_categories_json(); // Manually regenerate the JSON file
        echo '<div class="notice notice-success is-dismissible"><p>Categories JSON file regenerated successfully.</p></div>';
    }

    // Display the admin page content with regenerate and download buttons
    echo '<div class="wrap">';
    echo '<h1>Export Categories JSON</h1>';
    echo '<p>Click the button below to download the latest categories JSON file, or regenerate it if needed.</p>';
    
    // Regenerate JSON button
    echo '<form method="POST" style="margin-bottom: 10px;">';
    echo '<input type="hidden" name="regenerate_json" value="1">';
    echo '<button type="submit" class="button button-secondary">Regenerate JSON</button>';
    echo '</form>';
    
    // Download JSON button
    if (file_exists($json_file_path)) {
        echo '<a href="' . esc_url($json_file_url) . '" class="button button-primary" download>Download JSON</a>';
    } else {
        echo '<p><em>JSON file not found. Please regenerate the file first.</em></p>';
    }

    echo '</div>';
}


// GENERATE CATEGORIES BY ID JSON FUNCTION 
/*
function generate_categories_by_id_json() {
    $categories_data = gather_categories_hierarchically();

    // Index categories by ID
    $categories_by_id = [];
    foreach ($categories_data as $category) {
        $categories_by_id[$category['id']] = $category;
    }

    // Identify terminal categories
    $terminal_categories = array_filter($categories_data, function($cat) {
        return $cat['subcategory_count'] === 0;
    });

    // Define suffixes for complementary relationships
    $complementary_suffixes = ['readings', 'mahzorim']; // Extend this list as needed

    // Group terminal categories by base stub
    $base_groups = [];
    foreach ($terminal_categories as $cat) {
        $cat_id = $cat['id'];
        $stub = $cat['stub'];
        $base_stub = $stub;

        foreach ($complementary_suffixes as $suffix) {
            $base_stub = preg_replace('/-' . preg_quote($suffix, '/') . '$/', '', $base_stub);
        }

        $base_groups[$base_stub][] = $cat_id;
    }

    // Build complementary_map from base_groups
    $complementary_map = [];
    foreach ($base_groups as $group) {
        foreach ($group as $id) {
            $comps = array_diff($group, [$id]); // all others in the same group
            if (!isset($complementary_map[$id])) {
                $complementary_map[$id] = [];
            }
            $complementary_map[$id] = array_values(array_unique(array_merge($complementary_map[$id], $comps)));
        }
    }

    // Assign complementary_cat_id
    foreach ($complementary_map as $id => $comp_ids) {
        $categories_by_id[$id]['complementary_cat_id'] = array_values(array_unique($comp_ids));
    }

    // Ensure every category has complementary_cat_id (even if empty)
    foreach ($categories_by_id as $id => &$cat) {
        if (!isset($cat['complementary_cat_id'])) {
            $cat['complementary_cat_id'] = [];
        }
    }
    unset($cat); // break reference

    // Output JSON
    $json_data = json_encode($categories_by_id, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'categories_by_id.json';
    $hash_file_path = trailingslashit($upload_dir['basedir']) . 'categories_by_id_hash.txt';
    $current_hash = hash('sha256', $json_data);

    if (file_exists($hash_file_path)) {
        $saved_hash = file_get_contents($hash_file_path);
        if ($current_hash === $saved_hash) {
            return;
        }
    }

    file_put_contents($json_file_path, $json_data);
    file_put_contents($hash_file_path, $current_hash);
}


add_action('admin_menu', 'add_generate_categories_by_id_json_menu');

function add_generate_categories_by_id_json_menu() {
    add_submenu_page(
        'edit.php',
        'Export Cats by ID JSON',
        'Export Cats by ID JSON',
        'manage_options',
        'export-categories-by-id-json',
        'export_categories_by_id_json_page' // ← FIXED this
    );
}

function export_categories_by_id_json_page() {
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'categories_by_id.json';
    $json_file_url = trailingslashit($upload_dir['baseurl']) . 'categories_by_id.json';

    if (isset($_POST['regenerate_json'])) {
        generate_categories_by_id_json();
        echo '<div class="notice notice-success is-dismissible"><p>Categories by ID JSON file regenerated successfully.</p></div>';
    }

    echo '<div class="wrap">';
    echo '<h1>Export Categories by ID JSON</h1>';
    echo '<p>Click the button below to download the latest categories_by_id.json file or regenerate it.</p>';

    // Regenerate button
    echo '<form method="POST" style="margin-bottom: 10px;">';
    echo '<input type="hidden" name="regenerate_json" value="1">';
    submit_button('Regenerate JSON', 'secondary');
    echo '</form>';

    // Download button
    if (file_exists($json_file_path)) {
        echo '<a href="' . esc_url($json_file_url) . '" class="button button-primary" download>Download JSON</a>';
    } else {
        echo '<p><em>JSON file not found. Please regenerate it first.</em></p>';
    }

    echo '</div>';
}



// Schedule the cron job if not already scheduled
add_action('wp', function () {
    if (!wp_next_scheduled('generate_categories_by_id_json_cron')) {
        wp_schedule_event(time(), 'daily', 'generate_categories_by_id_json_cron');
    }
});

// Hook the cron job to the generator function
add_action('generate_categories_by_id_json_cron', 'generate_categories_by_id_json');

*/




// Natural order sorting for hierarchical IDs
function sort_hierarchical_ids_naturally($a, $b) {
    $a_parts = array_map('intval', explode('.', $a['hierarchical_id']));
    $b_parts = array_map('intval', explode('.', $b['hierarchical_id']));
    
    $max_depth = max(count($a_parts), count($b_parts));
    for ($i = 0; $i < $max_depth; $i++) {
        $a_value = $a_parts[$i] ?? 0; // Default to 0 if no value exists at this depth
        $b_value = $b_parts[$i] ?? 0;
        if ($a_value !== $b_value) {
            return $a_value <=> $b_value; // Compare numerically
        }
    }
    return 0; // Equal if all parts match
}

// Generate "Siblinks" (i.e., links to sibling and cousin categories within a directory hierarchy)
function generate_siblinks($current_category_id) {
    // Load categories.json
    $categories_file = wp_upload_dir()['basedir'] . '/categories.json';
    if (!file_exists($categories_file)) {
        return ['previous' => '', 'next' => ''];
    }

    $categories = json_decode(file_get_contents($categories_file), true);

    // Find the current category
    $current_category = null;
    foreach ($categories as $category) {
        if ($category['id'] === $current_category_id) {
            $current_category = $category;
            break;
        }
    }

    if (!$current_category) return ['previous' => '', 'next' => ''];

    // Determine siblings based on ancestor_set_id if applicable
    $siblings = [];
    if ($current_category['ancestor_set_id']) {
        $ancestor_set_id = $current_category['ancestor_set_id'];
        $siblings = array_filter($categories, function($cat) use ($ancestor_set_id) {
            return $cat['ancestor_set_id'] === $ancestor_set_id;
        });

        // Sort siblings by hierarchical_id naturally
        usort($siblings, 'sort_hierarchical_ids_naturally');
    } else {
        // Otherwise, use siblings by parent_id
        $parent_id = $current_category['parent_id'];
        $siblings = array_filter($categories, function($cat) use ($parent_id) {
            return $cat['parent_id'] === $parent_id;
        });

        // Sort siblings by term_order
        usort($siblings, function($a, $b) {
            return $a['term_order'] <=> $b['term_order'];
        });
    }

    // Locate the current category within the siblings
    $current_index = null;
    foreach ($siblings as $index => $sibling) {
        if ($sibling['id'] === $current_category_id) {
            $current_index = $index;
            break;
        }
    }

    // Determine previous and next siblings
    $previous_sibling = $current_index > 0 ? $siblings[$current_index - 1] : null;
    $next_sibling = $current_index < count($siblings) - 1 ? $siblings[$current_index + 1] : null;

    // Ensure no "previous" link for the first category in a set
    if ($current_index === 0) {
        $previous_sibling = null;
    }

    // Wrap around to the last/first sibling in the set if needed
    if (!$previous_sibling && $current_index !== 0 && !empty($siblings)) {
        $previous_sibling = end($siblings);
    }
    if (!$next_sibling && !empty($siblings)) {
        $next_sibling = reset($siblings);
    }

    // Return the previous and next sibling links
    return [
        'previous' => $previous_sibling ? '&#x1F844; (Previous category) :: <a href="' . esc_url($previous_sibling['permalink']) . '" class="previous-siblink">&#x1F4C1; ' . esc_html($previous_sibling['name']) . '</a>' : '',
        'next' => $next_sibling ? '<a href="' . esc_url($next_sibling['permalink']) . '" class="next-siblink">&#x1F4C1; ' . esc_html($next_sibling['name']) . '</a> :: (Next Category) &#x1F846;' : '',
    ];
}




function os_get_adjacent_date($start, $end) {
    global $wpdb;

    $prev_post = $wpdb->get_row($wpdb->prepare("
        SELECT post_date
        FROM $wpdb->posts
        WHERE post_type = 'post'
          AND post_status = 'publish'
          AND post_date < %s
        ORDER BY post_date DESC
        LIMIT 1
    ", $start));

    $next_post = $wpdb->get_row($wpdb->prepare("
        SELECT post_date
        FROM $wpdb->posts
        WHERE post_type = 'post'
          AND post_status = 'publish'
          AND post_date >= %s
        ORDER BY post_date ASC
        LIMIT 1
    ", $end));

    return [
        'prev_ts' => $prev_post ? strtotime($prev_post->post_date) : null,
        'next_ts' => $next_post ? strtotime($next_post->post_date) : null,
    ];
}

function os_get_adjacent_month_links() {

    if (!is_month()) return ['previous' => '', 'next' => ''];

    $year  = (int) get_query_var('year');
    $month = (int) get_query_var('monthnum');

    $start = sprintf('%04d-%02d-01 00:00:00', $year, $month);

    $next_month = $month === 12 ? 1 : $month + 1;
    $next_year  = $month === 12 ? $year + 1 : $year;
    $end = sprintf('%04d-%02d-01 00:00:00', $next_year, $next_month);

    $adj = os_get_adjacent_date($start, $end);

    return [
        'previous' => $adj['prev_ts']
            ? '&#x1F844; (Previous month) :: <a href="' . esc_url(get_month_link(date('Y', $adj['prev_ts']), date('n', $adj['prev_ts']))) . '" class="prev-month">&#x1F4C5; ' . date_i18n('F Y', $adj['prev_ts']) . '</a>'
            : '',
        'next' => $adj['next_ts']
            ? '<a href="' . esc_url(get_month_link(date('Y', $adj['next_ts']), date('n', $adj['next_ts']))) . '" class="next-month">&#x1F4C5; ' . date_i18n('F Y', $adj['next_ts']) . '</a> :: (Next month) &#x1F846;'
            : '',
    ];
}

function os_get_adjacent_year_links() {

    if (!is_year()) return ['previous' => '', 'next' => ''];

    $year = (int) get_query_var('year');

    $start = "$year-01-01 00:00:00";
    $end   = ($year + 1) . "-01-01 00:00:00";

    $adj = os_get_adjacent_date($start, $end);

    return [
        'previous' => $adj['prev_ts']
            ? '&#x1F844; (Previous year) :: <a href="' . esc_url(get_year_link(date('Y', $adj['prev_ts']))) . '" class="prev-year">&#x1F4C5; ' . date('Y', $adj['prev_ts']) . '</a>'
            : '',
        'next' => $adj['next_ts']
            ? '<a href="' . esc_url(get_year_link(date('Y', $adj['next_ts']))) . '" class="next-year">&#x1F4C5; ' . date('Y', $adj['next_ts']) . '</a> :: (Next year) &#x1F846;'
            : '',
    ];
}

function os_get_adjacent_day_links() {

    if (!is_day()) return ['previous' => '', 'next' => ''];

    $year  = (int) get_query_var('year');
    $month = (int) get_query_var('monthnum');
    $day   = (int) get_query_var('day');

    $start = sprintf('%04d-%02d-%02d 00:00:00', $year, $month, $day);

    $end_ts = strtotime('+1 day', strtotime($start));
    $end = date('Y-m-d H:i:s', $end_ts);

    $adj = os_get_adjacent_date($start, $end);

    return [
        'previous' => $adj['prev_ts']
            ? '&#x1F844; (Previous day) :: <a href="' . esc_url(get_day_link(date('Y', $adj['prev_ts']), date('n', $adj['prev_ts']), date('j', $adj['prev_ts']))) . '" class="prev-day">&#x1F4C5; ' . date_i18n('j F Y', $adj['prev_ts']) . '</a>'
            : '',
        'next' => $adj['next_ts']
            ? '<a href="' . esc_url(get_day_link(date('Y', $adj['next_ts']), date('n', $adj['next_ts']), date('j', $adj['next_ts']))) . '" class="next-day">&#x1F4C5; ' . date_i18n('j F Y', $adj['next_ts']) . '</a> :: (Next day) &#x1F846;'
            : '',
    ];
}


function os_get_year_month_links($year) {
    global $wpdb;

    $months = $wpdb->get_col($wpdb->prepare("
        SELECT DISTINCT MONTH(post_date)
        FROM $wpdb->posts
        WHERE post_type = 'post'
          AND post_status = 'publish'
          AND YEAR(post_date) = %d
        ORDER BY post_date ASC
    ", $year));

    if (!$months) return '';

    $output = '<div class="year-month-links" style="margin-top:10px;">';

    foreach ($months as $m) {
        $month_name = date_i18n('F', mktime(0, 0, 0, $m, 1, $year));
        $link = get_month_link($year, $m);

        $output .= '<a href="' . esc_url($link) . '" class="year-month-link">' 
                . esc_html($month_name) 
                . '</a>&nbsp;&nbsp;';
    }

    $output .= '</div>';

    return $output;
}

function os_get_month_day_links($year, $month) {
    global $wpdb;

    $days = $wpdb->get_col($wpdb->prepare("
        SELECT DISTINCT DAY(post_date)
        FROM $wpdb->posts
        WHERE post_type = 'post'
          AND post_status = 'publish'
          AND YEAR(post_date) = %d
          AND MONTH(post_date) = %d
        ORDER BY post_date ASC
    ", $year, $month));

    if (!$days) return '';

    $output = '<div class="month-day-links" style="margin-top:10px;">';

    foreach ($days as $d) {
        $day_label = (int) $d; // simple numeric day (1–31)
        $link = get_day_link($year, $month, $d);

        $output .= '<a href="' . esc_url($link) . '" class="month-day-link">'
                . esc_html($day_label)
                . '</a>&nbsp;&nbsp;';
    }

    $output .= '</div>';

    return $output;
}

// Retrieve all post IDs where the user is involved (primary author or co-author).
function get_all_user_post_ids($user_id) {
    // Perform the query for all posts by the user.
    $query = new WP_Query(array(
        'author' => $user_id,
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => -1, // Retrieve all posts
        'fields' => 'ids',      // Return only post IDs
    ));

    // If posts are found, return the post IDs.
    return $query->posts;
}


/*
function export_authors_json() {
    // Fetch all users with 'contributor' or 'author' roles
    $authors = get_users(array(
        'role__in' => array('contributor', 'author'),
    ));

    $authors_temp = [];
    $base_name_map = [];

    foreach ($authors as $author) {
        $first_name = trim(strtolower($author->first_name));
        $last_name = trim(strtolower($author->last_name));
        $base_name = $first_name . ' ' . $last_name;

        $authors_temp[] = [
            'author' => $author,
            'base_name' => $base_name
        ];

        if (!isset($base_name_map[$base_name])) {
            $base_name_map[$base_name] = [];
        }
        $base_name_map[$base_name][] = $author->ID;
    }

    $authors_data = [];

    foreach ($authors_temp as $entry) {
        $author = $entry['author'];
        $base_name = $entry['base_name'];

        $status = in_array('contributor', $author->roles) ? 'active' :
                  (in_array('author', $author->roles) ? 'inactive' : '');

        $display_name = $author->display_name;
        $role_label = null;

        // Look for text in parentheses at the end of the display_name
        if (preg_match('/\(([^)]+)\)\s*$/', $display_name, $matches)) {
            $role_label = trim($matches[1]);
        }

        $post_count = count_user_posts($author->ID);
        $post_ids = get_all_user_post_ids($author->ID);
        $avatar_url = get_avatar_url($author->ID);
        $description = get_user_meta($author->ID, 'description', true);
        $website = $author->user_url;
        $author_id = $author->ID;
        $profile_page_link = home_url('/profile/' . $author_slug);

        // Get last_active via post_date!
        $last_active = null;
        if (!empty($post_ids)) {
            $dates = array_map(function($pid) {
                return get_post_field('post_date', $pid);
            }, $post_ids);
            rsort($dates);
            $last_active = $dates[0] ?? null;
        }

        $sibling_ids = array_values(array_filter($base_name_map[$base_name], function($id) use ($author_id) {
            return $id !== $author_id;
        }));

        $authors_data[] = array(
            'display_name' => $author->display_name,
            'first_name' => $author->first_name,
            'last_name' => $author->last_name,
            'base_name' => $base_name,
            'post_count' => $post_count,
            'post_ids' => $post_ids,
            'avatar_url' => $avatar_url,
            'description' => $description,
            'website' => $website,
            'author_slug' => $author_slug,
            'author_id' => $author_id,
            'profile_page_link' => $profile_page_link,
            'status' => $status,
            'last_active' => $last_active,
            'role_label' => $role_label,
            'sibling_ids' => $sibling_ids,
        );
    }

    usort($authors_data, function($a, $b) {
        return strcasecmp($a['last_name'], $b['last_name']);
    });

    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'contributors.json';
    $hash_file_path = trailingslashit($upload_dir['basedir']) . 'contributors_hash.txt';

    $json_data = json_encode($authors_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $current_hash = hash('sha256', $json_data);

    if (file_exists($hash_file_path)) {
        $saved_hash = file_get_contents($hash_file_path);
        if ($current_hash === $saved_hash) {
            return; // Skip regeneration
        }
    }

    file_put_contents($json_file_path, $json_data);
    file_put_contents($hash_file_path, $current_hash);
}

// Schedule the cron job for generating contributors.json to run hourly
if (!wp_next_scheduled('generate_contributors_json')) {
    wp_schedule_event(time(), 'hourly', 'generate_contributors_json');
}

// Hook to the cron job
add_action('generate_contributors_json', 'export_authors_json');

// Add Export Authors JSON to the Users submenu
function export_authors_json_menu() {
    add_submenu_page(
        'users.php', 
        'Export Contributors JSON', 
        'Export Contributors JSON', 
        'manage_options', 
        'download-authors-json', 
        'download_authors_json_page'
    );
}
add_action('admin_menu', 'export_authors_json_menu');

// Create the download page
function download_authors_json_page() {
    // Get the upload directory path to find the JSON file
    $upload_dir = wp_upload_dir();
    $json_file_url = trailingslashit($upload_dir['baseurl']) . 'contributors.json';

    // Check if the "regenerate" action was requested
    if (isset($_POST['regenerate_json'])) {
        export_authors_json(); // Manually regenerate the JSON file
        echo '<div class="notice notice-success is-dismissible"><p>Contributors JSON file regenerated successfully.</p></div>';
    }

    // Display the download and regenerate buttons
    echo '<div class="wrap">';
    echo '<h1>Export Contributors JSON</h1>';
    echo '<p>Click the button below to download the latest contributors JSON file, or regenerate it if needed.</p>';
    
    // Regenerate JSON button
    echo '<form method="POST" style="margin-bottom: 10px;">';
    echo '<input type="hidden" name="regenerate_json" value="1">';
    echo '<button type="submit" class="button button-secondary">Regenerate JSON</button>';
    echo '</form>';
    
    // Download JSON button
    echo '<a href="' . esc_url($json_file_url) . '" class="button button-primary" download>Download JSON</a>';
    echo '</div>';
}


// Unschedule the old export_authors_json cron event
function remove_old_export_authors_json_cron() {
    $timestamp = wp_next_scheduled('export_authors_json_cron_hook');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'export_authors_json_cron_hook');
    }
}
remove_old_export_authors_json_cron(); // Run once, then remove this line
*/

function export_contributors_by_id_json() {
    $authors = get_users(array(
        'role__in' => array('contributor', 'author'),
    ));

    $authors_temp = [];
    $base_name_map = [];

    foreach ($authors as $author) {
        //$first_name = trim(strtolower($author->first_name));
        //$last_name = trim(strtolower($author->last_name));
        $first_name = trim(strtolower((string) ($author->first_name ?? '')));
        $last_name  = trim(strtolower((string) ($author->last_name ?? '')));

        $base_name = $first_name . ' ' . $last_name;

        $authors_temp[] = [
            'author' => $author,
            'base_name' => $base_name
        ];

        if (!isset($base_name_map[$base_name])) {
            $base_name_map[$base_name] = [];
        }
        $base_name_map[$base_name][] = $author->ID;
    }

    $authors_data = [];

    foreach ($authors_temp as $entry) {
        $author = $entry['author'];
        $base_name = $entry['base_name'];
        $author_id = $author->ID;

        $status = in_array('contributor', $author->roles) ? 'active' :
                  (in_array('author', $author->roles) ? 'inactive' : '');

        $display_name = (string) ($author->display_name ?? '');
        //$display_name = $author->display_name;
        $role_label = null;

        // Extract role label from parentheses in display_name
        if (preg_match('/\(([^)]+)\)\s*$/', $display_name, $matches)) {
            $role_label = trim($matches[1]);
        }

        $post_count = count_user_posts($author_id);
        $post_ids = get_all_user_post_ids($author_id);
        $avatar_url = get_avatar_url($author_id);
        $description = get_user_meta($author_id, 'description', true);
        $website = $author->user_url;
        $author_slug = $author->user_nicename;
        $profile_page_link = home_url('/profile/' . $author_slug);

        $last_active = null;
        if (!empty($post_ids)) {
            $dates = array_map(function($pid) {
                return get_post_field('post_date', $pid);
            }, $post_ids);
            rsort($dates);
            $last_active = $dates[0] ?? null;
        }

        $sibling_ids = array_values(array_filter($base_name_map[$base_name], function($id) use ($author_id) {
            return $id !== $author_id;
        }));

        $authors_data[$author_id] = array(
            'display_name' => $display_name,
            'first_name' => $author->first_name,
            'last_name' => $author->last_name,
            'base_name' => $base_name,
            'post_count' => $post_count,
            'post_ids' => $post_ids,
            'avatar_url' => $avatar_url,
            'description' => $description,
            'website' => $website,
            'author_slug' => $author_slug,
            'author_id' => $author_id,
            'profile_page_link' => $profile_page_link,
            'status' => $status,
            'last_active' => $last_active,
            'role_label' => $role_label,
            'sibling_ids' => $sibling_ids,
        );
    }

    ksort($authors_data); // Optional: sort by author ID for predictability

    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'contributors_by_id.json';
    $hash_file_path = trailingslashit($upload_dir['basedir']) . 'contributors_by_id_hash.txt';

    $json_data = json_encode($authors_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $current_hash = hash('sha256', $json_data);

    if (file_exists($hash_file_path)) {
        $saved_hash = file_get_contents($hash_file_path);
        if ($current_hash === $saved_hash) {
            return; // Skip regeneration
        }
    }

    file_put_contents($json_file_path, $json_data);
    file_put_contents($hash_file_path, $current_hash);
    
    // Clear cached shortcode output
    delete_transient('cci_rendered_index_html');    
}



// Schedule the cron job for generating contributors_by_id.json to run hourly
if (!wp_next_scheduled('generate_contributors_by_id_json')) {
    wp_schedule_event(time(), 'hourly', 'generate_contributors_by_id_json');
}

// Hook to the cron job
add_action('generate_contributors_by_id_json', 'export_contributors_by_id_json');


// Add Export Contributors by ID JSON to the Users submenu
function export_contributors_by_id_json_menu() {
    add_submenu_page(
        'users.php', 
        'Export Contributors JSON', 
        'Export Contributors JSON', 
        'manage_options', 
        'download-contributors-by-id-json', 
        'download_contributors_by_id_json_page'
    );
}
add_action('admin_menu', 'export_contributors_by_id_json_menu');

// Create the download page
function download_contributors_by_id_json_page() {
    $upload_dir = wp_upload_dir();
    $json_file_url = trailingslashit($upload_dir['baseurl']) . 'contributors_by_id.json';

    if (isset($_POST['regenerate_contributors_by_id_json'])) {
        export_contributors_by_id_json();
        echo '<div class="notice notice-success is-dismissible"><p>contributors_by_id.json regenerated successfully.</p></div>';
    }

    echo '<div class="wrap">';
    echo '<h1>Contributors by ID JSON</h1>';
    echo '<p>This JSON file is keyed by author ID for improved plugin performance and key-based access.</p>';
    
    // Regenerate JSON button
    echo '<form method="POST" style="margin-bottom: 10px;">';
    echo '<input type="hidden" name="regenerate_contributors_by_id_json" value="1">';
    echo '<button type="submit" class="button button-secondary">Regenerate JSON</button>';
    echo '</form>';

    // Download JSON button
    echo '<a href="' . esc_url($json_file_url) . '" class="button button-primary" download>Download JSON</a>';
    echo '</div>';
}


//Extending User data to include categories and tags


// Register User Categories
function register_user_categories() {
    register_taxonomy(
        'user_category',
        'user',
        array(
            'public' => true,
            'labels' => array(
                'name' => 'User Categories',
                'singular_name' => 'User Category',
                'search_items' => 'Search User Categories',
                'all_items' => 'All User Categories',
                'edit_item' => 'Edit User Category',
                'update_item' => 'Update User Category',
                'add_new_item' => 'Add New User Category',
                'new_item_name' => 'New User Category Name',
                'menu_name' => 'User Categories',
            ),
            'rewrite' => array('slug' => 'user_category'),
        )
    );
}
add_action('init', 'register_user_categories');

// Register User Tags
function register_user_tags() {
    register_taxonomy(
        'user_tag',
        'user',
        array(
            'public' => true,
            'labels' => array(
                'name' => 'User Tags',
                'singular_name' => 'User Tag',
                'search_items' => 'Search User Tags',
                'all_items' => 'All User Tags',
                'edit_item' => 'Edit User Tag',
                'update_item' => 'Update User Tag',
                'add_new_item' => 'Add New User Tag',
                'new_item_name' => 'New User Tag Name',
                'menu_name' => 'User Tags',
            ),
            'rewrite' => array('slug' => 'user_tag'),
        )
    );
}
add_action('init', 'register_user_tags');

// Add user categories and tags to user profile
function add_user_taxonomies_to_profile($user) {
    // Get user categories and tags
    $user_categories = wp_get_object_terms($user->ID, 'user_category', array('fields' => 'names'));
    $user_tags = wp_get_object_terms($user->ID, 'user_tag', array('fields' => 'names'));

    ?>
    <h3>User Categories and Tags</h3>

    <table class="form-table">
        <tr>
            <th><label for="user_categories">User Categories</label></th>
            <td>
                <?php
                // Display user categories as checkboxes
                $categories = get_terms('user_category', array('hide_empty' => false));
                foreach ($categories as $category) {
                    $checked = in_array($category->name, $user_categories) ? 'checked="checked"' : '';
                    echo '<label><input type="checkbox" name="user_categories[]" value="' . esc_attr($category->term_id) . '" ' . $checked . '> ' . esc_html($category->name) . '</label><br>';
                }
                ?>
            </td>
        </tr>
        <tr>
            <th><label for="user_tags">User Tags</label></th>
            <td>
                <textarea name="user_tags" id="user_tags" rows="5" cols="30"><?php echo esc_html(implode(', ', $user_tags)); ?></textarea>
                <p class="description">Separate tags with commas.</p>
            </td>
        </tr>
    </table>
    <?php
}

add_action('show_user_profile', 'add_user_taxonomies_to_profile');
add_action('edit_user_profile', 'add_user_taxonomies_to_profile');

// Save user categories and tags
function save_user_taxonomies($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Save user categories
    if (isset($_POST['user_categories'])) {
        $user_categories = array_map('intval', $_POST['user_categories']);
        wp_set_object_terms($user_id, $user_categories, 'user_category', false);
    } else {
        wp_set_object_terms($user_id, array(), 'user_category', false);
    }

    // Save user tags
/*    if (isset($_POST['user_tags'])) {
        $user_tags = array_map('trim', explode(',', $_POST['user_tags']));
        wp_set_object_terms($user_id, $user_tags, 'user_tag', false);
    } else {
        wp_set_object_terms($user_id, array(), 'user_tag', false);
    } */
    
    // Save user tags
    if (isset($_POST['user_tags'])) {
        $raw_tags  = (string) $_POST['user_tags'];
        $user_tags = array_map('trim', explode(',', $raw_tags));
        wp_set_object_terms($user_id, $user_tags, 'user_tag', false);
    } else {
        wp_set_object_terms($user_id, array(), 'user_tag', false);
    }
}

add_action('personal_options_update', 'save_user_taxonomies');
add_action('edit_user_profile_update', 'save_user_taxonomies');

// Add menu items for managing user categories and tags under Users menu
function user_taxonomies_menu() {
    add_users_page(
        'User Categories', // Page title
        'User Categories', // Menu title
        'manage_options', // Capability
        'edit-tags.php?taxonomy=user_category', // Menu slug
        '', // Function
        20 // Position
    );

    add_users_page(
        'User Tags', // Page title
        'User Tags', // Menu title
        'manage_options', // Capability
        'edit-tags.php?taxonomy=user_tag', // Menu slug
        '', // Function
        21 // Position
    );
}

add_action('admin_menu', 'user_taxonomies_menu');

// Ensure the Users menu is highlighted when viewing user categories and tags
function set_current_menu() {
    global $parent_file, $submenu_file, $current_screen;
    
    if ($current_screen->taxonomy === 'user_category' || $current_screen->taxonomy === 'user_tag') {
        $parent_file = 'users.php';
        $submenu_file = 'edit-tags.php?taxonomy=' . $current_screen->taxonomy;
    }
}

add_action('admin_head', 'set_current_menu');

/* function my_rewrite_flush() {
    register_user_categories();
    register_user_tags();
    flush_rewrite_rules();
}
add_action('init', 'my_rewrite_flush', 20); */




// Add means of accessing tags via the tag_ID
function redirect_tag_id_to_slug() {
    if ( isset( $_GET['tag_ID'] ) ) {
        $tag_id = intval( $_GET['tag_ID'] );
        $tag = get_tag( $tag_id );
        if ( $tag ) {
            wp_redirect( get_tag_link( $tag_id ), 301 );
            exit;
        }
    }
}
add_action( 'template_redirect', 'redirect_tag_id_to_slug' );


// Improvement to Header info of archive pages
function add_jetpack_analytics_to_archive_pages() {
    if (is_category() || is_tag()) {
        // Get the current term (category or tag)
        $term = get_queried_object();
        
        // Bail out safely if no valid term object
        if (! $term || ! isset($term->term_id, $term->slug)) {
            return;
        }
        
        $term_type = is_category() ? 'category' : 'tag';
        $term_id = $term->term_id;
        $term_slug = $term->slug;
        
        // Canonical URL based on term ID
        $canonical_url = home_url("/index.php?$term_type" . "_ID=$term_id");
        
        // OpenGraph and Twitter card updates (if needed)
        echo '<meta property="og:type" content="website" />';
        echo '<meta property="og:url" content="' . esc_url($canonical_url) . '" />';
        echo '<meta property="og:title" content="' . esc_html(single_cat_title('', false)) . '" />';
        echo '<meta name="twitter:card" content="summary" />';
        echo '<meta name="twitter:url" content="' . esc_url($canonical_url) . '" />';
        
        // Output canonical tag for term ID
        echo '<link rel="canonical" href="' . esc_url($canonical_url) . '" />';
        
        // Optional: Add breadcrumbs for better tracking and navigation clarity
        /* if (function_exists('yoast_breadcrumb')) {
            yoast_breadcrumb('<p id="breadcrumbs">','</p>');
        } */
    }
}
add_action('wp_head', 'add_jetpack_analytics_to_archive_pages');


// Visitor re-arrangement of asc/desc category and tag page menu_order 
function change_category_tag_menu_order( $query ) {
    // Ensure we're not in the admin panel and this is the main query
    if ( ! is_admin() && $query->is_main_query() ) {
        
        // For category and tag archive pages
        if ( is_category() || is_tag() ) {
            // Check if 'order' is set in the query string
            $user_order = isset($_GET['order']) ? $_GET['order'] : '';

            if ($user_order === 'asc') {
                // Sort by menu_order in ascending order
                $query->set( 'orderby', 'menu_order' );
                $query->set( 'order', 'ASC' );
            } elseif ($user_order === 'desc') {
                // Sort by menu_order in descending order
                $query->set( 'orderby', 'menu_order' );
                $query->set( 'order', 'DESC' );
            } else {
                // Default sorting by menu_order in descending order if no user input
                $query->set( 'orderby', 'menu_order' );
                $query->set( 'order', 'DESC' );
            }
        }
    }
}
add_action( 'pre_get_posts', 'change_category_tag_menu_order' );


// Add means of accessing authors via the user_ID

function redirect_user_id_to_slug() {
    if ( isset( $_GET['user_ID'] ) ) {
        $user_id = intval( $_GET['user_ID'] );
        $user = get_userdata( $user_id );
        if ( $user ) {
            // Build the profile link using the user's slug
            $profile_url = home_url( '/profile/' . $user->user_nicename );
            wp_redirect( $profile_url, 301 ); // Permanent redirect
            exit;
        }
    }
}
add_action( 'template_redirect', 'redirect_user_id_to_slug' );


// Fixing Author page title and og:title caused by YoastSEO

add_filter('wpseo_title', function($title) {
    if (is_author()) {
        $curauth = get_queried_object();
        return $curauth->display_name . ' • ' . get_bloginfo('name');
    }
    return $title;
});
add_filter('wpseo_opengraph_title', function($title) {
    if (is_author()) {
        $curauth = get_queried_object();
        return $curauth->display_name . ' • ' . get_bloginfo('name');
    }
    return $title;
});

// Helper function to get collaborative posts
function get_collaborative_posts($author_id, $collab_id) {
    $json_file = wp_upload_dir()['basedir'] . '/contributors_by_id.json';
    if (!file_exists($json_file)) {
        return [];
    }

    $contributors = json_decode(file_get_contents($json_file), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return [];
    }

    // Helper function to get all post IDs including siblings
    $get_all_post_ids = function($id) use ($contributors) {
        if (!isset($contributors[$id])) return [];

        $all_ids = [$id];
        if (!empty($contributors[$id]['sibling_ids'])) {
            $all_ids = array_merge($all_ids, $contributors[$id]['sibling_ids']);
        }

        $posts = [];
        foreach ($all_ids as $aid) {
            if (isset($contributors[$aid])) {
                $posts = array_merge($posts, $contributors[$aid]['post_ids'] ?? []);
            }
        }

        return array_unique($posts);
    };

    $author_posts = $get_all_post_ids($author_id);
    $collab_posts = $get_all_post_ids($collab_id);

    if (empty($author_posts) || empty($collab_posts)) {
        return [];
    }

    return array_values(array_intersect($author_posts, $collab_posts));
}


// Author page filtering by category, tag, collaborator, date range, and language.
function modify_author_query($query) {
    if ($query->is_author() && $query->is_main_query() && !is_admin()) {
        $curauth = get_user_by('slug', get_query_var('author_name'));

        // 🔒 PHP 8 guard: author may not exist
        if ( ! $curauth || ! isset( $curauth->ID ) ) {
            return;
        }        

        // Get filter parameters from URL
        $order     = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'asc';
        $category  = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : null;
        $tag       = isset($_GET['tag']) ? sanitize_text_field($_GET['tag']) : null;
        $collab    = isset($_GET['collab']) ? intval($_GET['collab']) : null;
        $daterange = isset($_GET['daterange']) ? sanitize_text_field($_GET['daterange']) : null;
        $language  = isset($_GET['language']) ? sanitize_text_field($_GET['language']) : null;

        // Initialize query parameters
        $query_params = [
            'orderby'        => 'menu_order',
            'order'          => $order,
            'posts_per_page' => 20,
        ];

        // Filter by collaborator (if present)
        if ($collab) {
            $post_ids = get_collaborative_posts($curauth->ID, $collab);
            $query_params['post__in'] = empty($post_ids) ? [0] : $post_ids;
        } else {
            $query_params['author'] = $curauth->ID;
        }

        // Filter by category (if present)
        if ($category) {
            $query_params['category_name'] = $category;
        }

        // Filter by tag (if present)
        if ($tag) {
            $query_params['tag'] = $tag;
        }

        // Filter by language (if present)
        if ($language) {
            $query_params['meta_query'][] = [
                'key'     => 'languages_meta',
                'value'   => '"code":"' . $language . '"',
                'compare' => 'LIKE'
            ];
        }

        // Handle date range filtering
        $daterange_start = isset($_GET['daterange_start']) ? (int) $_GET['daterange_start'] : null;
        $daterange_end = isset($_GET['daterange_end']) ? (int) $_GET['daterange_end'] : null;

        if ($daterange_start !== null && $daterange_end !== null && $daterange_start <= $daterange_end) {
            $query_params['meta_query'][] = [
                'relation' => 'AND',
                [
                    'key'     => 'date_src_start_year',
                    'value'   => $daterange_start,
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                ],
                [
                    'key'     => 'date_src_end_year',
                    'value'   => $daterange_end,
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                ],
            ];

            unset($query_params['author'], $query_params['tag'], $query_params['category__in']);
        }

        // Apply query modifications
        foreach ($query_params as $key => $value) {
            $query->set($key, $value);
        }
    }
}
add_action('pre_get_posts', 'modify_author_query');



// Category page filtering by category, tag, author, language, and date range.
function modify_category_query($query) {
    if ($query->is_category() && $query->is_main_query() && !is_admin()) {
        $order           = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'desc';
        $tag             = isset($_GET['taag']) ? sanitize_text_field($_GET['taag']) : null;
        $cat_slug        = isset($_GET['caat']) ? sanitize_text_field($_GET['caat']) : null;  
        $collab_id       = isset($_GET['col']) ? intval($_GET['col']) : null;
        $language        = isset($_GET['language']) ? sanitize_text_field($_GET['language']) : null;
        $daterange_start = isset($_GET['daterange_start']) ? (int) $_GET['daterange_start'] : null;
        $daterange_end   = isset($_GET['daterange_end']) ? (int) $_GET['daterange_end'] : null;

        $category = get_queried_object();
        /* $category_id = $category->term_id; */
        if ( ! $category || ! isset( $category->term_id ) ) {
            return;
        }
        $category_id = (int) $category->term_id;


        $query_params = [
            'orderby'        => 'menu_order',
            'order'          => $order,
            'posts_per_page' => 20,
        ];

        if ($tag) {
            $query_params['tag'] = $tag;
        }

        $upload_dir = wp_upload_dir()['basedir'];
        $categories_file = $upload_dir . '/categories.json';
        $contributors_file = $upload_dir . '/contributors_by_id.json';

        $cat_posts = null;
        if ($cat_slug && file_exists($categories_file)) {
            $categories = json_decode(file_get_contents($categories_file), true);
            $cat_obj = get_category_by_slug($cat_slug);
            if ($cat_obj) {
                foreach ($categories as $cat) {
                    if ($cat['id'] === $cat_obj->term_id) {
                        $cat_posts = $cat['post_ids'];
                        break;
                    }
                }
                if ($cat_posts !== null) {
                    $query_params['post__in'] = !empty($cat_posts) ? $cat_posts : [0];
                }
            }
        }

        if ($collab_id && file_exists($contributors_file) && file_exists($categories_file)) {
            $contributors = json_decode(file_get_contents($contributors_file), true);
            $categories = json_decode(file_get_contents($categories_file), true);

            $author_posts = [];
            if (isset($contributors[$collab_id])) {
                $author_posts = $contributors[$collab_id]['post_ids'];
            }

            $category_posts = [];
            foreach ($categories as $cat) {
                if ($cat['id'] === $category_id) {
                    $category_posts = $cat['post_ids'];
                    break;
                }
            }

            $filtered_posts = array_intersect($author_posts, $category_posts);
            $query_params['post__in'] = !empty($filtered_posts) ? $filtered_posts : [0];
        }

        if ($language) {
            $query_params['meta_query'][] = [
                'key'     => 'languages_meta',
                'value'   => '"code":"' . $language . '"',
                'compare' => 'LIKE'
            ];
        }

        if ($daterange_start !== null && $daterange_end !== null && $daterange_start <= $daterange_end) {
            $meta_query = [
                'relation' => 'AND',
                [
                    'key'     => 'date_src_start_year',
                    'value'   => $daterange_start,
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                ],
                [
                    'key'     => 'date_src_end_year',
                    'value'   => $daterange_end,
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                ],
            ];

            // When a date range is present, remove other post filters
            $tag = $cat_slug = $collab_id = null;

            $query->set('meta_query', $meta_query);
        }

        foreach ($query_params as $key => $value) {
            $query->set($key, $value);
        }
    }
}
add_action('pre_get_posts', 'modify_category_query');



// Modify Yoast SEO breadcrumb to show "Tag: X" only on tag pages
add_filter('wpseo_breadcrumb_links', 'custom_yoast_tag_breadcrumb_links');

function custom_yoast_tag_breadcrumb_links($links) {
    // Ensure this modification only applies on tag archive pages
    if (is_tag() && !is_author() && !is_category()) {
        $tag = get_queried_object(); // Get the current tag object

        // Modify the last breadcrumb element with "Tag: X"
        $links[count($links) - 1]['text'] = 'tag: ' . esc_html($tag->name);
    }
    return $links;
}

add_filter('wpseo_breadcrumb_links', 'ac_modify_author_breadcrumb');

function ac_modify_author_breadcrumb($links) {
    // Check if we're on an author archive page or a filtered author page.
    if (is_author() || (is_author() && (get_query_var('cat') || get_query_var('tag')))) {

        // Get the queried author object.
        $author_id = get_queried_object_id();
        $author = get_userdata($author_id);
        if (!$author) {
            return $links; // Exit if no author found.
        }

        // Create a new breadcrumb link with the author’s display name.
        $author_link = array(
            'url'  => get_author_posts_url($author_id),
            'text' => $author->display_name,
        );

        // Add the author link to the end of the breadcrumb links.
        if (isset($_GET['tag'])) {
            $links[] = $author_link;
        }
    }

    return $links;
}


add_filter('wpseo_breadcrumb_links', 'os_modify_date_breadcrumbs');

function os_modify_date_breadcrumbs($links) {

    if (!is_date()) {
        return $links;
    }

    $new_links = array();

    // YEAR archive: /2026/
    if (is_year()) {
        $year = get_query_var('year');

        $new_links[] = array(
            'text' => (string) $year,
        );

        return $new_links;
    }

    // MONTH archive: /2026/04/
    if (is_month()) {
        $year  = get_query_var('year');
        $month = get_query_var('monthnum');

        // Year (linked)
        $new_links[] = array(
            'url'  => get_year_link($year),
            'text' => (string) $year,
        );

        // Month (current)
        $new_links[] = array(
            'text' => date_i18n('F', mktime(0, 0, 0, $month, 1)),
        );

        return $new_links;
    }

    // DAY archive (optional but consistent)
    if (is_day()) {
        $year  = get_query_var('year');
        $month = get_query_var('monthnum');
        $day   = get_query_var('day');

        $new_links[] = array(
            'url'  => get_year_link($year),
            'text' => (string) $year,
        );

        $new_links[] = array(
            'url'  => get_month_link($year, $month),
            'text' => date_i18n('F', mktime(0, 0, 0, $month, 1)),
        );

        $new_links[] = array(
            'text' => (string) $day,
        );

        return $new_links;
    }

    return $links;
}



// Enqueue custom styles
function enqueue_custom_styles() {
    wp_enqueue_style(
        'custom-styles', 
        get_stylesheet_directory_uri() . '/css/custom-styles.css', 
        array(), 
        '1.0.0' // Version number for cache-busting
    );
}
add_action('wp_enqueue_scripts', 'enqueue_custom_styles');

// Helper function to get sibling accounts by first and last name for Author pages.
function get_sibling_accounts($current_user_id) {
    // Get the current user's first and last name
    $current_user = get_userdata($current_user_id);
    $first_name = get_user_meta($current_user_id, 'first_name', true);
    $last_name = get_user_meta($current_user_id, 'last_name', true);

    if (!$first_name || !$last_name) {
        return []; // If either name is missing, return an empty array
    }

    // Query for users with the same first and last name
    $sibling_accounts = get_users([
        'meta_query' => [
            'relation' => 'AND',
            [
                'key'     => 'first_name',
                'value'   => $first_name,
                'compare' => '='
            ],
            [
                'key'     => 'last_name',
                'value'   => $last_name,
                'compare' => '='
            ]
        ],
        'exclude' => [$current_user_id] // Exclude the current user
    ]);

    return $sibling_accounts;
}

function get_sibling_accounts_with_roles($main_id) {
    $json_path = wp_upload_dir()['basedir'] . '/contributors_by_id.json';
    if (!file_exists($json_path)) {
        return [];
    }

    $data = json_decode(file_get_contents($json_path), true);
    if (!isset($data[$main_id])) {
        return [];
    }

    $main_entry = $data[$main_id];
    $sibling_ids = $main_entry['sibling_ids'] ?? [];

    // Include the main ID (in case we’re not on the original page)
    array_unshift($sibling_ids, $main_id); // Adds main ID to the front of the array

    $result = [];
    foreach ($sibling_ids as $id) {
        if (!isset($data[$id])) {
            continue;
        }

        $user = get_user_by('ID', $id);
        if (!$user) continue;

        $result[] = [
            'user' => $user,
            'role_label' => $data[$id]['role_label']
        ];
    }

    return $result;
}


//Helper function for the above with use in the author's template
function get_main_account_id($user_id) {
    $siblings = get_sibling_accounts_with_roles($user_id);
    foreach ($siblings as $entry) {
        if ($entry['role_label'] === null) {
            return $entry['user']->ID;
        }
    }
    return $user_id; // fallback if no null role_label found
}




// Allow HTML in category descriptions
add_filter('term_description', 'allow_category_html', 10, 1);
function allow_category_html($description) {
    return wp_kses_post($description); // Allow standard HTML tags
}


/*
function disable_jetpack_auto_placement() {
    remove_filter( 'the_content', 'sharing_display', 19 ); // Remove from post content
    remove_filter( 'the_excerpt', 'sharing_display', 19 ); // Remove from excerpts
}
add_action( 'loop_start', 'disable_jetpack_auto_placement' );
*/


// Add Bluesky button to Scriptless Social Sharing plugin
add_filter( 'scriptlesssocialsharing_register', function( $buttons ) {
    $buttons['bluesky'] = array(
        'label'    => 'Bluesky',
        'url_base' => 'https://bsky.app/intent/compose',
        'args'     => array(
            'query_args' => array(
                'text' => '%%custom_text%%', // text must be contained within placeholders
            ),
            'color'      => '#3333cc', // Optional: Custom button color.
            'icon'       => '', // Optional: SVG icon for Bluesky.
        ),
    );
    return $buttons;
}, 20 ); // Higher priority ensures it overrides other filters.

add_filter( 'scriptlesssocialsharing_bluesky_query_args', function( $query_args, $id, $attributes, $setting ) {
    global $post;

    if ( ! $post instanceof WP_Post ) {
        return $query_args;
    }

    $post_title = get_the_title( $post->ID );
    $shortlink  = site_url( '?p=' . $post->ID );

    // Adding two spaces to separate the title from the URL.
    $query_args['text'] = $post_title . '  ' . $shortlink;

    return $query_args;
}, 20, 4 );


/*
function display_sorted_posts() {
    global $wpdb;

    // Query posts and their custom fields
    $posts = $wpdb->get_results("
        SELECT 
            p.ID as post_id,
            p.menu_order,
            p.post_title,
            m1.meta_value as date_src_start,
            m2.meta_value as date_src_end,
            m3.meta_value as date_trans_start,
            m4.meta_value as date_trans_end
        FROM 
            {$wpdb->posts} p
        LEFT JOIN {$wpdb->postmeta} m1 ON p.ID = m1.post_id AND m1.meta_key = 'date_src_start'
        LEFT JOIN {$wpdb->postmeta} m2 ON p.ID = m2.post_id AND m2.meta_key = 'date_src_end'
        LEFT JOIN {$wpdb->postmeta} m3 ON p.ID = m3.post_id AND m3.meta_key = 'date_trans_start'
        LEFT JOIN {$wpdb->postmeta} m4 ON p.ID = m4.post_id AND m4.meta_key = 'date_trans_end'
        WHERE 
            p.post_status = 'publish'
        ORDER BY 
            CAST(SUBSTRING(m1.meta_value, 1, 4) AS SIGNED) DESC, -- Year of date_src_start
            CAST(SUBSTRING(m1.meta_value, 6, 2) AS SIGNED) DESC, -- Month of date_src_start
            CAST(SUBSTRING(m1.meta_value, 9, 2) AS SIGNED) DESC, -- Day of date_src_start
            p.post_title DESC,                                   -- Post title (descending)
            CAST(SUBSTRING(m3.meta_value, 1, 4) AS SIGNED) DESC, -- Year of date_trans_start
            CAST(SUBSTRING(m3.meta_value, 6, 2) AS SIGNED) DESC, -- Month of date_trans_start
            CAST(SUBSTRING(m3.meta_value, 9, 2) AS SIGNED) DESC  -- Day of date_trans_start
    ");

    if (!$posts) {
        echo '<p>No posts found.</p>';
        return;
    }

    // Display results
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<thead>
        <tr>
            <th>Post ID</th>
            <th>Menu Order</th>
            <th>Post Title</th>
            <th>Date Src Start</th>
            <th>Date Src End</th>
            <th>Date Trans Start</th>
            <th>Date Trans End</th>
        </tr>
    </thead>';
    echo '<tbody>';

    foreach ($posts as $post) {
        echo '<tr>';
        echo '<td>' . esc_html($post->post_id) . '</td>';
        echo '<td>' . esc_html($post->menu_order) . '</td>';
        echo '<td>' . esc_html($post->post_title) . '</td>';
        echo '<td>' . esc_html($post->date_src_start) . '</td>';
        echo '<td>' . esc_html($post->date_src_end) . '</td>';
        echo '<td>' . esc_html($post->date_trans_start) . '</td>';
        echo '<td>' . esc_html($post->date_trans_end) . '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
}

// Hook this function to a shortcode for testing
add_shortcode('display_sorted_posts', 'display_sorted_posts');
*/


// Add custom column to the Posts admin page
add_filter('manage_posts_columns', 'add_year_range_column');
function add_year_range_column($columns) {
    $columns['year_range'] = __('Year Range', 'textdomain');
    return $columns;
}

// Populate the custom column with data, including date_trans range
add_action('manage_posts_custom_column', 'populate_year_range_with_trans_column', 10, 2);
function populate_year_range_with_trans_column($column_name, $post_id) {
    if ($column_name === 'year_range') {
        // Get date_src and date_trans fields
        $date_src_start = get_post_meta($post_id, 'date_src_start', true);
        $date_src_end = get_post_meta($post_id, 'date_src_end', true);
        $date_trans_start = get_post_meta($post_id, 'date_trans_start', true);
        $date_trans_end = get_post_meta($post_id, 'date_trans_end', true);

        // Extract years
        $src_start_year = extract_year($date_src_start);
        $src_end_year = extract_year($date_src_end);
        $trans_start_year = extract_year($date_trans_start);
        $trans_end_year = extract_year($date_trans_end);

        // Format the date_src range
        $output = '';
        if ($src_start_year && $src_end_year) {
            $output = ($src_start_year === $src_end_year) ? $src_start_year : "$src_start_year – $src_end_year";
        } elseif ($src_start_year) {
            $output = $src_start_year;
        } else {
            $output = __('N/A', 'textdomain');
        }

        // Format the date_trans range
        $trans_output = '';
        if ($trans_start_year && $trans_end_year) {
            $trans_output = ($trans_start_year === $trans_end_year) ? $trans_start_year : "$trans_start_year – $trans_end_year";
        } elseif ($trans_start_year) {
            $trans_output = $trans_start_year;
        }

        // Append the trans range in parentheses if available
        if (!empty($trans_output)) {
            $output .= " ($trans_output)";
        }

        echo esc_html($output);
    }
}

// Helper function to extract the year from a date
function extract_year($date) {
    if (preg_match('/^(-?\d+)-/', $date, $matches)) {
        $year = $matches[1];

        // Replace dash with Unicode minus sign for BCE years
        return $year[0] === '-' ? '−' . substr($year, 1) : $year;
    }
    return ''; // Return empty string if no match
}


function update_year_fields_on_save( $post_id ) {
    // Only update for posts (not pages or other post types)
    if ( get_post_type( $post_id ) !== 'post' ) {
        return;
    }

    // Avoid autosave and revision updates
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Ensure user has permission to edit post
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // Extract the year values from the full date fields
    $date_src_start = get_post_meta( $post_id, 'date_src_start', true );
    $date_src_end = get_post_meta( $post_id, 'date_src_end', true );
    $date_trans_start = get_post_meta( $post_id, 'date_trans_start', true );
    $date_trans_end = get_post_meta( $post_id, 'date_trans_end', true );

    // Helper function to extract year from date
    $extract_year = function( $date ) {
        if ( $date && preg_match( '/^-?\d{4}/', $date, $match ) ) {
            return (int) $match[0];
        }
        return null;
    };

    // Update the year fields based on extracted values
    update_post_meta( $post_id, 'date_src_start_year', $extract_year( $date_src_start ) );
    update_post_meta( $post_id, 'date_src_end_year', $extract_year( $date_src_end ) );
    update_post_meta( $post_id, 'date_trans_start_year', $extract_year( $date_trans_start ) );
    update_post_meta( $post_id, 'date_trans_end_year', $extract_year( $date_trans_end ) );
}
add_action( 'save_post', 'update_year_fields_on_save' );







// Add a "Languages" column to the admin post list
function add_languages_column($columns) {
    $columns['languages'] = 'Languages';
    return $columns;
}
add_filter('manage_posts_columns', 'add_languages_column');

// Populate the "Languages" column with data
function display_languages_column($column, $post_id) {
    if ($column === 'languages') {
        $languages_meta = get_post_meta($post_id, 'languages_meta', true);
        $languages = $languages_meta ? json_decode($languages_meta, true) : [];

        if (!empty($languages)) {
            $language_names = array_map(fn($lang) => esc_html($lang['name']), $languages);
            sort($language_names, SORT_NATURAL | SORT_FLAG_CASE); // Sort alphabetically, case-insensitive
            echo implode(', ', $language_names);
        } else {
            echo '<em>None</em>';
        }
    }
}
add_action('manage_posts_custom_column', 'display_languages_column', 10, 2);



// Add Languages & Scripts Metabox to Admin Post Editor
function add_languages_scripts_metabox() {
    add_meta_box(
        'languages_scripts_metabox',
        'Languages & Scripts',
        'render_languages_scripts_metabox',
        'post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_languages_scripts_metabox');


// Render the Languages & Scripts metabox on post edit admin page
function render_languages_scripts_metabox($post) {
    $languages = get_post_meta($post->ID, 'languages_meta', true);
    $scripts = get_post_meta($post->ID, 'scripts_meta', true);

    $languages = $languages ? json_decode($languages, true) : [];
    $scripts = $scripts ? json_decode($scripts, true) : [];

    wp_nonce_field('save_languages_scripts', 'languages_scripts_nonce');

    ?>
    <h3>Languages</h3>
    <div id="languages-container">
        <?php foreach ($languages as $index => $language) : ?>
            <div class="language-entry">
                <input type="text" name="languages[<?php echo $index; ?>][name]" value="<?php echo esc_attr($language['name']); ?>" placeholder="Language Name">
                <input type="text" name="languages[<?php echo $index; ?>][code]" value="<?php echo esc_attr($language['code']); ?>" placeholder="Code">
                <input type="text" name="languages[<?php echo $index; ?>][standard]" value="<?php echo esc_attr($language['standard']); ?>" placeholder="Standard">
                <button type="button" class="remove-entry">Remove</button>
            </div>
        <?php endforeach; ?>
    </div>
    <button type="button" id="add-language">Add Language</button>

    <h3>Scripts</h3>
    <div id="scripts-container">
        <?php foreach ($scripts as $index => $script) : ?>
            <div class="script-entry">
                <input type="text" name="scripts[<?php echo $index; ?>][name]" value="<?php echo esc_attr($script['name']); ?>" placeholder="Script Name">
                <input type="text" name="scripts[<?php echo $index; ?>][code]" value="<?php echo esc_attr($script['code']); ?>" placeholder="Code">
                <input type="text" name="scripts[<?php echo $index; ?>][standard]" value="<?php echo esc_attr($script['standard']); ?>" placeholder="Standard">
                <button type="button" class="remove-entry">Remove</button>
            </div>
        <?php endforeach; ?>
    </div>
    <button type="button" id="add-script">Add Script</button>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('add-language').addEventListener('click', function () {
            let container = document.getElementById('languages-container');
            let index = container.children.length;
            let entry = document.createElement('div');
            entry.classList.add('language-entry');
            entry.innerHTML = '<input type="text" name="languages[' + index + '][name]" placeholder="Language Name">' +
                '<input type="text" name="languages[' + index + '][code]" placeholder="Code">' +
                '<input type="text" name="languages[' + index + '][standard]" value="ISO 639-3" placeholder="Standard">' + // Pre-fill standard
                '<button type="button" class="remove-entry">Remove</button>';
            container.appendChild(entry);
        });

        document.getElementById('add-script').addEventListener('click', function () {
            let container = document.getElementById('scripts-container');
            let index = container.children.length;
            let entry = document.createElement('div');
            entry.classList.add('script-entry');
            entry.innerHTML = '<input type="text" name="scripts[' + index + '][name]" placeholder="Script Name">' +
                '<input type="text" name="scripts[' + index + '][code]" placeholder="Code">' +
                '<input type="text" name="scripts[' + index + '][standard]" value="ISO 15924" placeholder="Standard">' + // Pre-fill standard
                '<button type="button" class="remove-entry">Remove</button>';
            container.appendChild(entry);
        });

        document.addEventListener('click', function (event) {
            if (event.target.classList.contains('remove-entry')) {
                event.target.parentElement.remove();
            }
        });
    });
    </script>

    <style>
        .language-entry, .script-entry {
            margin-bottom: 10px;
        }
        .remove-entry {
            margin-left: 10px;
            color: red;
            cursor: pointer;
        }
    </style>
    <?php
}

// Save the metabox data
function save_languages_scripts_meta($post_id) {
    if (!isset($_POST['languages_scripts_nonce']) || !wp_verify_nonce($_POST['languages_scripts_nonce'], 'save_languages_scripts')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (!current_user_can('edit_post', $post_id)) return;

    // Process Languages
    if (isset($_POST['languages']) && is_array($_POST['languages'])) {
        $languages = array_map(function($lang) {
            if (!empty($lang['code']) && !empty($lang['name'])) {
                $lang['code'] = strtolower($lang['code']); // Ensure lowercase ISO 639-3 language codes
                return $lang;
            }
            return null;
        }, array_values($_POST['languages']));

        $languages = array_filter($languages); // Remove any null values

        if (!empty($languages)) {
            update_post_meta($post_id, 'languages_meta', json_encode($languages, JSON_UNESCAPED_UNICODE));
        } else {
            delete_post_meta($post_id, 'languages_meta');
        }
    } else {
        delete_post_meta($post_id, 'languages_meta');
    }

    // Process Scripts
    if (isset($_POST['scripts']) && is_array($_POST['scripts'])) {
        $scripts = array_map(function($script) {
            if (!empty($script['code']) && !empty($script['name'])) {
                $script['code'] = ucfirst(strtolower($script['code'])); // Ensure ISO 15924 script codes start with uppercase
                return $script;
            }
            return null;
        }, array_values($_POST['scripts']));

        $scripts = array_filter($scripts); // Remove any null values

        if (!empty($scripts)) {
            update_post_meta($post_id, 'scripts_meta', json_encode($scripts, JSON_UNESCAPED_UNICODE));
        } else {
            delete_post_meta($post_id, 'scripts_meta');
        }
    } else {
        delete_post_meta($post_id, 'scripts_meta');
    }
}
add_action('save_post', 'save_languages_scripts_meta');


// Recognize Languages & Scripts base
function add_languages_scripts_rewrite_rule() {
    add_rewrite_rule('^languages-scripts/([^/]*)/?$', 'index.php?pagename=languages-scripts&language=$matches[1]', 'top');
}
add_action('init', 'add_languages_scripts_rewrite_rule');

function lsi_add_query_vars($vars) {
    $vars[] = 'language';
    $vars[] = 'script';
    return $vars;
}
add_filter('query_vars', 'lsi_add_query_vars');



// Generate Posts JSON
function generate_posts_json() {
    $args = [
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => -1,
    ];

    $query = new WP_Query($args);
    $posts = $query->posts;
    $posts_data = [];

    foreach ($posts as $post) {
        setup_postdata($post);
        $post_id = $post->ID;

        // Get authors
        $authors = [];
        if (function_exists('get_coauthors')) {
            $coauthors = get_coauthors($post_id);
        } else {
            $coauthors = [get_userdata($post->post_author)];
        }

        foreach ($coauthors as $author) {
            $roles = $author->roles;
            if (array_intersect($roles, ['author', 'contributor', 'subscriber'])) {
                $authors[] = $author->display_name . ' (' . $author->ID . ')';
            }
        }

        // Get categories
        $categories = [];
        $category_objects = get_the_category($post_id);
        foreach ($category_objects as $cat) {
            $categories[] = $cat->name . ' (' . $cat->term_id . ')';
        }

        // Get tags
        $tags = [];
        $tag_objects = get_the_tags($post_id);
        if (!empty($tag_objects)) {
            foreach ($tag_objects as $tag) {
                $tags[] = $tag->name . ' (' . $tag->term_id . ')';
            }
        }

        // Get languages and scripts
        $languages_raw = get_post_meta($post_id, 'languages_meta', true);
        $scripts_raw = get_post_meta($post_id, 'scripts_meta', true);
        $languages_decoded = is_string($languages_raw) ? json_decode($languages_raw, true) : [];
        $scripts_decoded = is_string($scripts_raw) ? json_decode($scripts_raw, true) : [];

        $languages = [];
        if (is_array($languages_decoded)) {
            foreach ($languages_decoded as $lang) {
                if (!empty($lang['name']) && !empty($lang['code']) && !empty($lang['standard'])) {
                    $languages[] = $lang['standard'] . ': ' . $lang['code'] . ' (' . $lang['name'] . ')';
                }
            }
        }

        $scripts = [];
        if (is_array($scripts_decoded)) {
            foreach ($scripts_decoded as $script) {
                if (!empty($script['name']) && !empty($script['code']) && !empty($script['standard'])) {
                    $scripts[] = $script['standard'] . ': ' . $script['code'] . ' (' . $script['name'] . ')';
                }
            }
        }

        // Use post_id as the key
        $posts_data[$post_id] = [
            'post_title' => get_the_title($post_id),
            'post_date' => get_the_date('Y-m-d', $post_id),
            'last_modified' => get_the_modified_date('Y-m-d', $post_id),
            'authors' => $authors,
            'categories' => $categories,
            'tags' => $tags,
            'date_src_start' => get_post_meta($post_id, 'date_src_start', true),
            'date_src_end' => get_post_meta($post_id, 'date_src_end', true),
            'date_trans_start' => get_post_meta($post_id, 'date_trans_start', true),
            'date_trans_end' => get_post_meta($post_id, 'date_trans_end', true),
            'open_content_license' => get_post_meta($post_id, 'open_content_license', true),
            'languages' => $languages,
            'scripts' => $scripts,
            'post_slug' => $post->post_name,
            'source_link' => home_url('/?p=' . $post_id),
            'permalink' => get_permalink($post_id)
        ];
    }

    wp_reset_postdata();

    $json_data = json_encode($posts_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'posts.json';
    $hash_file_path = trailingslashit($upload_dir['basedir']) . 'posts_hash.txt';

    $current_hash = hash('sha256', $json_data);
    $saved_hash = file_exists($hash_file_path) ? file_get_contents($hash_file_path) : '';

    if ($current_hash !== $saved_hash) {
        file_put_contents($json_file_path, $json_data);
        file_put_contents($hash_file_path, $current_hash);
    }
}

// Schedule the cron job to regenerate posts.json daily
add_action('init', function() {
    if (!wp_next_scheduled('generate_posts_json_cron')) {
        wp_schedule_event(time(), 'daily', 'generate_posts_json_cron');
    }
});

// Hook the cron event to the function
add_action('generate_posts_json_cron', 'generate_posts_json');


/*
add_action('admin_init', function () {
    $timestamp = wp_next_scheduled('generate_posts_json_cron');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'generate_posts_json_cron');
    }
});
*/


add_action('admin_menu', 'export_posts_json_menu');
function export_posts_json_menu() {
    add_submenu_page(
        'edit.php',
        'Export Posts JSON',
        'Export Posts JSON',
        'manage_options',
        'export-posts-json',
        'export_posts_json_page'
    );
}

function export_posts_json_page() {
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'posts.json';
    $json_file_url = trailingslashit($upload_dir['baseurl']) . 'posts.json';

    if (isset($_POST['regenerate_json'])) {
        generate_posts_json();
        echo '<div class="notice notice-success is-dismissible"><p>Posts JSON file regenerated successfully.</p></div>';
    }

    echo '<div class="wrap">';
    echo '<h1>Export Posts JSON</h1>';
    echo '<form method="POST"><input type="hidden" name="regenerate_json" value="1">';
    echo '<button type="submit" class="button button-secondary">Regenerate JSON</button></form>';

    if (file_exists($json_file_path)) {
        echo '<a href="' . esc_url($json_file_url) . '" class="button button-primary" download>Download JSON</a>';
    } else {
        echo '<p><em>JSON file not found. Please regenerate the file first.</em></p>';
    }

    echo '</div>';
}


// Add "Export Tags JSON" submenu under Posts
add_action('admin_menu', function () {
    add_submenu_page(
        'edit.php',
        'Export Tags JSON',
        'Export Tags JSON',
        'manage_options',
        'export-tags-json',
        'export_tags_json_page'
    );
});

// Callback to export the tags JSON
function export_tags_json_page() {
    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'tags.json';
    $json_file_url = trailingslashit($upload_dir['baseurl']) . 'tags.json';

    if (isset($_POST['regenerate_json'])) {
        generate_tags_json();
        echo '<div class="notice notice-success is-dismissible"><p>Tags JSON file regenerated successfully.</p></div>';
    }

    echo '<div class="wrap">';
    echo '<h1>Export Tags JSON</h1>';
    echo '<form method="POST"><input type="hidden" name="regenerate_json" value="1">';
    echo '<button type="submit" class="button button-secondary">Regenerate JSON</button></form>';

    if (file_exists($json_file_path)) {
        echo '<a href="' . esc_url($json_file_url) . '" class="button button-primary" download>Download Tags JSON</a>';
    } else {
        echo '<p><em>JSON file not found. Please regenerate the file first.</em></p>';
    }

    echo '</div>';
}


// Function to generate the tags.json file
function generate_tags_json() {
    $tags = get_tags(['hide_empty' => false]);
    $tags_data = [];

    foreach ($tags as $tag) {
        $post_ids = get_objects_in_term($tag->term_id, 'post_tag');

        $tags_data[] = [
            'tag_id' => $tag->term_id,
            'tag_name' => $tag->name,
            'tag_slug' => $tag->slug,
            'post_ids' => $post_ids,
        ];
    }

    $json_data = json_encode($tags_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    $upload_dir = wp_upload_dir();
    $json_file_path = trailingslashit($upload_dir['basedir']) . 'tags.json';

    return file_put_contents($json_file_path, $json_data) !== false ?: 'Failed to write file.';
}



function opensiddur_start_output_buffer() {
    ob_start('opensiddur_filter_footer_scripts');
}
add_action('wp_head', 'opensiddur_start_output_buffer');

function opensiddur_filter_footer_scripts($content) {
    if (!is_single()) {
        // Remove Sefaria v2 linker.js only (preserve v3)
        $content = preg_replace('#<script[^>]+sefaria\.org/linker\.js[^>]*></script>#', '', $content);
        
        // Keep linker.v3.js! Don't remove that one.

        // Remove other unused scripts from non-single views
        $content = preg_replace('#<script[^>]+sortable\.js[^>]*></script>#', '', $content);
        $content = preg_replace('#<script[^>]+column-toggle-container\.js[^>]*></script>#', '', $content);
        $content = preg_replace('#<script[^>]+dragtable\.js[^>]*></script>#', '', $content);
        $content = preg_replace('#<script[^>]+advanced-iframe/js/ai_external\.js[^>]*></script>#', '', $content);
        
        // Optional: remove v2-style inline init script
        $content = preg_replace('#<script>\s*sefaria\.link\([^)]*\);\s*</script>#', '', $content);
    }

    return $content;
}

function custom_fonts_stylesheet() {
    wp_enqueue_style('custom-fonts', get_stylesheet_directory_uri() . '/css/custom-fonts.css');
}
add_action('wp_enqueue_scripts', 'custom_fonts_stylesheet');

/*
add_action('init', 'load_plugin_translations', 0);
function load_plugin_translations() {
    load_textdomain('ajax-search-pro', WP_LANG_DIR . '/plugins/ajax-search-pro-' . get_locale() . '.mo');
    load_textdomain('favorites', WP_LANG_DIR . '/plugins/favorites-' . get_locale() . '.mo');
    load_textdomain('user-verification', WP_LANG_DIR . '/plugins/user-verification-' . get_locale() . '.mo');
}
*/


/*
// Display rewrite rules (Warning: Use extremely briefly!)
add_action('init', function() {
    global $wp_rewrite;
    echo '<pre>'; print_r($wp_rewrite->wp_rewrite_rules()); echo '</pre>';
    exit;
});
*/

?>