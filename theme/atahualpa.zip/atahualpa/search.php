<?php 
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();
get_header(); 
extract($bfa_ata); 
global $bfa_ata_postcount;
?>

<?php /* If there are any posts: */
if (have_posts()) : $bfa_ata_postcount = 0; /* Postcount needed for option "XX first posts full posts, rest excerpts" */ ?>

    <?php  if ($bfa_ata['widget_center_top'] <> '') { 
          echo bfa_parse_widget_areas($bfa_ata['widget_center_top']); 
	} ?>

	<?php // Deactivated since 3.6.5
	# include 'bfa://content_above_loop'; 
	// Uses the following static code instead: ?>

	<?php if (is_search() && isset($_GET['s'])) {
        echo "<p><br><div style='padding-left: 60px;'><span style='font-size: x-large;'><strong>search results for: `".$_GET['s']."`</strong></span></div><p><br>";
    } ?>
    <?php echo do_shortcode('[wpdreams_ajaxsearchpro id=3]'); ?>
    <?php echo "<p><br>"; ?>
	<?php $showpost=1; ?>
	<?php if  (is_category()) {
		if ( has_term_have_children(get_queried_object_id()) ) {
			$showpost=0;
			// echo "this is a category page with subcategories. ($showpost)<p />"; 
		} 
	} ?>

	<?php 
	if ($showpost) { 
	    echo '<div align="right">';
	    the_posts_pagination();
	    echo '</div>';
	    echo do_shortcode('[spacer height="20px"]');
	}
	?>

	<?php  while (have_posts()) : the_post(); $bfa_ata_postcount++; ?>

		<?php // Deactivated since 3.6.5
		#include 'bfa://content_inside_loop'; 
		// Uses the following static code instead: ?>


		<?php /* Post Container starts here */
		if ( function_exists('post_class') ) { ?>

			<?php if ($showpost) { ?>

				<div <?php if ( is_page() ) { post_class('post'); } else { post_class(); } ?> id="post-<?php the_ID(); ?>">

			<?php } ?>

			<?php } else { ?>

				<div class="<?php echo ( is_page() ? 'page ' : '' ) . 'post" id="post-'; the_ID(); ?>">

			<?php } ?>

			
		<?php $current_id = $post->ID ?> 			
		<?php if ($showpost) bfa_post_headline('<div class="post-headline"><h1><a style="text-decoration: none; color: inherit;" href="/?p=' . $current_id . '">','</a></h1></div>'); ?>


		<?php bfa_archives_page('<div class="archives-page">','</div>'); // Archives Pages. Displayed on a specific static page, if configured at ATO -> Archives Pages: ?>
		

		</div><!-- / Post -->	
						
	<?php endwhile; ?>
	
	<?php // Deactivated since 3.6.5
	# include 'bfa://content_below_loop'; 
	// Uses the following static code instead: ?>

	<?php bfa_get_comments(); // Load Comments template (on single post pages, and static pages, if set on options page): ?>
	<?php if ($showpost) { 
	    echo '<hr /><center>';
	    the_posts_pagination();
	    echo '</center>';
	} // Displayed on MULTI post pages if activated at ATO -> Next/Previous Navigation: ?>	
			

    <?php if ($bfa_ata['widget_center_bottom'] <> '') {  
          echo bfa_parse_widget_areas($bfa_ata['widget_center_bottom']); 
    } ?> 

<?php /* END of: If there are any posts */
else : /* If there are no posts: */ ?>

<?php // Deactivated since 3.6.5
#include 'bfa://content_not_found'; 
// Uses the following static code instead: ?>

<?php 
    echo '<span style="font-size: large;">&#x2937;</span>&nbsp;';
    echo "You are here:&nbsp;&nbsp;  Search results for `".$_GET['s']."` &#x27B2; Nothing found, alas!<hr />"; 
?>

    <?php echo "<p><br><div style='padding-left: 60px;'><span style='font-size: x-large;'><strong>search results for: `".$_GET['s']."`</strong></span></div><p><br>"; ?>
    <p><?php _e("Nothing found, alas! Try again with another query","atahualpa"); ?></p>
    <?php echo do_shortcode('[wpdreams_ajaxsearchpro id=3]'); ?>
    <?php echo "<p><br>"; ?>
    <?php echo "
<div class='english' lang='en' style='font-size: 1.2em;'>
Note: If searching for a term in transliterated (romanized) Hebrew, the following transliteration schema will aid you.
<p style='padding-left: 40px;'> <span class='latin' lang='la'>אַ = a<br />
אָ = a<br />
אׇ = o<br />
אֵ = e, é, a<br />
אֵי = ei<br />
אֶ = e<br />
אִ = i<br />
אְ = e, ə<br />
אֻ = u<br />
אֹ = o<br />
בּ = b<br />
ב = v, ḇ<br />
ג = g<br />
ד = d<br />
ה = h<br />
הּ = h<br />
ו = v<br />
וּ = u<br />
וֹ = o<br />
ז = z<br />
ח = Ḥ/ḥ (<em>Ḥanukkah, ḥaroset</em>)<br />
ט = t<br />
י = y<br />
כּ = k (<em>kavod</em>)<br />
כ = kh (<em>ana b’khoaḥ</em>)<br />
ל = l<br />
מ = m<br />
נ = n<br />
ס = s<br />
ע = a (as for alef, above), Ŋ/ŋ<br />
פּ = p<br />
פ = f<br />
צ = ts (<em>tsitsit</em>, <em>mitsvah</em>), ẓ (<em>yahrẓeit</em>)<br />
ק = Q/q, Ḳ/ḳ (<em>ḳaddish</em>, <em>Qoraḥ</em>)<br />
ר = r<br />
שׁ = sh<br />
שׂ = s<br />
תּ = t<br />
ת = t</span></p>
</div>"; ?>



<?php endif; /* END of: If there are no posts */ ?>

<?php get_footer(); ?>