<?php 
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();
get_header(); 
extract($bfa_ata); 
global $bfa_ata_postcount;
?>

<?php /* Check if there are any posts: */
    if (have_posts()) : $bfa_ata_postcount = 0; /* Postcount needed for option "XX first posts full posts, rest excerpts" */ 
?>

<?php  if ($bfa_ata['widget_center_top'] <> '') { 
      echo bfa_parse_widget_areas($bfa_ata['widget_center_top']); 
} ?>

<?php 
    $showpost=1; // This is, essentially, a kludge to distinguish "category pages with posts" from "category pages with subcategories." (We don't want to show posts in the latter.) 
?>
	
<?php if (is_category() || is_tag()) { 
	
    if (is_category()) {
	    
	    if ( has_term_have_children(get_queried_object_id()) ) {
		    $showpost=0; // this is a category page with subcategories. only terminal subcategories contain posts. (only in terminal subcategories should we display posts with $showpost=1)
		    // echo "this is a category page with subcategories, not a terminal subcategory<p />"; 
	    } 
	    
        $cattart = get_queried_object(); // Get the current category object
        $cattart_id = $cattart->term_id; // Get the category ID

        // Generate sibling links
        $siblinks = generate_siblinks($cattart_id);

    	// Display sibling links row above the category container
    	echo '<div class="siblink-row" style="display: flex; justify-content: space-between; margin-bottom: 20px;">';

    	// Placeholder or actual "previous" link
    	echo '<div class="previous-siblink">' . ($siblinks['previous'] ?? '') . '</div>';

    	// Placeholder or actual "next" link
    	echo '<div class="next-siblink">' . ($siblinks['next'] ?? '') . '</div>';

    	echo '</div>';

        echo do_shortcode('[spacer height="40px"]');

        echo '<div class="category-description-container">';

        // Category Image & SVG Frame
        echo do_shortcode( '[custom_category_grid svg_width="350" image_percentage="85" image_size="medium" show_title="false" term_ids="' . esc_attr($cattart_id) . '"] ' );

        // Category Title & Description logic
        echo '<div class="category-details">';
        // echo do_shortcode('[spacer height="20px"]');
        echo '<h3 class="category-title" style="font-size: x-large;">';
        echo '<a href="/index.php?cat=' . esc_attr($cattart_id) . '" style="text-decoration: none; color: inherit; line-height: 1.5em;">';
        echo esc_html(single_cat_title('', false));
        echo '</a>';
        echo '</h3>';

        // Display term description if available
        $description = term_description();
        if (!empty($description)) {
            // echo '<div class="category-description">' . $description . '</div>';
            echo do_shortcode('[enhanced_category_description]');
        }

        echo '</div>'; // Close category-details
        echo '</div>'; // Close category-description-container

        // echo do_shortcode('[spacer height="40px"]');


        // Display tabs if there is a complementary category
        $upload_dir = wp_upload_dir(); // Load categories.json from uploads directory
        $categories_file = trailingslashit($upload_dir['basedir']) . 'categories.json';
        $categories_json = file_get_contents($categories_file);
        $categories_data = json_decode($categories_json, true);

        // Index categories by ID
        $categories_by_id = [];
        foreach ($categories_data as $cat) {
            $categories_by_id[$cat['id']] = $cat;
        }

        // Get current category ID
        $current_cat_id = get_queried_object_id();
        $current_cat = $categories_by_id[$current_cat_id] ?? null;

        if ($current_cat && !empty($current_cat['complementary_cat_id'])) {
            // Build full list: current category + its complements
            $ordered_cats = [$current_cat];
            foreach ($current_cat['complementary_cat_id'] as $comp_id) {
                if (isset($categories_by_id[$comp_id])) {
                    $ordered_cats[] = $categories_by_id[$comp_id];
                }
            }

            // Sort by stub for consistent prefix detection
            usort($ordered_cats, function($a, $b) {
                return strcasecmp($a['stub'], $b['stub']);
            });

            // Find longest common prefix based on slug ('stub')
            $stubs = array_column($ordered_cats, 'stub');
            $prefix = $stubs[0];
            foreach ($stubs as $stub) {
                while (strpos($stub, $prefix) !== 0) {
                    $prefix = substr($prefix, 0, -1);
                    if ($prefix === '') break;
                }
            }
            $prefix = trim($prefix);

            // Render tabs using names, but trim prefix based on stub logic
            echo '<div class="complementary-tabs" style="margin-top: 30px;">';
            echo '<div class="tabs">';

            foreach ($ordered_cats as $cat) {
                $is_active = ($cat['id'] === $current_cat_id);
                $cat_url = get_category_link($cat['id']);

                // Get label suffix from stub
                $label = $cat['name']; // fallback
                if (strpos($cat['stub'], $prefix) === 0) {
                    $suffix = substr($cat['stub'], strlen($prefix));
                    $suffix = trim(str_replace('-', ' ', $suffix));
                    if (!empty($suffix)) {
                        $label = ucwords($suffix);
                    } else {
                        $label = 'Prayers';
                    }
                }

                $label = esc_html($label);

                if ($is_active) {
                    echo "<span class='tab-button active'>{$label}</span>";
                } else {
                    echo "<a class='tab-button' href='" . esc_url($cat_url) . "'>{$label}</a>";
                }
            }

            echo '</div></div>';
        }


        // Show Category's subcategories
        $category = get_queried_object(); 
        echo do_shortcode( '<p /><br />[custom_category_grid svg_width="300" image_percentage="85" image_size="medium" gap="20" sub_categories="true" sort="term_order" term_ids="'.$category->term_id.'"] ' ); 
        // echo do_shortcode('[spacer height="40px"]');        
    }


    if (is_tag()) { 
        $taggart = get_queried_object(); // Get the current tag object
        $taggart_id = $taggart->term_id; // Get the tag ID

        echo do_shortcode('[spacer height="40px"]');
        echo '<div class="category-description-container"><span class="category-title">';
        // Add the tag_ID to the URL
        echo '<a href="/index.php?tag_ID=' . esc_attr($taggart_id) . '" style="text-decoration: none; color: inherit; line-height: 1.5em;"><strong>&#x1F516; ' . single_cat_title('', false) . '</strong></a>';
        echo '</span></div>'; 
        echo do_shortcode('[spacer height="40px"]');
    }


    if ($showpost) { 

		// Display filter message if a category, tag, or collaborator filter is applied
    	$filter_message = '';

        // Get the base category URL (unfiltered)
        $category = get_queried_object();
        $base_url = get_category_link($category->term_id);

		// Handle category filter
		if (isset($_GET['caat'])) {
		    $category = get_category_by_slug($_GET['caat']);
		    if ($category) {
		        $filter_message = 'Resources filtered by CATEGORY: “' . esc_html($category->name);
		    }
		} 
		// Handle tag filter
		elseif (isset($_GET['taag'])) {
		    $tag = get_term_by('slug', $_GET['taag'], 'post_tag');
		    if ($tag) {
		        $filter_message = 'Resources filtered by TAG: “' . esc_html($tag->name);
		    }
		} 
		// Handle collaborator filter
		elseif (isset($_GET['col'])) {
		    $collab_id = intval($_GET['col']);
		    $collab_user = get_user_by('ID', $collab_id);
		    if ($collab_user) {
		        $filter_message = 'Resources filtered by COLLABORATOR: “' . esc_html($collab_user->display_name);
		    }
		}
		
		// Handle language filter
		elseif (isset($_GET['language']) && isset($_GET['language_name'])) {
		    $filter_message = 'Resources filtered by LANGUAGE: “' . esc_html(urldecode($_GET['language_name'])) . '”';
		}

		// Handle date range filter		
		elseif (isset($_GET['daterange_start']) && isset($_GET['daterange_end'])) {
		    $start = (int) $_GET['daterange_start'];
		    $end = (int) $_GET['daterange_end'];

		    $start_label = ($start < 0) ? abs($start) . ' BCE' : $start . ' CE';
		    $end_label = ($end < 0) ? abs($end) . ' BCE' : $end . ' CE';

		    if ($start && $end) {
		        $filter_message = 'Resources filtered by DATE RANGE: “' . esc_html($start_label) . ' to ' . esc_html($end_label) . '”';
		    }
		}


		// Display the filter message if it's set
		if ($filter_message) {
		    // echo '<div class="filter-message" style="font-size: 18px; margin-bottom: 20px;">' . $filter_message . '</div>';
	        echo '<div class="filter-message" style="font-size: 18px; margin-bottom: 20px;">';
		    echo $filter_message . '” <a href="' . esc_url($base_url) . '" style="font-size: 16px; color: #0073aa;">(clear filter)</a>';
            echo '</div>';
		    echo do_shortcode('[spacer height="30px"]');
		}


	    // Pagination -->
		    
		echo '<div align="right">';
		the_posts_pagination();
		echo '</div>';
		// echo do_shortcode('[spacer height="20px"]');

		bfa_next_previous_page_links('Top'); // For MULTI post pages if activated at ATO -> Next/Previous Navigation:
			

        // Sort options for posts -->

			
	    // Check if 'order' is set in the query string
	    $current_order = isset($_GET['order']) ? $_GET['order'] : 'desc'; 
	    
	    // Determine the opposite order for toggling
	    $next_order = ($current_order === 'desc') ? 'asc' : 'desc';
		    
	    // Generate the base URL (keeping any existing query parameters like category or tag)
        $base_url = add_query_arg(array(
            'order' => $next_order,
        ));	
		    
	    // Display a single toggle link based on current order
	    echo '<div class="sort-options">';
	    echo '<span style="text-decoration: underline; text-underline-offset: 10px; text-decoration-thickness: from-font;">';
	    if ($current_order === 'desc') {
	        // echo 'Sorted Chronologically (old to new). Sort <a href="?order=asc">most recent first</a>?';
	        echo 'Sorted Chronologically (old to new). Sort <a href="' . esc_url($base_url) . '">most recent first</a>?';
	    } else {
	        // echo 'Sorted Chronologically (new to old). Sort <a href="?order=desc">oldest first</a>?';
	        echo 'Sorted Chronologically (new to old). Sort <a href="' . esc_url($base_url) . '">oldest first</a>?';
	    }
	    echo '</span></div>';
		echo do_shortcode('[spacer height="40px"]');	    
    }
} ?>
	
	
<?php while (have_posts()) : the_post(); $bfa_ata_postcount++; ?>

<?php // Deactivated since 3.6.5
	#include 'bfa://content_inside_loop'; 
	// Uses the following static code instead: 
?>


<?php bfa_next_previous_post_links('Top'); // For SINGLE post pages if activated at ATO -> Next/Previous Navigation  ?>


<?php /* Post Container starts here */

	if ( function_exists('post_class') ) { ?>

		<?php if ($showpost) { ?>

		    <div <?php if ( is_page() ) { post_class('post'); } else { post_class(); } ?> id="post-<?php the_ID(); ?>">

		<?php } ?>

	<?php } else { ?>

		<div class="<?php echo ( is_page() ? 'page ' : '' ) . 'post" id="post-'; the_ID(); ?>">

	<?php } ?>

	<?php if ($showpost) bfa_post_kicker('<div class="post-kicker">','</div>'); ?>
			
	<?php $current_id = $post->ID ?> 	
		
	<?php if ($showpost) { // Check if the post is new
		
        $created = new DateTime(get_the_date('Y-m-d H:i:s', $current_id));
        $current = new DateTime(current_time('mysql'));
        $created_to_today = $created->diff($current);
        $is_new = ($created_to_today && $created_to_today->days < 31);
            
        if ($is_new) {
            $newemoji = '&#x1F195; ';
        } else { 
            $newemoji = '';
        } 
            
	    // bfa_post_headline('<div class="post-headline"><h1><a style="text-decoration: none; color: inherit;" href="/?p=' . $current_id . '">','</a></h1></div>'); 
	    
	    
        echo '<div class="post-headline" style="display: flex; align-items: flex-start; justify-content: space-between;">';

        // Output the headline
        echo '<h1 style="margin: 0;"><a style="text-decoration: none; color: inherit;" href="/?p=' . $current_id . '">' . $newemoji . get_the_title() . '</a></h1>';

        // Show the Favorites button only on single post views
        if ( is_single() ) {
            echo do_shortcode('[favorite_button]');
        }

        echo '</div>'; // end .post-headline
    
	} ?>
    
	<?php if ($showpost) bfa_post_byline('<div class="post-byline">','</div>'); ?>
		
	<?php if (is_page()) bfa_post_bodycopy('<div class="post-bodycopy clearfix">','</div>'); ?>		

	<?php if (is_single()) bfa_post_bodycopy('<div class="post-bodycopy clearfix">','</div>'); ?>

	<?php if (is_single()) {				

        if (class_exists('coauthors_plus')) {  // Check if Co-Authors Plus plugin is active
            $co_authors = get_coauthors();  // Get all co-authors for the post

            echo '<hr /><div class="print-only" style="background-color: #EEEEEE; padding: 20px;">';

            foreach ($co_authors as $key => $co_author) {
                $co_author_classes = array(
                    'co-author-wrap',
                    'co-author-number-' . ($key + 1),
                );

                // Use CSS grid for layout

                echo '<div class="co-author-wrap co-author-number-' . ($key + 1) . '">';
    
                // Avatar
                echo '<div class="co-author-avatar">';
                echo '<a href="/profile/' . $co_author->user_nicename . '">';
                echo get_avatar($co_author->user_email, '96');
                echo '</a>';
                echo '</div>';

                // Content wrapper (name and bio)
                echo '<div class="co-author-content">';
                echo '<div class="co-author-display-name">';
                echo '<a href="/profile/' . $co_author->user_nicename . '">';
                echo $co_author->display_name;
                echo '</a>';
                echo '</div>';

                if ($description = get_the_author_meta('description', $co_author->ID)) {
                    echo '<div class="co-author-bio">' . $description . '</div>';
                }
                echo '</div>'; // end content
                echo '</div>'; // end wrap

                // Add a spacer between entries (optional)
                echo '<div style="height: 10px; clear: both;"></div>';
            }

            echo '</div>';  // Close print-only div
            echo '<span style="display: block; clear: both; height: 20px;"></span>';
        }
	} ?>
			
	<?php bfa_post_pagination('<p class="post-pagination"><strong>'.__('Pages:','atahualpa').'</strong>','</p>'); ?>
		
	<?php bfa_archives_page('<div class="archives-page">','</div>'); // Archives Pages. Displayed on a specific static page, if configured at ATO -> Archives Pages: ?>
		
	<?php if ($showpost) { echo do_shortcode('[spacer height="40px"]'); } ?>

	<?php if (is_single()) {
		    
	    bfa_post_footer('<div class="post-footer">','</div>');
	    
		// echo wp_kses_post( scriptlesssocialsharing_do_buttons() );

	    echo do_shortcode('[social_sharing]');

		// if ( function_exists( 'sharing_display' ) ) {
            // echo sharing_display( '', true );
        // }
        
	    echo '<div class="accordion"><h2>Read a comment / Leave a comment (moderated)</h2></div>';
        echo '<div class="panel">';
	    // echo do_shortcode('[expander_maker id="2" more="OPEN COMMENTS" less="CLOSE COMMENTS"]');
	    bfa_get_comments(); // Load Comments template (on single post pages, and static pages, if set on options page): 
	    // echo do_shortcode('[/expander_maker]');
        echo '</div>';        
			
		if(function_exists('get_related_posts_slider')) { 
			echo '&nbsp;<p />';
			get_related_posts_slider(); // alternately, if this plugin dies: echo do_shortcode('[yarpp]');
			echo '&nbsp;<p />';
		} 
	} ?>
		
	</div> <!-- A safety div(?) -->
		

	<!-- / Post -->

	<?php endwhile; ?>

	<?php // Deactivated since 3.6.5
	# include 'bfa://content_below_loop'; 
	// Uses the following static code instead: ?>


	<?php bfa_next_previous_post_links('Middle'); // Displayed on SINGLE post pages if activated at ATO -> Next/Previous Navigation: ?>
	
	<?php bfa_next_previous_post_links('Bottom'); // Displayed on SINGLE post pages if activated at ATO -> Next/Previous Navigation: ?>
	
	<?php if ($showpost) { 
	    // bfa_next_previous_page_links('Bottom'); 
	    echo '<center>';
	    the_posts_pagination();
	    echo '</center>';
	    echo do_shortcode('[spacer height="40px"]');
	    
        if (is_category()) { 
	        bfa_post_footer('<div class="post-footer">','</div>'); 
        } 
	    
	} // Displayed on MULTI post pages if activated at ATO -> Next/Previous Navigation: ?>


	<?php if (is_page()) { 
	    bfa_post_footer('<div class="post-footer">','</div>'); 
	    //echo wp_kses_post( scriptlesssocialsharing_do_buttons() );

        echo do_shortcode('[social_sharing]');

	    // if ( function_exists( 'sharing_display' ) ) {
            // echo sharing_display( '', true );
        // }
	} ?>

    <?php if ($bfa_ata['widget_center_bottom'] <> '') {  
          echo bfa_parse_widget_areas($bfa_ata['widget_center_bottom']); 
    } ?> 

<?php /* END of: If there are any posts */
else : /* If there are no posts: */ ?>

<?php // Deactivated since 3.6.5
#include 'bfa://content_not_found'; 
// Uses the following static code instead: ?>
<h2><?php _e('Not Found','atahualpa'); ?></h2>
<p><?php _e("Sorry, but you are looking for something that isn't here.","atahualpa"); ?></p>
<?php endif; /* END of: If there are no posts */ ?>

<?php if ( ( is_category() || is_tag() ) && ! empty( $showpost ) ) {    
    echo do_shortcode('[social_sharing]');
} ?>


<?php get_footer(); ?>