<?php
get_header();
?>

<div class="container">
    <h1><?php single_term_title(); ?></h1>
    <p><?php echo term_description(); ?></p>

    <?php
    $term = get_queried_object();
    $user_ids = get_objects_in_term($term->term_id, 'user_tag');

    if ($user_ids) {
        $users = get_users(array('include' => $user_ids));

        if ($users) {
            echo '<ul class="author-list">';
            foreach ($users as $user) {
                echo '<li class="author">';
                echo '<div class="author-photo">' . get_avatar($user->user_email, '100') . '</div>';
                echo '<div class="author-info">';
                echo '<h2><a href="' . get_author_posts_url($user->ID) . '">' . esc_html($user->display_name) . '</a></h2>';
                echo '<p>' . esc_html($user->description) . '</p>';
                echo '</div>';
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo '<p>No authors found for this tag.</p>';
        }
    } else {
        echo '<p>No authors found for this tag.</p>';
    }
    ?>
</div>

<?php
get_footer();
?>
