<?php
/* Template Name: Languages & Scripts */
get_header();
?>


<?php 
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();
extract($bfa_ata); 
global $bfa_ata_postcount;

// Get language or script filter from query
$language_code = isset($_GET['language']) ? sanitize_text_field($_GET['language']) : '';
$script_code = isset($_GET['script']) ? sanitize_text_field($_GET['script']) : '';
$language_name = isset($_GET['language_name']) ? urldecode($_GET['language_name']) : '';
//$language_name = urldecode(get_query_var('language_name', 'Language'));
$script_name = isset($_GET['script_name']) ? urldecode($_GET['script_name']) : '';
//$script_name = urldecode(get_query_var('script_name', 'Script'));


$page_title = $language_code ? "Resources in $language_name (language)" : ($script_code ? "Resources in $script_name (script)" : "Languages & Scripts");
?>

<!-- The following lines are needed to show the breadcrumb and the <hr> on the following line -->
<?php if ($bfa_ata['widget_center_top'] <> '') { 
    echo bfa_parse_widget_areas($bfa_ata['widget_center_top']); 
} ?>
<div class="<?php echo ( is_page() ? 'page ' : '' ) . 'post" id="post-'; the_ID(); ?>">

<div class="container" style="display: flex; align-items: center; gap: 20px;">

    <!-- Image for Languages or Scripts -->
    <div id="langscriptimg-size" style="flex-shrink: 0; width: 96px;">
        <?php if ($language_code) : ?>
            <img alt="Languages" src="https://opensiddur.org/wp-content/uploads/2025/03/speech-bubbles.png" class="langscriptimg" height="96" width="96" style="height:96px;width:100%; border-radius: 8px;">
        <?php elseif ($script_code) : ?>
            <img alt="Scripts" src="https://opensiddur.org/wp-content/uploads/2025/03/script-quill-ink.png" class="langscriptimg" height="96" width="96" style="height:96px;width:100%; border-radius: 8px;">
        <?php endif; ?>
    </div>

    <!-- Title -->
    <h1 style="margin: 0;">
        <?php if ($language_code) : ?>
            Resources employing <?php echo esc_html($language_name); ?> language
        <?php elseif ($script_code) : ?>
            Resources using <?php echo esc_html($script_name); ?> script
        <?php else : ?>
            Languages & Scripts
        <?php endif; ?>
    </h1>

</div>

<!-- Back to Index -->
<p><a href="<?php echo esc_url(home_url('/languages-scripts-index/')); ?>">&larr; Back to Languages & Scripts Index</a></p>

    <?php echo do_shortcode('[spacer height="20px"]'); ?>

    <?php 
    $paged = get_query_var('paged') ? get_query_var('paged') : 1; 
        
    $args = [
        'post_type'      => 'post',
        'posts_per_page' => 50, // Adjust as needed
        'paged'          => $paged,
        'meta_query'     => [
        'relation' => 'AND',
        ],
    ];

    if ($language_code) {
        $args['meta_query'][] = [
            'key'     => 'languages_meta',
            'value'   => '"code":"' . $language_code . '"',
            'compare' => 'LIKE'
            ];
    }

    if ($script_code) {
        $args['meta_query'][] = [
        'key'     => 'scripts_meta',
        'value'   => '"code":"' . $script_code . '"',
        'compare' => 'LIKE'
        ];
    }

    $query = new WP_Query($args);



    if ($query->have_posts()) :
            
        // Pagination Above (aligned right)
        echo '<div class="pagination" style="text-align: right; margin-bottom: 20px;">';
        echo paginate_links([
            'total'   => $query->max_num_pages,
            'current' => max(1, get_query_var('paged')),
            'format'  => '?paged=%#%',
            'prev_text' => '← Previous',
            'next_text' => 'Next →',
        ]);
        echo '</div>';

        // Loop Through Posts
        while ($query->have_posts()) : $query->the_post(); ?>
            <div class="post">
                <h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php if ($newemoji) { echo $newemoji; } ?><?php the_title(); ?></a></h3>
                <div><?php the_excerpt(); ?></div>
            </div>
        <?php endwhile; 
        
        // Pagination Controls
        echo '<div class="pagination" style="text-align: center; margin-top: 20px;">';
        echo paginate_links([
            'total'   => $query->max_num_pages,
            'current' => max(1, get_query_var('paged')),
            'format'  => '?paged=%#%', // Ensures pagination URLs work
            'prev_text' => '← Previous',
            'next_text' => 'Next →',
        ]);
        echo '</div>';
        
    else :
        echo '<p>No resources found.</p>';
    endif;
    
    wp_reset_postdata();
    ?>
</div>

<?php get_footer(); ?>
