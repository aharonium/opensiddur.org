jQuery(document).ready(function($) {
    console.log('Custom Admin Script Loaded'); // Debug

    $('.menu-order-input').on('change', function() {
        var postId = $(this).data('post-id');
        var newOrder = $(this).val();

        console.log('Post ID:', postId); // Debug
        console.log('New Order:', newOrder); // Debug

        $.ajax({
            url: customAdminAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'update_menu_order',
                post_id: postId,
                new_order: newOrder,
                nonce: customAdminAjax.nonce
            },
            success: function(response) {
                console.log('AJAX Response:', response); // Debug
                if (response.success) {
                    location.reload(); // Reload to reflect changes
                } else {
                    alert('Error updating menu order: ' + response.data);
                }
            },
            error: function() {
                console.log('AJAX Error:', arguments); // Debug
                alert('An error occurred while processing your request.');
            }
        });
    });
});