<?php
/* Template Name: License Results */

// Redirect to index page if no license or category query is present
if (
    ! isset($_GET['license']) ||
    ! isset($_GET['category'])
) {
    wp_redirect(home_url('/license-index/'), 301);
    exit;
}

get_header();
?>


<?php
list($bfa_ata, $cols, $left_col, $left_col2, $right_col, $right_col2, $bfa_ata['h_blogtitle'], $bfa_ata['h_posttitle']) = bfa_get_options();
extract($bfa_ata);
global $bfa_ata_postcount;

// Get license slug and category id from query
$license_slug = isset($_GET['license']) ? sanitize_text_field($_GET['license']) : '';
$category_id = isset($_GET['category']) ? (int) $_GET['category'] : 0;

$roots = function_exists('lix_get_root_categories') ? lix_get_root_categories() : array();
$tabs  = function_exists('lix_get_license_tabs') ? lix_get_license_tabs() : array();

// Look up display label for this license slug
$license_label = '';
$matched_internal_value = null;
foreach ($tabs as $internal_value => $def) {
    if ($def['slug'] === $license_slug) {
        $license_label = $def['label'];
        $matched_internal_value = $internal_value;
        break;
    }
}

$badge_url = ($matched_internal_value && function_exists('lix_get_badge_image_url'))
    ? lix_get_badge_image_url($matched_internal_value)
    : null;

$category_name = isset($roots[$category_id])
    ? html_entity_decode(wp_strip_all_tags($roots[$category_id]))
    : '';

$page_title = ($license_label && $category_name)
    ? "Resources shared under $license_label — $category_name"
    : "License Results";
?>

<!-- The following lines are needed to show the breadcrumb and the <hr> on the following line -->
<?php if ($bfa_ata['widget_center_top'] <> '') {
    echo bfa_parse_widget_areas($bfa_ata['widget_center_top']);
} ?>
<div class="<?php echo ( is_page() ? 'page ' : '' ) . 'post" id="post-'; the_ID(); ?>">

<div class="container" style="display: flex; align-items: center; gap: 20px;">

    <?php if ($badge_url) : ?>
        <!-- License Badge -->
        <div style="flex-shrink: 0;">
            <img src="<?php echo esc_url($badge_url); ?>" alt="" style="height: 60px; width: auto;">
        </div>
    <?php endif; ?>

    <!-- Title -->
    <h1 style="margin: 0;"><?php echo esc_html($page_title); ?></h1>

</div>

<!-- Back to Index -->
<p><a href="<?php echo esc_url(add_query_arg('license', $license_slug, home_url('/license-index/'))); ?>">&larr; Back to License Index</a></p>

    <?php echo do_shortcode('[spacer height="20px"]'); ?>

    <?php
    $paged = get_query_var('paged') ? get_query_var('paged') : 1;

    // Get the post ID list for this license+category combination from
    // the Custom License Index plugin's cached data, then run a real
    // WP_Query against it (post__in) for native pagination/excerpts --
    // matching languages-scripts.php's own approach, rather than
    // meta_query LIKE matching (which doesn't cleanly apply here, since
    // license classification depends on URL parsing, not a simple
    // substring match against stored meta).
    $post_ids = array();
    if (function_exists('lix_get_posts_for_slug_and_category')) {
        $records = lix_get_posts_for_slug_and_category($license_slug, $category_id);
        $post_ids = wp_list_pluck($records, 'id');
    }

    if (empty($post_ids)) {
        echo '<p>No resources found.</p>';
    } else {

        $args = [
            'post_type'      => 'post',
            'post__in'       => $post_ids,
            'posts_per_page' => 50, // Adjust as needed
            'paged'          => $paged,
        ];

        $query = new WP_Query($args);

        $current_id = ($post->ID);

        if ($query->have_posts()) :

            // Pagination Above (aligned right)
            echo '<div class="pagination" style="text-align: right; margin-bottom: 20px;">';
            echo paginate_links([
                'total'   => $query->max_num_pages,
                'current' => max(1, get_query_var('paged')),
                'format'  => '?paged=%#%',
                'prev_text' => '← Previous',
                'next_text' => 'Next →',
            ]);
            echo '</div>';

            // Loop Through Posts
            while ($query->have_posts()) : $query->the_post(); ?>
                <div class="post">
                    <h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h3>
                    <div><?php the_excerpt(); ?></div>
                </div>
            <?php endwhile;

            // Pagination Controls
            echo '<div class="pagination" style="text-align: center; margin-top: 20px;">';
            echo paginate_links([
                'total'   => $query->max_num_pages,
                'current' => max(1, get_query_var('paged')),
                'format'  => '?paged=%#%',
                'prev_text' => '← Previous',
                'next_text' => 'Next →',
            ]);
            echo '</div>';

        else :
            echo '<p>No resources found.</p>';
        endif;

        wp_reset_postdata();
    }
    ?>
</div>

<?php get_footer(); ?>