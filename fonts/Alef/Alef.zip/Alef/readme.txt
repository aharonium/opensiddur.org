alef.hagilda.com

אָ‏לֵף הוא גופן רשת דו־לשוני פתוח
==========================
אלף נולד למסך ועוצב לפיקסל מתוך מוטיבציה להרחיב את מנעד הגופנים הקיימים בעברית ברשת, ובעיקר להוות אלטרנטיבה אמיתית לברירת המחדל - "אריאל".

Alef is an open source bilingual webfont
========================================
Alef was born to the screen and designed to the pixel in an attempt to extend the pallet of Hebrew fonts available for web design and especially to challenge the only default — "Arial".

In this folder:

Alef
┃
┣━ -COMING-SO0N-.txt		// some shameless promotion
┣━ Alef-Webfont		// files to embed on the web
┣━ OFL-license.txt		// the open font license
┣━ readme.txt			// a bit about what's in the package
┣━ TTF				// True Type files, can be used beyond the web
┗━ VTT-Source			// Source files for remixing including the manual hinting done in Visual True Type