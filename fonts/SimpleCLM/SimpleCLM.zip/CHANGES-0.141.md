# Simple CLM Medium 0.141 (Open Siddur Project build, 2026-11-25)

Based on Simple CLM Medium 0.140 (Culmus) as maintained for the Open Siddur Project (“ANV”),
which includes Aharon Varady’s 2022 coverage additions. This release merges the Sofer Books
update by Mordechai Shaliehsaboo and adds further Hebrew and non-Hebrew support.

- 3,007 glyphs (0.140: 2,604) and 2,967 mapped characters (0.140: 2,598).
- No character was removed. All punctuation (quotation marks, ₪, €, thin space, dotted circle)
  and the zero widths of ZWJ, ZWNJ, LRM and RLM are unchanged from 0.140.
- Only the Medium style is updated; Bold, Medium Oblique and Bold Oblique remain at 0.140.

## From the Sofer Books update

- **Sheva na, U+05C8** (HEBREW POINT SHEVA NA MUDGASH, Unicode 18.0): the `shevana` glyph, with
  vowel and meteg positioning.
- **Dagesh ḥazaq, U+05C9** (HEBREW POINT DAGESH HAZAQ MUDGASH, Unicode 18.0): a square dot,
  in contrast to the round dagesh. U+05C9 becomes `dageshxazaq`, or one of 29 precomposed letters
  (`betdagesh.xz` etc.).
- **Meteg**: Sofer Books meteg placement, and extra space after narrow letters (vav, yod, zayin,
  nun, resh, gimel…) that carry a vowel plus meteg, so the marks clear the next letter.
- **Not taken**:
  - The sheva + varika → sheva na substitution. Varika is now a visible Ladino mark, and sheva na
    has its own code point.
  - The Sofer Books punctuation designs and the non-zero zero-width-character widths.

## Unicode 18.0 marks in older browsers

Browsers whose Unicode data predates 18.0 (e.g. Firefox with Unicode 17 data) don’t attach
U+05C8 and U+05C9 to the preceding letter, so the font’s substitutions and positioning can’t act
on them.

- The U+05C9 glyph now carries the square dot itself; in Sofer Books it was blank.
- The outlines of sheva na and U+05C9 are shifted so that, when left unattached, they fall over
  the preceding glyph (centered on the dotted circle) instead of beside it.
- Their anchors were adjusted by the same amount, so attached positions in Unicode 18 browsers
  are unchanged.

## Hebrew positioning and new marks

- **Sheva na in final khaf**: new `finalkafshevana`, with sheva na inside the letter where sheva naḥ
  sits (`finalkafsheva`). It splits back apart when a dagesh or meteg follows, as `finalkafsheva`
  does.
- **Sheva na anchors**: sheva na now has a position on every base where sheva has one.
- **Varika, U+FB1E**: no longer hidden. Redrawn smaller (460 units wide; was 660) and positioned
  over the top of every letter. The glyph is renamed `uniFB1E` (FontForge read `varika` as
  U+05F5).
- **Rafe**: positions added for the 71 letter forms that had none (zayin, ḥet, tet, lamed, mem,
  nun, samekh, ayin, tsadi, qof, resh, shin…); the 30 existing ones are unchanged. On lamed, rafe
  and varika sit over the body, clear of the ascender.
- **Upper dot U+05C4, lower dot U+05C5, masora circle U+05AF**: previously mapped to an empty glyph
  and hidden. Now drawn and positioned:
  - Upper and lower dots are round, 220 units across (about 1.5× the holam), so they aren’t taken
    for niqqud or te’amim.
  - The upper dot sits just above holam height, centered over the top of the letter.
  - The masora circle (300 units across) is centered at the upper dot’s height.
  - The lower dot is centered under the whole letter (resh included), not under the stem as
    vowels are.
  - The lower dot sits at one depth under every letter: its top is 726 units below the baseline,
    clear of the lowest vowel (qamats qatan, −606) and every descender (−455). This puts it below
    the font’s line-spacing descent (575 units hhea / 625 Windows).
- **Yiddish ײַ (U+FB1F; U+05F2 + U+05B7)**: the pataḥ is lengthened to reach from one yod to the
  other (`patah.yy`, placed by hand by Aharon Varady).
- **Dotted circle U+25CC**: every Hebrew mark is centered on it at its usual height. Holam is
  centered rather than at its upper-left letter position, and dagesh ḥazaq is the square dot.

## Added from GNU FreeFont

Outlines from FreeSans (FreeSerif where FreeSans lacks a character), scaled 187.9% as in the 2022
additions:

- 53 symbols and punctuation from the custom-fonts-display sample lines (☉ ☜ ☞ ❦ ❧ ⹂ ☯ ♈–♓
  ⚲ ⚥ ⚧ 🔯 🌐 …).
- Georgian, Gothic, Ugaritic, Tifinagh, and Phonetic Extensions (including ᵊ U+1D4A).
- Egyptological alef and ain, U+A722–A725 (ꜥ), from FreeSerif.
- U+FE0E and U+FE0F as empty zero-width glyphs.

## Names

- Version string: “Version 0.141” (head revision 0.141).
- The copyright notice (name ID 0) credits:
  - the Sofer Books work;
  - the Hebrew mark work by Aharon Varady;
  - the FreeFont additions.

## Not covered

- 30 pictographs from the sample lines (📖 💬 🖖 🗀 🕮 📚 …, plus ֍ ֎ ⛎ ⸿ ⹝ ﷻ). No GPL font has
  them.
- Arabic, Devanagari, Bengali, Ethiopic, CJK, Samaritan, Runic, Old South Arabian, cuneiform, and
  the ConScript private-use scripts (Tengwar, pIqaD). These are left to fallback fonts.
- Sheva and sheva na have no position on the Yiddish ligatures װ ױ ײ.

## Checker changes (display-font-charmap.php)

- The lower dot is checked as centered under the whole letter, resh included.
- The lower dot must sit at one height under every letter, final forms included (within 0.02 em).
- It must also sit at least 0.03 em below the lowest vowel the font draws.
