If you would like to contribute directly, please file an issue to discuss your contribution before starting work on it, so you don't waste time. 

When your contribution is included, please add the name of the copyright author to AUTHORS.txt and your name to CONTRIBUTORS.txt
